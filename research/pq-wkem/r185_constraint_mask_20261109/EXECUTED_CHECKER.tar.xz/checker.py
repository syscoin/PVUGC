#!/usr/bin/env python3
"""R185: adversarial public-coefficient extraction for a toy hash-gate quotient.

This is a regression of a proposed CLASS of polynomially encoded source masks,
NOT a WKEM, live bitcoin verifier, QPT experiment or constructive cryptography.
"""
import hashlib, random, json, itertools
from math import comb

P=65537
N=8
D=4
BASIS=[mask for mask in range(1<<N) if mask.bit_count()<=D]
IDX={mask:i for i,mask in enumerate(BASIS)}

# In the Boolean quotient over F_65537, z_i^2=z_i, monomials multiply via bitwise OR.
def mul(a,b):
    out={}
    for u,au in a.items():
      for v,bv in b.items():
        m=u|v
        out[m]=(out.get(m,0)+au*bv)%P
    return {m:v for m,v in out.items() if v}

def add(*args):
    out={}
    for a in args:
      for m,v in a.items(): out[m]=(out.get(m,0)+v)%P
    return {m:v for m,v in out.items() if v}

def neg(a):return {m:-v%P for m,v in a.items()}

def scale(a,s):return {m:v*s%P for m,v in a.items() if v*s%P}

one={0:1}
x=[{1<<i:1} for i in range(N)]

def xor_bit(a,b):return add(a,b,scale(mul(a,b),-2))
def or_bit(a,b):return add(a,b,neg(mul(a,b)))

# Toy source SHA-like bit constraints, not SHA itself. The 3-way-OR bit encodes a
# union of challenge types; the final equality t=1 stands for a valid challenge.
constraints=[
 add(x[3],neg(mul(x[0],x[1]))),
 add(x[4],neg(xor_bit(x[1],x[2]))),
 add(x[5],neg(mul(x[3],x[4]))),
 add(x[6],neg(or_bit(or_bit(x[5],x[2]),x[0]))),
 add(x[6],neg(one)),
 add(x[7],neg(xor_bit(x[0],x[1]))),
]

def value(p,vals):
  return sum(v for m,v in p.items() if all(vals[i] for i in range(N) if m>>i&1))%P

def synd(vals): return tuple(value(c,vals) for c in constraints)

def vec(p):
  v=[0]*len(BASIS)
  for m,a in p.items():
    if a and m not in IDX: raise ValueError('degree exceeds basis')
    if a:v[IDX[m]]=a
  return v

# Mask ideal span of constraints times monomials degree <=1 (all degree <=4).
monomials=[{0:1}]+[{1<<i:1} for i in range(N)]
generators=[mul(c,m) for c in constraints for m in monomials]
columns=[vec(one)]+[vec(g) for g in generators]

# Gaussian elimination of augmented equations M z = F (F is public coefficient vector).
# Every solution's first coordinate is K if 1 not in the ideal-mask span.
def solve(M, f):
  rows=[[M[j][i] for j in range(len(M))]+[f[i]] for i in range(len(f))]
  pivots=[];r=0;w=len(M)
  for col in range(w):
    k=next((k for k in range(r,len(rows)) if rows[k][col]%P),None)
    if k is None:continue
    rows[r],rows[k]=rows[k],rows[r]
    v=pow(rows[r][col],-1,P)
    rows[r]=[(z*v)%P for z in rows[r]]
    for j in range(len(rows)):
      if j==r:continue
      q=rows[j][col]
      if q: rows[j]=[(rows[j][t]-q*rows[r][t])%P for t in range(w+1)]
    pivots.append(col);r+=1
    if r==len(rows):break
  for j in range(r,len(rows)):
    if rows[j][-1]%P:raise ValueError('no solution')
  z=[0]*w
  for j,col in enumerate(pivots):z[col]=rows[j][-1]%P
  return z,pivots

def linear_comb(cols,coeff):return [sum(col[i]*coeff[j] for j,col in enumerate(cols))%P for i in range(len(BASIS))]

# Real function: for every valid trace all constraints=0, so F(w)=K.
valid=[]
for bits in itertools.product(range(2),repeat=N):
  if not any(synd(bits)):valid.append(bits)
assert valid
assert all(sum(synd(w))==0 for w in valid)

# If unit 1 belonged to span(generators), any valid assignment would contradict
# 1 = 0. The linear system recovers K without FINDING such an assignment.
seed=int.from_bytes(hashlib.sha256(b'R185-realistic-experiment-seed').digest()[:8],'big')
rng=random.Random(seed)
counts={'valid_assignments':len(valid),'coeff_basis_dim':len(BASIS),
        'constraint_count':len(constraints),'generator_count':len(generators),
        'basis_degree_limit':D, 'coeff_extraction_without_witness':0,
        'honest_all_valid_same_capability':0,'false_evals_can_differ':0,
        'distinct_random_key_trials':0}

for trial in range(24):
  K=rng.randrange(P)
  params=[rng.randrange(P) for _ in generators]
  public=linear_comb(columns,[K]+params)
  solution,pivots=solve(columns,public)
  assert 0 in pivots
  assert solution[0]==K
  counts['coeff_extraction_without_witness']+=1
  counts['distinct_random_key_trials']+=1
  polynomial={m:public[i] for i,m in enumerate(BASIS) if public[i]}
  for w in valid:
    assert value(polynomial,w)==K
    counts['honest_all_valid_same_capability']+=1
  invalid=[w for w in itertools.product(range(2),repeat=N) if any(synd(w))]
  assert any(value(polynomial,w)!=K for w in invalid)
  counts['false_evals_can_differ']+=1

# A hash of public polynomial coefficients cannot magically prevent the
# coefficient-level attack when raw coefficient representation is still supplied.
# If only hashes of coefficients are provided, no general public polynomial eval
# procedure follows from ordinary hash commitment alone: this is a missing API.
counts['cryptographic_release']='NOT OBTAINED: public linear ideal mask yields K by Gaussian elimination'
counts['formal_scope']='Explicit coefficient output, degree <=4, 8 Boolean wires, toy source constraints; not real SHA/AuxPoW'
counts['security_claim']='NONE'
counts['source_sha256']=hashlib.sha256(open(__file__,'rb').read()).hexdigest()
print(json.dumps(counts,indent=2,sort_keys=True))

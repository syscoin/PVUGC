# SL₂–Frobenius compensated local mixing for the existing Schur QAP carrier

**Date:** 2026-10-23. **Exact starting research head:** `d7d7862522faf1603c0a2e6e572b03d320f56045`, `syscoin/PVUGC#1`, branch `research/pq-wkem-validation-20260918`. **Scope:** a new explicit *linear-source, secret node-wise mixer* with unchanged supplied-representation ⇒ ORIGINAL-witness theorem and unchanged dense public size; **no** arbitrary-key hiding/QPT proof. This continues the published 3×3 Schur and extension-separated Booleanity carrier, not a new WE assumption, a new NP relation or an unrelated gadget.

## 1. Exact algorithms and entire public output

Retain the preceding source compiler, field embedding and sampled-node distribution unchanged: `F=GF(2^128)`, `E=GF(2^256)` with public `theta∈E\F`; original Boolean R1CS with `n` ORIGINAL wire coordinates, `m` constraints, `m−1` fixed off-domain nodes and `r` fresh tail nodes; `L=m−1+r`, `k=n+m`. The public affine source `y=(z0,w_1,...,w_n,rho_0,...,rho_(m−2))∈F^k` has node forms `a_e(y),b_e(y),c_e(y),s_e(y)`, *linear in y*, with `a_e,b_e,c_e` independent of quotient rho. The identity `a_e*b_e+z0*c_e+s_e²=F_y(e)` and the exact earlier QAP SOURCE extraction apply. Let `a_e(y)=a_(e,0)z0+Σ_i a_(e,i)w_i` and analogously for `b_e`, with coefficients entirely in F.

At every node sample, **independently** of all sources and other nodes, a uniform private

```
       T_e = [p_e q_e] in SL_2(F),    p_e*t_e + q_e*r_e = 1
             [r_e t_e]
```

(`t_e` here is an SL₂ matrix entry, **not** the QAP residual). To sample exactly uniformly in classical polynomial time: draw `(p,q)` uniformly from `F² \ {(0,0)}`, select a uniform free coordinate for the second row and solve `p*t+q*r=1`. The number of choices for each nonzero first row is exactly `|F|`, giving uniform SL₂.

Define public source-linear Booleanized Frobenius squares of the *original* two node forms,

```
A_e^B(y) = a_(e,0)^2*z0 + Σ_i a_(e,i)^2*w_i,
B_e^B(y) = b_(e,0)^2*z0 + Σ_i b_(e,i)^2*w_i.
```

These are computable coefficientwise at private setup (the node's coefficient vectors are public); they are **linear in the same y**. The new private-mixed forms are

```
a'_e = p_e*a_e + q_e*b_e,
b'_e = r_e*a_e + t_e*b_e,
c'_e = c_e + (p_e*r_e)*A_e^B + (q_e*t_e)*B_e^B.
```

Retain private shears `alpha_(e,i)∈E` satisfying `alpha_(e,i)^2 = bmask_(e,i)+theta*e^(i−1)` with independently uniform private `bmask∈F`, and set

```
eta_e(y)  = Σ_i alpha_(e,i)*w_i,
beta_e(y) = Σ_i alpha_(e,i)^2*w_i.
```

An independent constant `gamma_e*z0` shear may optionally be retained *unchanged*. It is not necessary: the exact identity `S_gamma=(I+gamma E13) S_0 (I+gamma E31)` lets independent uniform two-sided factors absorb it with **identical entire public coefficient distribution**. For simplicity this construction directly uses `gamma=0`. This gauge equivalence is for honest independent setup coins, not a malicious retained-coins claim.

**New gate, still linear in y and still 3×3:**

```
S'_e(y) = [ c'_e(y)+beta_e(y)    a'_e(y)     s_e(y)+eta_e(y) ]
          [ b'_e(y)              z0          0               ]
          [ s_e(y)+eta_e(y)      0           z0              ].
```

**Build/Setup** samples independent private uniform `K∈E`, independently uniform `U_e∈E^(N×3)` and `V_e∈E^(3×N)` and the private per-node shears and SL₂ matrices above. Publish the **complete** `k` coefficient matrices, with no new monomial slices or helper variables,

```
C_j = 1[j=0]*K*I_N + Σ_(e=1)^L U_e S'_e(unit_j) V_e ∈ E^(N×N)
```

for `N=2L+h`. Also publish the same pinned source R1CS/compiler, node list, field embeddings, `theta`, claim/UTXO/branch/anchors/window, intended native verification key, any public proof/checking metadata and applicable setup/funding transcript as the predecessor. The SL₂ coins, bmask, factors and K remain private/erased in the **honest-erasure baseline**; no malicious-secure MPC or graph is claimed implemented.

**Encode(x,w):** for *every* ORIGINAL Boolean satisfying w compute the predecessor's unique normalized Frobenius-QAP source `(1,w,rho(w))`, with rho calculated from the ORIGINAL QAP numerator/quotient. No SL₂ secrets or canonical witness are required. Different w may retain different rho and original source vectors.

**Recover(x,y):** enforce `y∈F^k, z0=1`, build `C(y)=Σ_j y_j C_j`, find the unique `lambda∈E` with `rank_E(C(y)-lambda I_N)≤2L`, confirm the fixed native verifying-key/claim binding and return `K=lambda`. On honest valid ORIGINAL inputs it returns the **same K**. The native signature and Bitcoin spend graph remain conditional/unimplemented.

**SuppliedPairExtract(x,lambda,y):** apply the same rank, subfield, normalization, context and verifying-key checks and return `w` from y. The probabilistic ORIGINAL-witness theorem below applies to *provided* `(lambda,y)`; **nothing** here extracts a source from a bare K or a signature.

## 2. Exact characteristic-two mixing identity (proved)

Let `D_i(y)=w_i²+z0*w_i∈F` and set

```
A_e^2 + z0*A_e^B = Σ_i a_(e,i)^2 * D_i,
B_e^2 + z0*B_e^B = Σ_i b_(e,i)^2 * D_i,
```

where `A_e=a_e(y)`, `B_e=b_e(y)`. These are **polynomial identities for every projective SOURCE**, not merely values observed in a toy test. Because `p*t+q*r=1` and characteristic two,

```
        a'_e*b'_e = a_e*b_e + (p*r)*a_e² + (q*t)*b_e².
```

Therefore the **new QAP residual** satisfies exactly

```
 a'_e*b'_e + z0*c'_e + s_e²
 = a_e*b_e + z0*c_e + s_e²
   + Σ_i [ (p*r)*a_(e,i)² + (q*t)*b_(e,i)² ] * D_i(y).    (★)
```

All the extra terms in (★) are **in the base field F** for F-typed y. They vanish **identically** for every normalized Boolean ORIGINAL w; no equality of intermediate states of different valid witnesses is required. The same field key K and honest local determinant zero are preserved for every original satisfying witness. This is a *new source-linear local operator*, not nonlinear interpolation, a secret online oracle or a signature trick.

After the existing extension-separated shears, for normalized y `z0=1`, write `delta_i=w_i²+w_i` and `P_delta(T)=Σ_i delta_i T^(i−1)`. The complete determinant becomes

```
 det S'_e(y) =
    [ F_y(e) + Σ_i ( bmask_(e,i) + (p*r)a_(e,i)² + (q*t)b_(e,i)² )*delta_i ]
       + theta * P_delta(e).                               (★★)
```

The bracket belongs to F. Thus for any non-Boolean F-typed source, the `theta F` component cannot cancel with it and the nonzero degree-`≤n−1` polynomial `P_delta` has at most `n−1` roots: **at least L−n+1 nodes fail deterministically, simultaneously for all quotient/source choices**. For all Boolean w (including invalid ORIGINAL assignments and arbitrary quotient rho), the new determinant is precisely the old `F_y(e)` at every node; hence the predecessor's *whole-source* robust sampled-QAP theorem, including `T` bad nodes for every invalid Boolean SOURCE, is inherited exactly.

For every normalized y, the bottom-right 2×2 block is `I_2`, so `rank_E S'_e(y)=2` if determinant is zero, and `3` otherwise. Quotient rho enters **only** through `s_e` in `(1,3)` and `(3,1)`; the quotient derivative remains `J=E13+E31`, rank two. This does not resurrect the predecessor's full-rank quotient-support subpencil, but also does not prove full-tensor secrecy.

## 3. Whole-source supplied-pair theorem and QPT scope (proved from pinned predecessor)

Fix any honest instance and node/SL₂/shear coins. The identities above imply the same set of valid normalized source vectors and **the same lower bounds on the number of violated local gates** as the pinned `d7d786...` theorem. Independently sampled uniform `U_e,V_e` then make the shifted matrix for each *fixed* normalized y equal in law to an independent uniform rectangular product `A_R B_R`, with `R=2L+v(y)` where `v(y)` is the number of violated nodes. This follows from exact rank factorization of each `S'_e(y)` and invariance of independent uniform factors under fixed invertible changes of basis; it holds **conditional on the sampled secret SL₂ matrices**. The original simultaneous union bound over all normalized F-typed SOURCE vectors and all wrong field scalars is therefore unaltered. In particular:

```
 epsilon_bool <= 2^(n+1) * binom(L,T−1) * (m+T−2)^r / |F|^(r−T+1)
 epsilon_rank <= 16(h+1)*|F|^(k−1)*|E|^(−h²)
 epsilon_wrong < 4*|F|^(k−1)*|E|^(1−h²).
```

With the **same** checked illustrative parameters `n=11000,m=16000,k=27000,r=375,L=16374,T=234,h=117,N=32865, |F|=2^128, |E|=2^256`, each term is `<2^−135`, total `<2^−133`. Except on that bad **honest-setup** event, **every provided rank-accepted `(lambda,y)` with `z0=1,y∈F^k` has lambda=K and w an ORIGINAL satisfying witness**. This is information-theoretic over setup and holds simultaneously for adaptive *classical output* chosen after full-public QPT processing, without rewinding. It does **not** prove that QPT key recovery produces such a pair.

The private mixer adds exactly `3L` base-field sampled degrees of freedom (for large L: 49,122 base-field elements, 785,952 bytes of uncompressed uniform coins). It adds **zero** SOURCE variables, gate nodes, published matrix coefficient slices or field operations in offline Recover beyond the predecessor. Published matrices still occupy **933,213,506,400,000 bytes ≈0.933 PB**. Setup field-linear form preprocessing grows, but the output remains wildly impractical; no claim of engineering efficiency is made. If omitting the gamma gauge from the predecessor, the net **sampled-private-byte** change is `+785,952−523,968=+261,984 bytes`; this is not a public-storage saving.

## 4. Why this is not just the old removable constant gauge

The earlier `gamma*z0` shear is an **exact constant GL₃×GL₃ gauge**, so integrating it out leaves the *entire* public distribution unchanged. The new per-node SL₂ step instead alters the *original-variable coefficient maps*: an independent formal a-direction enters the E12 and E21 positions as `p E12+r E21`. For generic `pr≠0` this matrix has rank two, whereas the predecessor's pure a-direction was the rank-one `E12`. Constant invertible left/right gate changes preserve the rank of a formal independent source coefficient, so the universal new mixer is **not** the same local constant-gauge identity. The additional Frobenius-linearized `c'_e` term vanishes only on the Boolean locus at the determinant level; it is a genuinely relation-dependent change for non-Boolean projective sources.

This non-equivalence is an *algebraic design property*, not a theorem that K is harder to recover. In particular, real R1CS coefficients are not independent formal a,b directions, and private `alpha` shear correlations could admit more subtle reductions. **Do not infer full-public indistinguishability or increased computational hardness** from the formal-rank fingerprint alone. The new rank-two a/b slices may even aid a joint factor attack; that is an internal validation target, not evidence of safety.

## 5. Exact remaining full-public tensor equation; validation and handoff

For an original variable coordinate `w_i`, write `Z_e=u_(e,1)v_(e,1)`, `X_e=u_(e,1)v_(e,2)`, `Y_e=u_(e,2)v_(e,1)`, `J_e=u_(e,1)v_(e,3)+u_(e,3)v_(e,1)`. The entire w_i public coefficient slice has the explicit form

```
 C_(w_i) = Σ_e [ ( c_(e,i) + p_e*r_e*a_(e,i)² + q_e*t_e*b_(e,i)²
                    + alpha_(e,i)² ) * Z_e
                + (p_e*a_(e,i)+q_e*b_(e,i))*X_e
                + (r_e*a_(e,i)+t_e*b_(e,i))*Y_e
                + alpha_(e,i)*J_e ].
```

The quotient slice still has the known public moments `C_(rho_j)=Σ_e sqrt(Z_QAP(e))*sqrt(e)^j *J_e`. The z0 slice additionally includes `K I +Σ_e(u_(e,2)v_(e,2)+u_(e,3)v_(e,3))`. **The next missing reduction is exactly whether the *joint* quotient-and-original slices permit reconstructing those hidden local factors and the unknown z0 baseline/K, or can be embedded in an independently justified QPT-hard standard problem.** Source soundness does not supply this reduction; neither a spectral rank check nor an untested name for an assumption is enough.

`sl2_frobenius_mix_check.py` is a complete standalone Python standard-library checker. It samples exact SL₂ elements over GF(16), uses GF(16)⊂GF(256) private shears and independent actual outer-factor matrices, verifies local identity (★★), ranks, deterministic extension code and full public-matrix same-key recovery over distinct valid witnesses. It also implements an **actual** 3-row ORIGINAL Boolean R1CS → interpolated off-domain QAP quotient → Frobenius source encoding (two valid witnesses yield different rho vectors) → new gate → outer-mixed public matrices → same key. Its 2 independent synthetic setups plus a separate actual QAP fixture passed **173,408 assertions**; two executions yielded identical captured JSON. The small fields/fixtures are correctness tests, not quantum or multi-capsule security tests.

**Explicitly UNPROVED:** full-public-output false-instance QPT secrecy, bare-K recovery or native signature forgery → ORIGINAL extraction/independent QPT break, related capsules, malicious/retained-coin N-of-N setup, honest watcher inclusion, finite Syscoin evidence parsing, native post-quantum Bitcoin signature/settlement graph and any practical release size. No production/workflow code is touched. Keep `syscoin/PVUGC#1` open/draft/unmerged and the research task enabled.

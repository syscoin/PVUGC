#!/usr/bin/env python3
"""Standalone executable SL2-Frobenius Boolean-linearized Schur mixer validation.
GF(16) ⊂ GF(256) checks actual outer-mixed public coefficient matrices.
Not a QPT proof or false-instance security experiment.
"""
import itertools, json, random, math

FP=0x13
def mul(a,b):
    r=0
    for _ in range(4):
        if b&1:r^=a
        a<<=1
        if a&16:a^=FP
        b>>=1
    return r
FM=[[mul(a,b) for b in range(16)] for a in range(16)]
def powf(a,n):
    r=1
    while n:
        if n&1:r=FM[r][a]
        a=FM[a][a];n>>=1
    return r
def trace(a):
    t=0
    for _ in range(4):t^=a;a=FM[a][a]
    assert t in (0,1)
    return t
KAPPA=next(i for i in range(1,16) if trace(i)==1)
def emul(a,b):
    a0,a1=a&15,a>>4;b0,b1=b&15,b>>4
    t=FM[a1][b1]
    return (FM[a0][b0]^FM[t][KAPPA]) | ((FM[a0][b1]^FM[a1][b0]^t)<<4)
EM=[[emul(a,b) for b in range(256)] for a in range(256)]
def powe(a,n):
    r=1
    while n:
        if n&1:r=EM[r][a]
        a=EM[a][a];n>>=1
    return r
INV=[0]+[powe(x,254) for x in range(1,256)]
THETA=16
ASRT=0
def check(t,what=''):
    global ASRT;ASRT+=1
    if not t:raise AssertionError((ASRT,what))

def rank(A):
    M=[r[:] for r in A];piv=0
    for col in range(len(M[0])):
        r=next((j for j in range(piv,len(M)) if M[j][col]),None)
        if r is None:continue
        M[piv],M[r]=M[r],M[piv]
        v=INV[M[piv][col]]
        for j in range(col,len(M[0])):M[piv][j]=EM[v][M[piv][j]]
        for i in range(piv+1,len(M)):
            q=M[i][col]
            if q:
                for j in range(col,len(M[0])):M[i][j]^=EM[q][M[piv][j]]
        piv+=1
        if piv==len(M):break
    return piv

def mm(A,B):
    O=[[0]*len(B[0]) for _ in A]
    for i,row in enumerate(A):
        for v,a in enumerate(row):
            if a:
                for j,b in enumerate(B[v]):O[i][j]^=EM[a][b]
    return O

def accum(A,B):
    for i in range(len(A)):
        for j in range(len(A[i])):A[i][j]^=B[i][j]

def Z(e):return FM[e][e]^e^1
NODES=[e for e in range(1,16) if Z(e)!=0][:11]
L=len(NODES);n=2;k=7;N=2*L+2

# Uniform sample from SL2(F): first row uniform nonzero, second row
# uniform in the affine line satisfying p*s+q*r=1.
def sample_sl2(rng):
    while True:
        p,q=rng.randrange(16),rng.randrange(16)
        if p or q:break
    free=rng.randrange(16)
    if p:
        r=free
        s=FM[INV_F[p]][1^FM[q][r]]
    else:
        s=free
        r=FM[INV_F[q]][1]
    check(FM[p][s]^FM[q][r]==1)
    return p,q,r,s
INV_F=[0]+[powf(i,14) for i in range(1,16)]

def shears(e,rng):
    alpha=[];mask=[]
    for i in range(2):
        b=rng.randrange(16)
        square=b^EM[THETA][powf(e,i)]
        a=powe(square,128)
        check(EM[a][a]==square)
        alpha.append(a);mask.append(b)
    return alpha,mask

def source_s(e,y):
    z,w1,w2,*rho=y
    root_z=powf(Z(e),8);root_e=powf(e,8)
    out=0
    for j,r in enumerate(rho):out^=FM[FM[root_z][powf(root_e,j)]][r]
    return out

def gate(e,y,alpha,T):
    z,w1,w2,*rho=y
    p,q,r,t=T
    a=w1^w2;b=z;c=0
    aa=FM[p][a]^FM[q][b]
    bb=FM[r][a]^FM[t][b]
    # Booleanized square of a,b; a=w1+w2, b=z0.
    Wa=w1^w2;Wb=z
    cp=c^FM[FM[p][r]][Wa]^FM[FM[q][t]][Wb]
    eta=0;beta=0
    for v,w in zip(alpha,(w1,w2)):
        eta^=EM[v][w];beta^=EM[EM[v][v]][w]
    v=source_s(e,y)^eta
    return [[cp^beta,aa,v],[bb,z,0],[v,0,z]]

def det3(G):
    x=0
    for p in itertools.permutations(range(3)):
        v=1
        for i,j in enumerate(p):v=EM[v][G[i][j]]
        x^=v
    return x

def source_t(e,y):
    z,w1,w2,*rho=y
    v=FM[z][w1^w2]
    for j,t in enumerate(rho):v^=FM[FM[Z(e)][powf(e,j)]][FM[t][t]]
    return v

def det_expected(e,y,alpha,T):
    z,w1,w2,*rho=y
    p,q,r,s=T
    delta=[FM[w][w]^FM[z][w] for w in (w1,w2)]
    # Original source/QAP + extension-shear Booleanity + new F-only correction
    out=source_t(e,y)
    for i,d in enumerate(delta):out^=EM[EM[alpha[i]][alpha[i]]][d]
    # a=w1+w2, b=z0 -> extra coefficient (p*r)*(delta_1+delta_2)
    out^=FM[FM[p][r]][delta[0]^delta[1]]
    return out

def cy(Cs,y):
    out=[[0]*N for _ in range(N)]
    for j,t in enumerate(y):
        if t:
            for i in range(N):
                for l in range(N):out[i][l]^=EM[t][Cs[j][i][l]]
    return out

def subkey(A,key):
    M=[r[:] for r in A]
    for i in range(N):M[i][i]^=key
    return M

def test(seed):
    rng=random.Random(seed)
    Ts=[sample_sl2(rng) for _ in NODES]
    sh=[shears(e,rng) for e in NODES]
    U=[[[rng.randrange(256) for _ in range(3)] for _ in range(N)] for _ in NODES]
    V=[[[rng.randrange(256) for _ in range(N)] for _ in range(3)] for _ in NODES]
    key=rng.randrange(1,256)
    C=[]
    for j in range(k):
        y=tuple(int(i==j) for i in range(k))
        M=[[0]*N for _ in range(N)]
        for t,e in enumerate(NODES):accum(M,mm(mm(U[t],gate(e,y,sh[t][0],Ts[t])),V[t]))
        if j==0:
            for i in range(N):M[i][i]^=key
        C.append(M)
    counts={'valid':0,'invalid_boolean':0,'nonboolean':0}
    for w1,w2 in itertools.product((0,1),repeat=2):
        for rho in itertools.product((0,1,2,3),repeat=4):
            y=(1,w1,w2,*rho)
            valid=(w1==w2 and not any(rho))
            violations=0
            for t,e in enumerate(NODES):
                G=gate(e,y,sh[t][0],Ts[t]);det=det3(G)
                check(det==det_expected(e,y,sh[t][0],Ts[t]),'boolean determinant')
                check(rank(G)==(2 if not det else 3),'gate rank')
                if det:violations+=1
                # Boolean ORIGINAL source gets same residual as un-mixed gate
                check(det==source_t(e,y),'boolean QAP residual')
            check(violations==0 if valid else violations>=L-5)
            counts['valid' if valid else 'invalid_boolean']+=1
    for _ in range(1500):
        w1,w2=rng.randrange(16),rng.randrange(16)
        if w1 in (0,1) and w2 in (0,1):w1=2
        y=(1,w1,w2,*[rng.randrange(16) for _ in range(4)])
        violations=0
        for t,e in enumerate(NODES):
            G=gate(e,y,sh[t][0],Ts[t]);d=det3(G)
            check(d==det_expected(e,y,sh[t][0],Ts[t]),'nonboolean determinant')
            check((d>>4)==(FM[w1][w1]^w1^FM[e][FM[w2][w2]^w2]),'extension code preserved')
            check(rank(G)==(2 if not d else 3),'nonboolean rank')
            if d:violations+=1
        check(violations>=L-n+1,'MDS rejection')
        counts['nonboolean']+=1
    for w1,w2 in ((0,0),(1,1)):
        Cw=cy(C,(1,w1,w2,0,0,0,0))
        check(rank(subkey(Cw,key))<=2*L,'valid same K rank')
        for lamb in range(256):
            if lamb!=key:check(rank(subkey(Cw,lamb))>2*L,'wrong field key')
    for _ in range(18):
        y=(1,rng.randrange(16),rng.randrange(16),*[rng.randrange(16) for _ in range(4)])
        for lamb in (key,key^1,key^7):
            check(rank(subkey(cy(C,y),lamb))>2*L,'false source rank')
    # Quotient derivative J is unchanged by a,b,c mixing.
    for t,e in enumerate(NODES):
        y=(0,0,0,1,0,0,0)
        G=gate(e,y,sh[t][0],Ts[t])
        check(rank(G)==2 and G[0][2]==powf(Z(e),8))
    return {'seed':seed,'key':key,'SL2_nodes':len(Ts),'counts':counts,'N':N,'k':k,'L':L}

def certificate():
    n=11000;m=16000;k=n+m;base_bits=128;outer_bits=256
    h=117;T=234;r=375;L=m-1+r;N=2*L+h
    q=1<<base_bits;Q=1<<outer_bits
    check((1<<(n+1))*math.comb(L,T-1)*pow(m+T-2,r)*(1<<135)<pow(q,r-T+1))
    check(16*(h+1)*pow(q,k-1)*(1<<135)<pow(Q,h*h))
    check(4*pow(q,k+1)*(1<<135)<pow(Q,h*h))
    check(T>=2*h and L-n+1>=T and q>=2*r*(2*m-2+r))
    return {'n':n,'m':m,'k':k,'r':r,'L':L,'T':T,'h':h,'N':N,
            'outer_bits':256,'base_bits':128,'same_public_coeff_bytes':k*N*N*32,
            'fresh_SL2_setup_random_field_elements':3*L,
            'new_independent_SL2_random_bytes':3*L*16,
            'semantic_error':'<2^-133 simultaneous supplied pair only',
            'key_security':'UNPROVED'}



def test_actual_qap(seed=401):
    """Actual 3-row Boolean R1CS -> off-domain QAP, not a synthetic source.
    Rows: w1 Boolean, w2 Boolean, (w1+w2)^2=0. Distinct valid original
    witnesses (0,0) and (1,1) give different QAP quotient states.
    """
    rng=random.Random(seed)
    rows_A=((0,1,0),(0,0,1),(0,1,1))
    rows_B=((0,1,0),(0,0,1),(0,1,1))
    rows_C=((0,1,0),(0,0,1),(0,0,0))
    gate_nodes=(0,1,2)
    eval_nodes=(3,4,5,6,7)
    def sum_gf(xs):
        t=0
        for x in xs:t^=x
        return t
    def poly_add(a,b):
        r=[0]*max(len(a),len(b))
        for i,v in enumerate(a):r[i]^=v
        for i,v in enumerate(b):r[i]^=v
        return r
    def poly_mul(a,b):
        r=[0]*(len(a)+len(b)-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):r[i+j]^=FM[x][y]
        return r
    def peval(a,x):
        v=0
        for t in reversed(a):v=FM[v][x]^t
        return v
    def quotient(a,b):
        a=a[:];r=[0]*max(1,len(a)-len(b)+1)
        for k in range(len(a)-len(b),-1,-1):
            if a[k+len(b)-1]:
                q=FM[a[k+len(b)-1]][INV_F[b[-1]]]
                r[k]=q
                for j,v in enumerate(b):a[k+j]^=FM[q][v]
        while len(a)>1 and a[-1]==0:a.pop()
        return r,a
    Zpoly=[1]
    lag=[]
    for t in gate_nodes:Zpoly=poly_mul(Zpoly,[t,1])
    for i in gate_nodes:
        pol=[1];den=1
        for j in gate_nodes:
            if i!=j:
                pol=poly_mul(pol,[j,1]);den=FM[den][i^j]
        lag.append([FM[x][INV_F[den]] for x in pol])
    # Each public linear form has three original coefficients, no quotient.
    forms={}
    for e in eval_nodes:
        coefficient=[]
        for rows in (rows_A,rows_B,rows_C):
            coefficient.append(tuple(
                sum_gf([FM[peval(lag[i],e)][rows[i][j]] for i in range(3)])
                for j in range(3)))
        forms[e]=coefficient
    factors=[]
    for e in eval_nodes:
        factors.append((sample_sl2(rng),shears(e,rng)[0]))
    def gate_q(e,y,T,alpha):
        z,w1,w2,r0,r1=y
        coef_a,coef_b,coef_c=forms[e]
        va=sum_gf([FM[c][y[j]] for j,c in enumerate(coef_a)])
        vb=sum_gf([FM[c][y[j]] for j,c in enumerate(coef_b)])
        vc=sum_gf([FM[c][y[j]] for j,c in enumerate(coef_c)])
        Wa=sum_gf([FM[FM[c][c]][y[j]] for j,c in enumerate(coef_a)])
        Wb=sum_gf([FM[FM[c][c]][y[j]] for j,c in enumerate(coef_b)])
        p,q,r,t=T
        aa=FM[p][va]^FM[q][vb]
        bb=FM[r][va]^FM[t][vb]
        cc=vc^FM[FM[p][r]][Wa]^FM[FM[q][t]][Wb]
        rootZ=powf(peval(Zpoly,e),8)
        rootE=powf(e,8)
        s=FM[rootZ][r0]^FM[FM[rootZ][rootE]][r1]
        eta=EM[alpha[0]][w1]^EM[alpha[1]][w2]
        beta=EM[EM[alpha[0]][alpha[0]]][w1]^EM[EM[alpha[1]][alpha[1]]][w2]
        v=s^eta
        return [[cc^beta,aa,v],[bb,z,0],[v,0,z]]
    def encode(w1,w2):
        y=(1,w1,w2)
        pols=[]
        for rows in (rows_A,rows_B,rows_C):
            vals=[sum_gf([FM[v][y[j]] for j,v in enumerate(row)]) for row in rows]
            p=[0]
            for i,value in enumerate(vals):
                term=[FM[value][x] for x in lag[i]]
                p=poly_add(p,term)
            pols.append(p)
        num=poly_add(poly_mul(pols[0],pols[1]),pols[2])
        quo,rem=quotient(num,Zpoly)
        check(not any(rem),'QAP remainder zero for ORIGINAL witness')
        quo +=[0]*(2-len(quo))
        return (1,w1,w2,powf(quo[0],8),powf(quo[1],8))
    valid=[encode(0,0),encode(1,1)]
    check(valid[0]!=valid[1], 'distinct SOURCE states')
    for y in valid:
        for j,e in enumerate(eval_nodes):
            g=gate_q(e,y,*factors[j])
            check(det3(g)==0,'true R1CS QAP gate determinant')
            check(rank(g)==2,'true gate rank')
    size=2*len(eval_nodes)+2; oldN=globals()['N'];globals()['N']=size
    U=[[[rng.randrange(256) for _ in range(3)] for _ in range(size)] for _ in eval_nodes]
    V=[[[rng.randrange(256) for _ in range(size)] for _ in range(3)] for _ in eval_nodes]
    K=rng.randrange(1,256)
    C=[]
    for i in range(5):
        basis=tuple(int(i==j) for j in range(5))
        acc=[[0]*size for _ in range(size)]
        for j,e in enumerate(eval_nodes):
            accum(acc,mm(mm(U[j],gate_q(e,basis,*factors[j])),V[j]))
        if i==0:
            for j in range(size):acc[j][j]^=K
        C.append(acc)
    for y in valid:
        M=cy(C,y)
        check(rank(subkey(M,K))<=2*len(eval_nodes),'full QAP common K')
        for candidate in range(256):
            if candidate !=K:
                check(rank(subkey(M,candidate))>2*len(eval_nodes),'QAP wrong K')
    globals()['N']=oldN
    return {'R1CS_rows':3,'offdomain_nodes':len(eval_nodes),
            'valid_original_witnesses':[(0,0),(1,1)],
            'encoded_source_vectors':[list(x) for x in valid],
            'same_K_from_both':K,'N':size}

if __name__=='__main__':
    check(all(EM[i][INV[i]]==1 for i in range(1,256)))
    check(all(powf(a,16)==a for a in range(16)))
    results=[test(s) for s in (307,311)]
    actual=test_actual_qap()
    print(json.dumps({'candidate':'SL2-Frobenius source-linear local mixer',
          'delta':'private SL2 node-wise transforms A,B with Booleanized Frobenius correction to C; same semantic theorem and 3x3 rank',
          'proof_scope':'honest-setup supplied original representation only; no full-public QPT key secrecy',
          'toy':results,'full_qap_integration':actual,'large':certificate(),'assertions':ASRT},indent=2,sort_keys=True))

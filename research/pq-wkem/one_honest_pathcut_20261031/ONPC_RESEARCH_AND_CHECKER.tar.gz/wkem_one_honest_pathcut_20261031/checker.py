#!/usr/bin/env python3
"""One-honest Native Preauthorization Cut (ONPC): bounded abstract model check.
Not a Bitcoin script implementation, signature verifier, or witness KEM test.
"""
import hashlib, json
from collections import deque
from dataclasses import dataclass

RUN = "2026-10-31-offline-one-honest-pathcut"
CAPSULE_DIGEST = hashlib.sha256(b"actual-public-capsules-and-relation-bound-context-toy").hexdigest()
N = 4
STAGE_OUTPOINT="funding-txid:vout-0"
CLAIM="source-chain-SYS/burn-claim-7"
SAFE_DEST="owner-normal-payout"
VETO_DEST="veto-resolution-covenant"
BAD_DEST="unapproved-recipient"
checks = 0

def ck(condition, tag="check"):
    global checks
    checks += 1
    if not condition: raise AssertionError(tag)

@dataclass(frozen=True)
class Spend:
    name:str; src:str; dst:str; branch:str; outpoint:str; outputs:str; lock:int
    needs_credential:bool; signer_mask:int; good:bool

ALL=(1<<N)-1
normal=Spend("normal","stage","normal_paid","normal",STAGE_OUTPOINT,SAFE_DEST,10,False,ALL,True)
challenge=Spend("challenge","stage","challenged","challenge",STAGE_OUTPOINT,"challenge-locked-output",0,True,ALL,True)
resolve=Spend("resolve","challenged","vetoed","resolve","challenge-outpoint",VETO_DEST,0,False,ALL,True)
# Unauthorized candidates cover missing output, outpoint, timelock, and native-guard controls.
siphon=Spend("siphon","stage","bad","normal",STAGE_OUTPOINT,BAD_DEST,10,False,ALL,False)
early=Spend("early","stage","bad","normal",STAGE_OUTPOINT,SAFE_DEST,0,False,ALL,False)
crossclaim=Spend("crossclaim","stage","bad","normal","different-funding-vout",SAFE_DEST,10,False,ALL,False)
bypass=Spend("bypass","stage","bad","unlisted",STAGE_OUTPOINT,BAD_DEST,0,False,ALL,False)
falsechallenge=Spend("falsechallenge","stage","bad","challenge",STAGE_OUTPOINT,"challenge-locked-output",0,True,ALL,False)
EDGES=(normal,challenge,resolve,siphon,early,crossclaim,bypass,falsechallenge)

def signing_message(e, omitted=frozenset()):
    fields={"domain":"PREAUTH_NATIVE_V1","relation":"ORIGINAL:R-v1","claim":CLAIM,
      "scope":"challenge-branch-7","capsule":CAPSULE_DIGEST,
      "branch":e.branch,"outpoint":e.outpoint,"outputs":e.outputs,"lock":e.lock}
    for f in omitted: fields.pop(f,None)
    return json.dumps(fields,sort_keys=True,separators=(',',':')).encode()

def policy(omitted=frozenset()):
    # Preauthorize ONLY non-challenge branches. The challenge must be a fresh native signature
    # under the SAME honest native key hidden in the SOURCE capsule.
    return frozenset(signing_message(e,omitted) for e in (normal,resolve))

def eligible(e,time,credential,break_release=False,script_timelock=True,script_outpoint=True):
    # Ledger assumes unique UTXO ownership; absolute script timelock, if present,
    # is enforced independently from signature hash coverage.
    if e.name=="falsechallenge" and (credential or not break_release): return False
    if e.name=="challenge" and not credential: return False
    if script_timelock and time<e.lock: return False
    if script_outpoint and e.name=="crossclaim": return False
    return True

def authorized(e,h,preauth,omitted=frozenset(),unguarded=frozenset(),credential=False,break_release=False):
    # Corrupted N-1 sign without limitation; honest h never signs any unlisted message.
    # Native policy may accidentally omit an honest signature for a script path.
    mask=e.signer_mask if e.name not in unguarded else (ALL^(1<<h))
    return (not ((mask>>h)&1)) or signing_message(e,omitted) in preauth or (e.branch=="challenge" and (credential or break_release))

def reachable_bad(h,time,credential=False,omitted=frozenset(),unguarded=frozenset(),
                  script_timelock=True,break_release=False,script_outpoint=True):
    preauth=policy(omitted)
    q=deque([("stage",())]); visited={"stage"}
    while q:
        state,path=q.popleft()
        if state=="bad": return path
        for e in EDGES:
            if e.src!=state: continue
            if not eligible(e,time,credential,break_release,script_timelock,script_outpoint): continue
            if not authorized(e,h,preauth,omitted,unguarded,credential,break_release): continue
            if e.dst in visited: continue
            visited.add(e.dst);q.append((e.dst,path+(e.name,)))
    return None

# Baseline: every potential honest signer excludes all unauthorized edges for all times.
for h in range(N):
    for time in range(0,13):
        for cred in (False,True):
            ck(reachable_bad(h,time,cred) is None,"baseline no bypass")
            ck(signing_message(siphon) not in policy(),"siphon signed? ")
            ck(signing_message(early) not in policy(),"early signed?")
            ck(signing_message(crossclaim) not in policy(),"crossclaim signed?")
            ck(signing_message(bypass) not in policy(),"bypass signed?")
# Time/credential eligibility, legal challenge and normal payout, unique UTXO consumption.
for h in range(N):
    for time in range(0,10):
        ck(eligible(challenge,time,True) and authorized(challenge,h,policy(),credential=True),"timely challenge")
        ck(not eligible(normal,time,False),"early normal guard")
        ck(not eligible(challenge,time,False),"invalid challenge guard")
    for time in range(10,13):
        ck(eligible(normal,time,False) and authorized(normal,h,policy()),"mature payout")
    ck(challenge.src==normal.src and challenge.dst!=normal.dst,"consuming same input")

# Negative controls: one actual missing control at a time.
for h in range(N):
    ck(reachable_bad(h,10,False,omitted=frozenset({'outputs'})) == ("siphon",),"output-binding counterexample")
    # Outpoint substitution is blocked by script guard; disable script guard to model unsafe reuse.
    ck(reachable_bad(h,10,False,omitted=frozenset({'outpoint'}),script_outpoint=False)==("crossclaim",),"outpoint counterexample")
    # A normal signature with lock omitted can authorize an early tx only if native lock absent.
    ck(reachable_bad(h,0,False,omitted=frozenset({'lock'}),script_timelock=False)==("early",),"timelock counterexample")
    ck(reachable_bad(h,0,False,unguarded=frozenset({'bypass'})) == ("bypass",),"honest-cut counterexample")
    ck(reachable_bad(h,0,False,break_release=True) == ("falsechallenge",),"WKEM break counterexample")

# A pre-signature never counts as witness/source security; the witness gate remains external.
ck(normal.needs_credential is False and challenge.needs_credential is True,"separation")
ck(signing_message(challenge) not in policy(),"do not presign challenge")
ck(all((e.signer_mask&ALL)==ALL for e in EDGES),"all scripted edges N-of-N")
ck(not any(e.src=="normal_paid" for e in EDGES),"settlement terminal")
ck(not any(e.src=="vetoed" for e in EDGES),"veto terminal")
print(json.dumps({"run":RUN,"checks":checks,"signers":N,"baseline_bad_paths":0,
 "counterexamples":{"unbound_outputs":"siphon","unbound_outpoint_and_script":"crossclaim",
 "unbound_lock_and_no_script_lock":"early","missing_honest_signer":"bypass",
 "unauthorized_WKEM_release":"falsechallenge"},
 "model":"finite abstract native signature authorization and UTXO state graph; not Bitcoin consensus", "wk_em_claim":"no ORIGINAL witness extraction, source soundness or QPT security tested"},sort_keys=True))

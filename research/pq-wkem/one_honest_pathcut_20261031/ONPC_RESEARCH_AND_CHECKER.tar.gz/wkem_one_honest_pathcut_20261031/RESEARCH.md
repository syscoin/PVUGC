# One-honest preauthorization path cut: full-public restricted LWE/signature composition

**Research checkpoint, 2026-10-31. Independent protocol-graph component only; NOT a generic-NP witness-KEM or a recovery-to-ORIGINAL-witness proof.**

## Continuity and precise objective

Continue from `syscoin/PVUGC#1` exact previous file `research/pq-wkem/native_preauth_joint_qpt_20261031/RESEARCH_AND_CHECKER.md`, SHA-1 Git blob `14beadb2399283d82eea13509bbf2341878e27c5`, at head `08e22afc34c4f502862d05249c15fc34cdb4ceef`; its latest substantive PR comment `6545049866`. That note already proves a **restricted** native-key-signature transcript hybrid for a random-FALSE binary-ISIS SOURCE. This iteration examines the missing graph/preauthorization step without pretending to solve ORIGINAL admissibility.

The named component is **ONPC — One-honest Native Preauthorization Cut**. It provides a concrete pre-signing policy, a graph certificate and a straight-line multi-party full-public QPT composition for the prior *restricted source distribution*. It corrects a tempting but fatal design choice: **the honest native key encrypted by the capsule must not pre-sign its own challenge-path authorization**. Otherwise the purported witness gate is already bypassed. The challenge path must require a *fresh* signature from the recovered capability, and safe timeout/resolve paths may be pre-signed.

## Real source distribution and cryptographic premise

Let q be odd prime, dimension d,n, T_h polynomial. Sample `(A,t)` uniformly from `F_q^(d×n) × F_q^d`. The ORIGINAL relation for this restricted source is `R((A,t),w)=[w∈{0,1}^n ∧ Aw=t]`. Let `p=Pr[∃w:R=1]≤2^n/q^d=δ` and `D_F` the uniform source conditioned on FALSE. This is NOT adversarial FALSE, NOT generic NP, and NOT a selected hard TRUE distribution. Public relation, claim/outpoint, branch, anchors/window, context, checking keys and commitments are part of the view. The input SOURCE must be generated independently of adversarially chosen corrupted signer data for the LWE embedding; a malicious party choosing `(A,t)` invalidates the theorem.

There are N signers with independent native key pairs `(sk_i,vk_i)`. A malicious QPT adversary controls the states, secrets, coins and signatures of N−1 signers and can adaptively react to all honest classical public messages. There is one honest signer `h`; let κ_h be an unambiguous encoding of `sk_h` and `vk_h` a genuine checking key. The honest classical-PPT capsule compiler outputs for each protected bit j and each related unopened capsule

`β_j = A^T s_j + e_j`,  `τ_j = t^T s_j + e*_j + g κ_{h,j}  (mod q)`

with `s_j ← uniform F_q^d` and independent bounded errors `e_j←χ^n, e*_j←χ`. The full public output contains `A,t`, every such ciphertext, `vk_h`, other keys/capsules, signed preauthorization transcripts, contexts, auxiliary public computed data, and adversary-chosen corrupted co-signer behavior. Every valid binary ORIGINAL witness decrypts precisely the same κ_h when `g>2B(n+1)` and `2(g+B(n+1))<q`, by cancellation `w^Tβ_j−τ_j=w^Te_j−e*_j−gκ_{h,j}`. This restricted binary-ISIS release has the previously documented chosen-FALSE nonbinary opener attack and is not a generic WKEM.

### Honest signing policy and native path binding

At pre-funding, the N participants produce exact-byte native signatures only on a safe, finite transaction-message whitelist: e.g. the **normal timeout** path and the **post-challenge safe resolution** path. The honest signer **does not** sign the future challenge message. A challenge transition requires a new native signature under its same encrypted `sk_h` on a domain-separated, exact challenge-path message. Different corrupted signers may sign freely, but no on-chain path is valid without all N required native signatures. This is the **N-of-N preauthorization** role; it is not the one-of-N observer role and not a Syscoin LLMQ/ChainLocks threshold.

Canonical signed messages must bind actual consensus-effective fields: relation identity, claim/UTXO, outpoint, branch, exact output amounts/scripts, timelock/sequence, challenge scope, native checking key and capsule/context digest. The formal graph model uses JSON canonical bytes as a **model of binding only**. Real Bitcoin SIGHASH/script behavior, fork semantics, output type and on-chain native hash-signature opcode availability are separate unverified prerequisites. Merely prefixing an application message without Bitcoin consensus actually committing to those bytes is NOT sufficient. A cryptographic collision or sighash ambiguity making an unsafe transaction share a safe signed digest is an explicit `BindFail` event.

### Finite graph certificate

Let G be a finite directed spend-state graph with all native spend alternatives enumerated. A native transition e has (source UTXO, destination output/condition, message m_e, signer mask, guard). Let `Q_h` be the exact set of honest signing-oracle messages issued before funding and through any allowed adaptive safe signing policy. Let `Unsafe` be all paths reaching an unauthorized terminal or a forbidden premature/unscoped transition. The **path-cut certificate** is

`∀ path P∈Unsafe : ∃ edge e∈P requiring the honest signer with m_e∉Q_h`, 

where unlisted native transitions, missing signers and script/guard failures must be treated as failed certification rather than silently excluded. The in-scope runtime model checks the entire finite listed graph at discrete times and enforces unique-UTXO consumption. If a timely admissible challenge is *actually included* before the payout timelock, it consumes the contested UTXO, so a later normal payout of that same UTXO is impossible. This does NOT ensure propagation, inclusion, availability, bounded honest hash share or resistance to arbitrary BTC censorship.

**Lemma (pure graph/signature, with explicit premises).** Given exact path coverage, native guards and exact transaction-message binding, if the path-cut certificate holds and no forbidden script condition is bypassed, any adversary reaching `Unsafe` must present a valid honest-signer signature on `m∉Q_h`, or break binding/guard assumptions. Proof: take the first cut edge on the realized unsafe path; the adversary controlled the remaining signers, but the honest signature on the cut edge is valid and not a signing-oracle response. Output that message/signature pair as an ordinary fresh EUF-CMA forgery. No witness, representation or quantum rewinding is requested from the adversary. This proof applies only to authorization bypasses, **not** to whether an apparently well-formed challenge signature was obtained by a non-ORIGINAL witness.

### Restricted full-joint QPT composition for the corrupt N−1 case

Fix the source distribution above; let all corrupted co-signer states and data be chosen by a QPT strategy responding to public history, without honest secret-key side channels or quantum signing-oracle superposition queries. Honest native signing messages are classical, chosen via a classical-PPT allowlist/policy reading only public transcript, and the challenge message is not signed. No other protected same-key capsule is selectively opened, and no encryption coins/master coins or maliciously sk-correlated auxiliary data are revealed. All `T_h` protected honest ciphertexts and related unopened capsules appear together in the actual full public view.

For each j, the ordinary nonuniform-QPT decisional-LWE challenger provides uniform source matrix `M^T=[A^T;t^T]` and one `(n+1)`-component LWE/random vector. A straight-line reduction itself generates genuine `(sk_h,vk_h)`, shifts only the final challenged coordinate by `gκ_{h,j}`, samples all other honest ciphertexts in the correct hybrid positions, and executes the N−1 malicious co-signers and the public-history safe signing policy with *actual* honest signatures. Thus each hybrid includes the **joint** relations among the SOURCE, native checking key, adaptive corrupted participants, signing messages, signed preauthorizations and related capsules; it is not marginal pad hiding and does not assume `SourceOpen`.

After T_h replacements, every honest capsule ciphertext is independent uniform, while `vk_h` and all real safe preauthorization signatures retain their joint native distribution. Embed a genuine native QPT EUF-CMA challenger `vk_h`; the simulator services safe classical signing queries via the challenger oracle, executes corrupt signer activity straight-line, and forwards the first valid fresh honest signature on a graph cut edge. Conditioning the uniform source on FALSE costs at most p statistical distance, even against QPT postprocessing, because the joint honest compiler and interactive adversarial simulator define the same channel in both experiments. The restricted authorization-bypass success bound is

`Pr_DF[Unsafe bypass] ≤ p + Σ(j=1..T_h) Adv_QPT_DLWE(B_j) + Adv_QPT_EUF-CMA(B_sig) + Pr[BindFail ∨ GuardFail ∨ CoverageFail]`.

There is **no union factor in the EUF-CMA term** if the reduction outputs the first fresh forged signature, with ordinary multi-query EUF-CMA security. A different event, `SOURCE release on FALSE without an ORIGINAL witness`, is NOT proved absent for chosen x by this bound; chosen-FALSE nonbinary public openings remain a concrete failure. On hard TRUE, an arbitrary successful key recovery/native challenge signature need not yield ORIGINAL W; that reduction is entirely open. For actual parameters, concrete QPT-LWE/security and signature resources are uncalibrated.

### Setup, liveness and graph limits (not silently assumed)

The signed exact graph and all required safe pre-signatures must be validated and made available **before irreversible funding**. A malicious co-signer can refuse and cause a pre-funding abort. This is a pre-funding abort-liveness condition, not a proof of useful completeness after funding; malformed capsules, proof of correct encoding, replay, signature key erasure and holder-controlled public-key consistency still need dedicated verification. A hypothetical keyless Build retaining all its coins is NOT established here. Valid ORIGINAL evidence must still cryptographically unlock the correct *same* native signer key(s); no Bitcoin NP circuit, VM/PCP/BitVM trace verification or online committee is used in this abstract component. A challenge credential is bearer-capable unless an independent designated-owner condition is included in the exact signed path. Normal payout after a legitimate uncontested timeout makes whole-UTXO ownership unrestricted. The SYS/BTC SOURCE verification, witness extraction, network inclusion, native PQ P2MR-like path and full graph of all UTXOs are not proved.

## Executable finite model and negative controls

`checker.py` is a pure Python 3 standard-library exhaustive search over four possible honest signers, 13 times, both presence/absence of a true ORIGINAL-derived credential, and eight enumerated edges. It checks that all unsafe alternatives are cut while native time/credential guards hold, and tests five negative controls: omission of output binding, outpoint binding coupled with loss of outpoint guard, timelock binding coupled with absence of the script lock, omission of one honest signer from a spend path, and successful unauthorized key release on false-source evidence. Native signatures are treated as a **perfect black-box verification predicate plus permitted-oracle set**; there is no test of a PQ signature algorithm or a full Bitcoin transaction. The checker specifically asserts that challenge signing bytes are absent from `Q_h`; an earlier LOCAL test version erroneously pre-signed them, was rejected before publication and corrected.

Run `python checker.py` twice and compare outputs. Captured checked output is `output.json`. It verifies 681 explicit assertions and five expected counterexample paths, in byte-identical executions. This verifies finite graph logic only, not QPT proof or real native checks.

## Main unresolved ORIGINAL-WKEM equation

Still require a witness-free classical-PPT `Comp(R,x,context,pk)` producing the actual complete correlated public distribution and public `Lift(x,W,...)` with, for **every** valid ORIGINAL witness W,

`Lift(Comp(R,x,context,pk),W) = K_precommitted`,

and for adversarial FALSE x and unauthorized hard TRUE x, *any* QPT recovered K or accepted fresh native challenge signature must reduce to an actual ORIGINAL W or an independently justified QPT hardness break. This ONPC graph result does **not** reduce that missing obligation, reject nonbinary openers, instantiate malicious one-honest distributed SOURCE setup, or establish the real Bitcoin native endpoint. Keep the existing research automation enabled.

## Provenance

Run ID `2026-10-31-offline-one-honest-pathcut`, automation turn 11. No external literature/web research. GitHub-only continuity reads: `get_pr_info`, `fetch_issue_comments`, `fetch_file` of the exact prior note at head `08e22afc34c4f502862d05249c15fc34cdb4ceef`. Latest prior substantive ordinary comment `6545049866`. Independent agents: none. Local test command: `python checker.py` twice and byte compare. No claim of deployed Bitcoin/PQ-native functionality, no real PQ signatures, and no secure generic NP witness-KEM.

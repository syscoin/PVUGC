#!/usr/bin/env python3
"""Pivot-twisted Schur-Frobenius release and adaptive rank-metric checks.

This checker inherits the exact GF(16) ⊂ GF(256), SL2, Schur,
rank, and two-sided mixing implementations from the published
sl2_frobenius_mix_check.py (SHA256 pinned in PROVENANCE.json).
It is not a QPT key-secrecy experiment.
"""
import json
import random
import itertools
from sl2_frobenius_mix_check import (
    FM, EM, INV_F, INV, powf, powe, sample_sl2, shears, mm,
    accum, rank, check, THETA, NODES, det3
)

ASSERT = 0

def require(ok, description=''):
    global ASSERT
    ASSERT+=1
    if not ok:raise AssertionError((ASSERT,description))

def mat_lin(mats, coefficients):
    nn=len(mats[0]);out=[[0]*nn for _ in range(nn)]
    for c,M in zip(coefficients,mats):
        if c:
            for i,row in enumerate(M):
                dest=out[i]
                for j,v in enumerate(row):
                    dest[j]^=EM[c][v]
    return out

def field_poly_add(a,b):
    z=[0]*max(len(a),len(b))
    for i,c in enumerate(a):z[i]^=c
    for i,c in enumerate(b):z[i]^=c
    return z

def field_poly_mul(a,b):
    z=[0]*(len(a)+len(b)-1)
    for i,c in enumerate(a):
        for j,d in enumerate(b):z[i+j]^=FM[c][d]
    return z

def field_poly_eval(p,e):
    t=0
    for c in reversed(p):t=FM[t][e]^c
    return t

def field_quotient(a,b):
    a=a[:]
    q=[0]*(len(a)-len(b)+1)
    for i in range(len(q)-1,-1,-1):
        c=FM[a[i+len(b)-1]][INV_F[b[-1]]]
        q[i]=c
        for j,bj in enumerate(b):a[i+j]^=FM[c][bj]
    return q,a

def actual_qap_public_package(seed):
    """Build true 3-row R1CS QAP. Return ONLY public matrices and compiler.

    Private node coins and outer factors never appear in the returned capsule.
    Exact 3-row ORIGINAL constraints: w1²=w1; w2²=w2;
    (w1+w2)²=0. Valid (w1,w2)=(0,0),(1,1).
    """
    rng=random.Random(seed)
    constraint_nodes=(0,1,2)
    offdomain_nodes=(3,4,5,6,7)
    zpoly=[1]
    for t in constraint_nodes:zpoly=field_poly_mul(zpoly,[t,1])
    lag=[]
    for i in constraint_nodes:
        p=[1];den=1
        for j in constraint_nodes:
            if i!=j:
                p=field_poly_mul(p,[j,1]);den=FM[den][i^j]
        lag.append([FM[c][INV_F[den]] for c in p])
    rowsA=((0,1,0),(0,0,1),(0,1,1))
    rowsB=rowsA
    rowsC=((0,1,0),(0,0,1),(0,0,0))
    node_forms={}
    for e in offdomain_nodes:
        vec=[]
        for rows in (rowsA,rowsB,rowsC):
            vec.append(tuple(
                _xor(FM[field_poly_eval(lag[j],e)][rows[j][i]] for j in range(3))
                for i in range(3)))
        node_forms[e]=vec
    # Fresh secret extension-field projective chart for each gate.
    # mu is sampled uniformly from E\F, with a private A/B orientation bit.
    private=[(sample_sl2(rng),shears(e,rng)[0],
              rng.randrange(16,256),rng.randrange(2)) for e in offdomain_nodes]
    N=2*len(offdomain_nodes)+2
    Us=[[[rng.randrange(256) for _ in range(3)] for _ in range(N)] for _ in offdomain_nodes]
    Vs=[[[rng.randrange(256) for _ in range(N)] for _ in range(3)] for _ in offdomain_nodes]
    K=rng.randrange(1,256)
    def gate(e,y,T,alpha,mu,side,with_certificate=False):
        z,w1,w2,r0,r1=y
        a,b,c=node_forms[e]
        A=_xor(FM[x][y[i]] for i,x in enumerate(a))
        B=_xor(FM[x][y[i]] for i,x in enumerate(b))
        C=_xor(FM[x][y[i]] for i,x in enumerate(c))
        Alinear=_xor(FM[FM[x][x]][y[i]] for i,x in enumerate(a))
        Blinear=_xor(FM[FM[x][x]][y[i]] for i,x in enumerate(b))
        p,q,r,t=T
        ap=FM[p][A]^FM[q][B]
        bp=FM[r][A]^FM[t][B]
        cp=C^FM[FM[p][r]][Alinear]^FM[FM[q][t]][Blinear]
        rootZ=powf(field_poly_eval(zpoly,e),8)
        rootE=powf(e,8)
        s=FM[rootZ][r0]^FM[FM[rootZ][rootE]][r1]
        eta=EM[alpha[0]][w1]^EM[alpha[1]][w2]
        beta=EM[EM[alpha[0]][alpha[0]]][w1]^EM[EM[alpha[1]][alpha[1]]][w2]
        v=s^eta
        Ce=cp^beta
        Q=EM[ap][bp]^EM[z][Ce]^EM[v][v]
        if side==0:
            pivot=z^EM[mu][ap]
            newa=ap;newb=bp^EM[mu][Ce]
        else:
            pivot=z^EM[mu][bp]
            newa=ap^EM[mu][Ce];newb=bp
        G=[[Ce,newa,v],[newb,pivot,0],[v,0,pivot]]
        if with_certificate:
            return G,pivot,Q,v
        return G
    def encode(w1,w2):
        original=(1,w1,w2)
        ps=[]
        for rows in (rowsA,rowsB,rowsC):
            vals=[_xor(FM[wi][original[i]] for i,wi in enumerate(row)) for row in rows]
            poly=[0]
            for j,val in enumerate(vals):
                poly=field_poly_add(poly,[FM[val][v] for v in lag[j]])
            ps.append(poly)
        num=field_poly_add(field_poly_mul(ps[0],ps[1]),ps[2])
        quo,rem=field_quotient(num,zpoly)
        require(not any(rem), 'valid original QAP numerator divisible by Z')
        quo += [0]*(2-len(quo))
        return (1,w1,w2,powf(quo[0],8),powf(quo[1],8))
    # Exhaustive normalized toy-source algebra at every private gate:
    # det(twisted)=pivot*Q and pivot!=0 for ALL F-typed z0=1 sources.
    for e,secret in zip(offdomain_nodes,private):
        require(secret[2]>=16, 'private pivot coefficient outside F')
        for w1 in range(16):
            for w2 in range(16):
                for rho0,rho1 in ((0,0),(1,0),(0,1),(7,9)):
                    y=(1,w1,w2,rho0,rho1)
                    G,pivot,Q,v=gate(e,y,*secret,with_certificate=True)
                    require(pivot!=0,'extension chart never singular on normalized F-source')
                    require(det3(G)==EM[pivot][Q],'exact quadratic-form invariant')
                    require(rank(G)==(2 if Q==0 else 3),'local semantic rank preserved')
        # Projective z0=0 gate: a nonzero Schur side term still gives rank >=2.
        for y in ((0,1,0,0,0),(0,0,1,0,0),(0,0,0,1,0),(0,0,0,0,1)):
            G,pivot,Q,v=gate(e,y,*secret,with_certificate=True)
            require(det3(G)==EM[pivot][Q],'projective determinant identity')
            if v:require(rank(G)>=2,'nonzero side guarantees rank-two support')
        # Public gate is source-linear in all five coordinates, not a quadratic API.
        units=[tuple(int(i==j) for i in range(5)) for j in range(5)]
        unit_gates=[gate(e,u,*secret) for u in units]
        for y in ((1,0,0,0,0),(0,1,1,2,5),(1,3,7,11,13)):
            reconstructed=[[0]*3 for _ in range(3)]
            for coefficient,M in zip(y,unit_gates):
                for row in range(3):
                    for col in range(3):reconstructed[row][col]^=EM[coefficient][M[row][col]]
            require(reconstructed==gate(e,y,*secret),'entire gate/source coefficient linearity')
    C=[]
    for idx in range(5):
        unit=tuple(int(i==idx) for i in range(5))
        out=[[0]*N for _ in range(N)]
        for j,e in enumerate(offdomain_nodes):
            accum(out,mm(mm(Us[j],gate(e,unit,*private[j])),Vs[j]))
        if idx==0:
            for v in range(N):out[v][v]^=K
        C.append(out)
    # Public output includes the exact QAP nodes, identical to predecessor.
    # Private mixing coins/factors are not returned.
    return {'capsule':{'C':C,'public_constraint_nodes':constraint_nodes,
            'public_offdomain_nodes':offdomain_nodes,'N':N,'m':3,'n':2,'L':5},
            'public_encode':encode,
            'test_oracle_only':{'expected_K':K}}

def _xor(xs):
    z=0
    for v in xs:z^=v
    return z

def projective_representatives(q,dimensions):
    """One representative of each F_q line in F_q^dimensions."""
    for first in range(dimensions):
        for tail in itertools.product(range(q),repeat=dimensions-first-1):
            yield (0,)*first + (1,) + tail

def test_toy(seed):
    pub=actual_qap_public_package(seed)
    capsule=pub['capsule']
    C=capsule['C'];N=capsule['N'];key=pub['test_oracle_only']['expected_K'];L=capsule['L']
    qs=C[3:]
    encoded=[]
    for w in ((0,0),(1,1)):
        y=pub['public_encode'](*w)
        encoded.append(y)
        M=mat_lin(C,y)
        found=[]
        for candidate in range(256):
            D=[row[:] for row in M]
            for i in range(N):D[i][i]^=candidate
            if rank(D)<=2*L:found.append(candidate)
        require(found==[key], 'public-only offline key recovery: two ORIGINAL witnesses')
    require(encoded[0]!=encoded[1], 'witness-dependent QAP intermediates')
    # Quotient projective field: GF(256)^2 / GF(256)^*.
    # Includes coefficients outside the SOURCE subfield GF(16).
    quot_count=0;min_quot=N
    for u in projective_representatives(256,2):
        Q=mat_lin(qs,u);r=rank(Q)
        min_quot=min(min_quot,r);quot_count+=1
        require(r>=2*(L-3+1),'all E-linear quotient pencil combinations')
    require(quot_count==257)
    # ALL F-typed projective original+quotient directions at z0=0.
    # 4 SOURCE coordinates, 4369 field-projective directions.
    source_count=0;min_joint=N
    for u in projective_representatives(16,4):
        M=mat_lin(C[1:],u);r=rank(M)
        min_joint=min(min_joint,r);source_count+=1
        require(r>=2*min(L-2+1,L-3+1),'all F-typed nonconstant directions')
    require(source_count==(16**4-1)//15)
    return {'seed':seed,'N':N,'L':L,'original_valid_witnesses':2,
            'source_states':[[int(t) for t in x] for x in encoded],
            'public_only_same_K':key, 'quotient_E_projective_directions':quot_count,
            'min_E_quotient_rank':min_quot,'joint_F_projective_directions':source_count,
            'min_F_joint_rank':min_joint}

def exponents(N,L,m,n,k):
    r=L-(m-1)
    aq=r+1; aw=L-n+1
    tq=2*aq;tw=2*aw
    # Distributional lemma: for any fixed source, after factoring every
    # nonzero local gate, the coefficient combination equals AB with
    # independent uniform A in E^(N x d), B in E^(d x N), for ANY d >= t.
    # A random N x d has rank < t only if its first t columns do; if it
    # has rank >= t, AB contains an independently uniform t x N submatrix.
    # Therefore P[rank AB < t] < 4 |E|^(-(N-t+1)), even for d > N.
    fq=N-tq+1
    fw=N-tw+1
    # Counts: E-projective quotient directions <=2 |E|^(m-2),
    # F-projective original-containing directions <=2 |F|^(k-2).
    expQ=fq-(m-2)
    require((k-2)%2==0,'exact quadratic-extension exponent')
    expW=fw-(k-2)//2
    require(expQ>0 and expW>0)
    return {'N':N,'L':L,'m':m,'n':n,'k':k,'tail_r':r,
            'quotient_min_rank':tq,'original_containing_min_rank':tw,
            'quotient_rank_failure_exponent_E':fq,
            'original_rank_failure_exponent_E':fw,
            'quotient_projective_count_E_exponent':m-2,
            'original_projective_count_E_exponent':(k-2)//2,
            'union_quotient_log2_upper':3-256*expQ,
            'union_original_log2_upper':3-256*expW,
            'outer_product_width':'arbitrary d>=required_rank, including d>N',
            'total_probability_less_than_2_power':int(min(256*expQ-4,256*expW-4))}

if __name__=='__main__':
    toys=[test_toy(s) for s in (401,409)]
    large=exponents(32865,16374,16000,11000,27000)
    print(json.dumps({'candidate':'Extension-chart pivot-twisted SL2-Frobenius release',
        'new_claim':'new private E/F pivot mixing; identical all-original-witness K and supplied-pair theorem; adaptive E quotient/F joint rank bounds',
        'scope':'honest-setup supplied-pair semantics and whole nonconstant-span rank; NO bare-K/QPT secrecy',
        'toy':toys,'large_certificate':large,'assertions':ASSERT},indent=2,sort_keys=True))

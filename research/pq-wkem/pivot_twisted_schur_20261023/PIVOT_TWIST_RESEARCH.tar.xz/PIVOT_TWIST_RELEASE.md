# Extension-chart pivot-twisted SL₂–Frobenius release: exact construction, adaptive joint-slice rank theorem

**Date:** 2026-10-23 (Pacific); **live starting PR head:** `b789d4027a10486d45e6a68fcd5dd5afc25fc898`, `syscoin/PVUGC#1`, `research/pq-wkem-validation-20260918` (open/draft/unmerged at initial read). **Parent exact construction:** `research/pq-wkem/sl2_frobenius_mixing_20261023/README.md` at that SHA, Git blob `c743a80b42e613a3c827b908ae74edde2ca7ac03`; its standalone checker exact SHA-256 `51dd71b569d475e3a1cdfb3d528641e59d805609a152463c1bcafeb1b66893c1`. Schur parent `d7d7862522faf1603c0a2e6e572b03d320f56045`. This is an **honest-setup local-release component**, not a completed witness KEM or independently justified QPT secrecy assumption.

## 1. Target, source and full public output

A claim-scoped statement must include at least `(ORIGINAL Syscoin/BTC relation identity, claim/UTXO, fork/challenge branch, source/BTC anchors, observation window, destination and native verification key/context)`; `R(x,w)` denotes verification of **the ORIGINAL finite evidence**. This algebraic release component treats `R` as a pinned Boolean R1CS but does **not** construct/authenticate the actual Syscoin headers, coinbase tags, full interval or transaction graph. Neither absence of an unseen fork nor BTC best-chain membership follows from a finite witness.

Inherit the exact pinned sampled Frobenius-QAP compiler, with `F=GF(q)` of characteristic two, `E/F` a quadratic finite-field extension, public `θ∈E\F`, `n` ORIGINAL Boolean wire variables, `m` R1CS constraints, and `k=n+m`. The **public** source is `y=(z,w_1,…,w_n,ρ_0,…,ρ_(m−2))∈F^k`. There are `m−1` fixed offdomain plus `r` honestly sampled tail nodes `e`, hence `L=m−1+r`. All node forms are **source-linear**. Private earlier `SL₂(F)` mixing with the exact Booleanized Frobenius correction produces base-field forms `A_e(y),B_e(y)∈F`; sheared `C_e(y)∈E`; and `S_e(y)=s_e(ρ)+η_e(w)∈E`. Their homogeneous residual is

```
Q_e(y) = A_e(y) B_e(y) + z C_e(y) + S_e(y)^2.
```

For normalized `z=1`, QAP correctness for **every ORIGINAL satisfying Boolean witness** gives `Q_e(y)=0` for all nodes, with `y=(1,w,ρ(w))`; two different valid ORIGINAL witnesses need not share `w`, `ρ(w)`, or local state. Under the exact parent extension-separated `α_(e,i)^2 = b_(e,i)+θ e^(i−1)` (with `b_(e,i)∈F`), every nonBoolean `F`-typed normalized w violates at least `L−n+1` gates by the Reed–Solomon separation argument; every invalid Boolean source violates at least the inherited `T` nodes except the predecessor's sampled setup event. These are **SOURCE/representation semantics**, not secrecy.

**Build/Setup** (classical randomized polynomial-time *in the explicit public-matrix size*) samples the same honest coins as the pinned parent: `K←E`, independent outer `U_e←E^{N×3}`, `V_e←E^{3×N}`, private per-node `SL₂(F)` matrices, independent private Boolean shears `b_(e,i)←F`, with `N=2L+h`. **NEW:** also sample independently at each node `μ_e←E\F` uniformly by rejection from `E`, and `side_e←{A,B}` uniformly; keep these private along with the outer factors. Define

```
if side=A: π_e=z+μ_e A_e;   A*_e=A_e;         B*_e=B_e+μ_e C_e.
if side=B: π_e=z+μ_e B_e;   A*_e=A_e+μ_e C_e; B*_e=B_e.

              [ C_e   A*_e   S_e ]
 G_e(y)   =   [ B*_e  π_e     0   ]    ∈ E^{3×3}.
              [ S_e    0     π_e ]
```

**Entire public release output**, not hiding a release oracle: the same source/field/compiler metadata, exactly `k` dense E matrices

```
C_j = [j=0] K I_N + Σ_(e=1)^L U_e G_e(unit_j) V_e.
```

The matrix pencils and fixed field embeddings, all offdomain nodes, intended public checking/verification key, context binding and ceremony transcript are exposed to an attacker. The public matrices reveal correlations among *all* original-variable and quotient slices. The corresponding actual native verification key is not instantiated or correlated with K by a proven scheme here; Bitcoin endpoint, native signature and N-of-N signing graph remain unproved. The private coins are erased in the honest-erasure baseline; retained or malicious coins are explicitly excluded from the proofs.

**Encode(x,w):** check `R(x,w)=1`, construct the original normalized Frobenius-QAP quotient `ρ(w)` from the pinned compiler, emit distinct `y=(1,w,ρ(w))∈F^k`; do not read private μ/SL₂/U/V/K and do not impose a canonical ORIGINAL witness. **Recover(x,y):** reject unless x/context matches, y typed F, z=1. Form `M(y)=Σ_j y_j C_j`, solve for candidate scalars λ over E satisfying `rank_E(M(y)−λI_N)≤2L` (one constructive algorithm is finite-field characteristic polynomial/root finding followed by ranks), require the unique λ and binding to the intended verifying key and return K=λ; the checking-key relation itself is *unimplemented*. **SuppliedPairExtract(x,λ,y):** perform the same source/type/rank/context checks and output the ORIGINAL witness coordinates `w`; this extractor takes the *supplied representation* and does not extract y from a bare K, a signature, or an arbitrary QPT internal state. Full offline recovery can be expensive (matrix root finding), and the dense setup is not practical.

## 2. Proved local pivot-isometry lemma and correctness

For side A, using characteristic-two cancellation,

```
  (A_e)(B_e+μ_e C_e) + (z+μ_e A_e) C_e + S_e²
    = A_e B_e + z C_e + S_e² = Q_e(y).
```

For side B the identical equation holds with A and B interchanged. Elementary determinant expansion for the displayed 3×3 Schur gate gives **as formal polynomial identities for arbitrary projective E-valued y**:

```
             det G_e(y) = π_e(y) Q_e(y).             (1)
```

For **every** normalized `y∈F^k,z=1` and every μ∈E\F, each `A_e(y),B_e(y)∈F`. If A=0 then π=1; otherwise π=1+μ A cannot vanish since μ∉F. Similarly on side B. Hence

```
       π_e(y) ≠ 0  simultaneously for ALL normalized F-sources.  (2)
```

Consequently G_e has rank **exactly 2** if `Q_e=0` and **exactly 3** if `Q_e≠0`: the bottom-right block is `π I₂` and determinant (1) decides the third dimension. This proves unchanged all-ORIGINAL-witness same-K completeness and unchanged predecessor normalized SOURCE/representation acceptance on the **entire** typed source domain, rather than for only enumerated honest witnesses. The extension-separated nonBoolean RS distance and Boolean invalid QAP distance remain **identical**, not weakened by the new projective chart. Every source coefficient in G remains F-linear/E-linear in y as a formal linear form; thus there are no public quadratic slices.

**Nontriviality scope:** this is not the predecessor's removable `γ z` constant GL₃ gauge: old local determinant `z Q` becomes `(z+μA)Q` or `(z+μB)Q`, whose factor varies with the formal independent source coordinates. A fixed invertible left/right change of basis can only multiply the determinant by a nonzero field constant. Under formal A,z independence with μ≠0, the two entire *families of symbolic gates* cannot be related by a constant left/right gauge. Some specific degenerate R1CS instances or full outer tensor distributions could have other equivalences. **This algebra does not prove additional computational secrecy.**

## 3. Inherited simultaneous supplied-pair → ORIGINAL theorem (same exact premise)

For each fixed normalized typed y, the local gate ranks are exactly the parent ranks. Conditional on the new node chart and all existing private gate coins, **independent uniform** `U_e,V_e` turn the sum into a product of independently uniform rectangular E matrices of width `D=2L+#violated_nodes(y)`. The parent's full-honest-setup union bound over all typed normalized y and wrong λ is therefore unchanged. The exact predecessor three error terms, under its pinned sampled-node independence and compiler completeness premises, are

```
ε_bool ≤ 2^(n+1) * binom(L,T−1) * (m+T−2)^r / |F|^(r−T+1)
ε_rank ≤ 16(h+1) * |F|^(k−1) * |E|^(−h²)
ε_wrong < 4 * |F|^(k−1) * |E|^(1−h²).
```

With `|F|=2^128`, `|E|=2^256`, `n=11,000`, `m=16,000`, `k=27,000`, `r=375`, `L=16,374`, `T=234`, `h=117`, `N=32,865`, the **previously checked** setup error is `<2^-133` for **the supplied `(λ,y)` acceptance statement only**, not K secrecy. Except on the setup-bad event, every rank-accepted supplied normalized `(λ,y)` has `λ=K` and `w` is a valid ORIGINAL witness. The result applies to classical outputs selected adaptively after arbitrary full-tensor quantum processing because the good setup event is simultaneous over all classical typed y and λ; it does not provide a quantum extractor from an algorithm outputting only K.

## 4. NEW: full-joint nonconstant coefficient-space rank metric (not only quotient-only selection)

The prior 3×3 Schur construction had a restricted masking lemma for functionals chosen without inspecting C0/nonquotient coefficients. Here we prove a different, **simultaneous setup statement for all linear combinations of full public nonconstant slices**, including mixtures chosen *after* inspecting the entire tensor. It is a structural rank result, not K hiding or a low-rank-recovery-to-witness reduction.

For any `z=0`, write `y=(0,w,ρ)`. The private extension shear satisfies exactly

```
 S_e(y)² = s_e(ρ)² + Σ_i b_(e,i) w_i² + θ Σ_i e^(i−1) w_i².     (3)
```

If `w∈F^n` is nonzero, the base-field bracket in (3) cannot cancel the θ component. Polynomial `P_w(t)=Σ_i w_i² t^(i−1)∈F[t]` has degree≤n−1, is nonzero, and has at most n−1 distinct roots in F. Therefore `S_e(y)≠0` at **≥a_w=L−n+1** of the L distinct nodes, for EVERY F-typed ρ, regardless of μ, orientations, SL₂, bmask. If w=0 and **ρ∈E^(m−1) is arbitrary, nonzero**, the pinned quotient form is `s_e(ρ)=sqrt(Z(e)) Σ_(j=0)^(m−2) ρ_j sqrt(e)^j`, with `Z(e)≠0` at all offdomain nodes. Since sqrt is a bijection, the nonzero polynomial has ≤m−2 roots: `S_e≠0` at **≥a_q=L−m+2** nodes. Crucially, this quotient assertion is over E-valued ρ, not only F-valued.

For ANY 3×3 chart G, if `S_e≠0`, its rank is at least two: either `π≠0` and bottom-right `πI₂` has rank 2, or `π=0` and the rows/columns {1,3} minor has determinant `S_e²≠0`. Therefore the sum of exact local ranks `d=Σ_e rank G_e(y)` is ≥`t_w=2a_w` or ≥`t_q=2a_q`, for the respective source classes. (For z=0 these are different from normalized rank-acceptance claims; no witness extraction is being asserted.)

**Independent-factor lemma (exact finite-field distribution):** Condition on every local rank and secret gate; select invertible row and column transformations of that fixed gate to isolate its rank-r identity block. Uniform independent U_e,V_e remain uniform under those transformations. Concatenating all L blocks yields `M(y)=Σ_e U_e G_e(y) V_e = AB` **in distribution**, with A uniform in `E^(N×d)` and B independently uniform in `E^(d×N)`, for any d≥t, including d>N. The first t columns of A are linearly independent except probability `<2|E|^(−(N−t+1))`; conditional on `rank A≥t`, the rank of AB dominates that of a uniform t×N matrix, whose short-rank probability obeys the same bound. Consequently

```
         Pr[rank_E M(y) < t | fixed y, gate coins] < 4 |E|^(−(N−t+1)).    (4)
```

There are fewer than `2|F|^(k−2)` F-projective vectors with `z=0,w≠0` and fewer than `2|E|^(m−2)` E-projective quotient-only vectors with `z=0,w=0,ρ≠0`. Nonzero scalar rescaling never changes the rank, so union (4) over these two disjoint sets yields a **single honest-setup event** with failure probability

```
ε_joint < 8 |F|^(k−2) |E|^(−(N−t_w+1))
        + 8 |E|^(m−2) |E|^(−(N−t_q+1)).                    (5)
```

With the pinned large illustrative parameters, `a_w=5,375`, `t_w=10,750`, `a_q=376`, `t_q=752`; `N−t_w+1=22,116`, `N−t_q+1=32,114`. Because `|F|=|E|^(1/2)`, the two setup-tail upper bounds are `<2^(−2,205,949)` and `<2^(−4,125,693)` respectively, and their sum `<2^(−2,205,948)`.

**Exact conclusion:** except on this event, simultaneously **every F-typed nonconstant public coefficient linear combination with at least one ORIGINAL-variable component has rank ≥10,750**, and **every nonzero arbitrary-E quotient-only coefficient combination has rank ≥752**. These may be selected adaptively **after** observing all public slices, all correlated public verification material and conducting a quantum computation, provided the final coefficient vectors are in the expressly typed classes. The theorem is unconditional over independent honest outer factor coins; this is a *rank-metric statement only*. It is **not** pseudorandomness, hiding of K, security against E-typed w/quotient joint mixtures, C0−λI or nonlinear polynomial/joint-tensor processing, or a reduction from a bare-key output. In particular original-variable combinations over E are not covered; the θ-separated component can then mix with other E terms.

## 5. Joint tensor expression and exact unresolved equation

For each local gate let column vectors `u1,u2,u3` be U's columns and `v1,v2,v3` be V's rows, and set `Z=u1v1`, `X=u1v2`, `Y=u2v1`, `D=u2v2+u3v3`, `J=u1v3+u3v1`. The full source-linear public local contribution, after the new private orientation, is

```
side A: C(Z+μY)+A(X+μD)+B Y+S J+z D,
side B: C(Z+μX)+A X+B(Y+μD)+S J+z D.
```

The shift `K I` appears **only in the public z0 slice**. Unlike the parent, D now also appears inside private μ-weighted ORIGINAL-variable slices. This is the exact new joint correlation to analyze next. A complete full-public-QPT release reduction would have to show that an arbitrary algorithm recovering **K alone** or forging the corresponding native Bitcoin signature yields an ORIGINAL witness or breaks a **separately established** PQ assumption, even with all coefficient matrices, checking-key correlations, quantum auxiliary advice/superposition queries, related capsules and malicious setup where specified. Neither (1)–(5) nor earlier SOURCE binding does that. The release matrix ensemble could still leak K through nonlinear tensor synchronization; hard/true and false instances are unproved.

## 6. Sizes, reproducibility and explicit next proof obligation

No new public matrices/source variables/gates: `k=27,000`, `N=32,865`, E entries 32 bytes; **exact dense package** `27,000·32,865²·32 = 933,213,506,400,000 bytes (~0.933 PB)`, excluding code/node/checking metadata. Added private sampling is L E\F field elements (~523,968 bytes uncompressed at 32 bytes each) plus 16,374 orientation bits (~2,047 bytes). No public storage improvement and **no practical size claim**. This release is a classical polynomial-time explicit algorithm in the enormous matrix output size; it is not a deployable efficient implementation. The standard witness-to-pivot-correctness algorithm is independent of all these hidden sampled private coins.

`pivot_twist_check.py` is a runnable Python 3.10+ checker (using **only** `sl2_frobenius_mix_check.py` from the exact pinned parent). Reproduction: `python pivot_twist_check.py > out.json` and byte compare to `pivot_twist_validation.json`. The checker actually builds two GF(16)/GF(256) synthetic ORIGINAL witnesses, their distinct three-row ORIGINAL R1CS QAP sources, all public coefficient matrices, and publicly recovers same K. It exhaustively verifies 257 E-projective quotient-only directions and 4,369 F-projective mixed directions per seed with two honest setup seeds; 40,108 assertions, repeated twice with byte-identical output. Tiny test parameters DO NOT validate quantum security, real 128-bit security, malicious ceremony or native Bitcoin scripts. The large theorem certificate is symbolic/integer arithmetic and relies on the full exact listed distribution assumptions.

**Next indispensable reduction:** characterize the **E-valued original+quotient** polynomial pencil together with `C0−λI` under the entire correlated (A/B)-oriented matrices, *including independent native verification key*. Establish either an independently motivated standard-QPT reduction (not an assumption restating WE) to guarantee K hiding/extractability or an explicit repair preserving the typed rank and all-original semantics. Do not mistake the joint typed rank lower bound for a solution. A practical design must also compress the ~0.933 PB output securely, prove malicious N-of-N ceremony with abort/retained-coin safeguards, connect to native post-quantum verification conditional on P2MR/SLH availability, and prove timely 1-of-N fork-evidence veto inclusion. Bitcoin must not verify arbitrary NP evidence onchain.

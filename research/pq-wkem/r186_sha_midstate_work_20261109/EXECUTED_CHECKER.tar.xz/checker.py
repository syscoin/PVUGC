#!/usr/bin/env python3
"""R186: source-midstate hypothesis with genuine SHA256d over synthetic 80-byte headers.

All parent header fields, targets, and work admission are TEST ONLY.  THIS IS NOT
an ORIGINAL Syscoin/Bitcoin AuxPoW proof, native signature, or PQ security test.
"""
import hashlib, struct, json
from collections import Counter

Q = Counter()

def check(b: bool, label: str):
    if not b:
        raise AssertionError(label)
    Q[label] += 1

def H(label: bytes, *parts: bytes) -> bytes:
    z = b'R186-HASH-V1' + len(label).to_bytes(2,'big') + label
    z += b''.join(len(p).to_bytes(4,'big')+p for p in parts)
    return hashlib.sha256(z).digest()

def dh(header: bytes) -> bytes:
    assert len(header) == 80
    return hashlib.sha256(hashlib.sha256(header).digest()).digest()

def xor(a, b):
    assert len(a) == len(b)
    return bytes(x^y for x,y in zip(a,b))

def header_prefix(seed: int) -> bytes:
    # 4-byte version + 32 prev hash + 32 simulated merkle root + 4 time + 4 bits
    return (struct.pack('<I',0x20000000) + H(b'parent-prev',bytes([seed])) +
            H(b'coinbase-merkle',bytes([seed])) + struct.pack('<II',1750000000,0x1f0fffff))

def mine_toy(prefix: bytes, target_bits:int=12, want:int=8, bound:int=1<<19):
    assert len(prefix)==76
    hit=[]
    for nonce in range(bound):
        hdr = prefix+struct.pack('<I',nonce)
        digest=dh(hdr)
        # TOY big-endian threshold. Actual Bitcoin checks are different and are NOT implemented.
        if int.from_bytes(digest,'big') < (1 << (256-target_bits)):
            hit.append((nonce,hdr,digest))
            if len(hit)>=want:
                break
    assert len(hit)==want
    return hit

def experiment():
    context = b'fake-bridge-slot-1'
    K=H(b'precommitted-capability-key',context)
    for seed in range(3):
        prefix=header_prefix(seed)
        hits=mine_toy(prefix)
        hashes=[row[2] for row in hits]
        check(len(set(hashes))==len(hits),'distinct_valid_work_digests')
        check(len(set(n for n,_,_ in hits))==len(hits),'unique_nonces')
        for nonce,header,digest in hits:
            check(len(header)==80 and dh(header)==digest,'actual_sha256d_80bytes')
            check(int.from_bytes(digest,'big') < (1 << 244),'toy_target_only')

        # Shared pre-work state/prefix is knowable to the attacker BEFORE mining.
        public_common=H(b'public-prefix-midstate-standin',prefix)
        enc_shared=xor(K,H(b'pad',public_common))
        adversary_no_work=xor(enc_shared,H(b'pad',public_common))
        check(adversary_no_work==K,'shared_pad_direct_recovery_without_work')
        # The same applies if the pad is based only on the fixed zero bits of the digest.
        enc_workclass=xor(K,H(b'pad',b'zero-prefix-12'))
        check(xor(enc_workclass,H(b'pad',b'zero-prefix-12'))==K,
              'work_prefix_class_is_public')

        # Mining changes the final hash. One precomputed winning-header pad opens
        # only one witness, not ALL valid work certificates for one semantic child.
        enc_first=xor(K,H(b'full-work-digest',hashes[0]))
        decs=[xor(enc_first,H(b'full-work-digest',d)) for d in hashes]
        check(decs[0]==K,'one_selected_work_certificate_opens')
        for j in range(1,len(decs)):
            check(decs[j]!=K,'other_qualifying_work_certificate_fails_common_key')

        # To support this fixed synthetic prefix by rows, setup must enumerate
        # different winning solutions and bind each witness-specific correction.
        corrections={nonce: xor(H(b'full-work-digest',hashes[0]),
                                H(b'full-work-digest',digest))
                     for nonce,_,digest in hits}
        for nonce,_,digest in hits:
            obtained=xor(enc_first, corrections[nonce])
            check(xor(obtained,H(b'full-work-digest',digest))==K,
                  'per_certificate_correction_recovers')
        check(len(corrections)==len(hits),'one_row_per_observed_work_solution')

        # Child identity (same Syscoin child for these eight parent-work choices)
        # is NOT a fork. Any KDF of its fixed known hash is also public.
        child=H(b'same-semantic-child',context,bytes([seed]))
        public_child_pad=H(b'pad',child)
        enc_child=xor(K,public_child_pad)
        check(xor(enc_child,public_child_pad)==K,
              'same_child_hash_pad_publicly_openable')

        # Repair hypothesis: setup hides a preselected 256-bit opening s in a
        # coinbase/body commitment; miners see a header commitment to the body.
        # Hash commitment does not magically reveal s when a PoW nonce is found.
        s=H(b'source-secret-opening',context,bytes([seed]))
        body=b'coinbase/fully-committed-body/'+s
        committed=hashlib.sha256(hashlib.sha256(body).digest()).digest()
        cb_prefix=(struct.pack('<I',0x20000000)+H(b'parent-prev',bytes([seed]))+
                   committed+struct.pack('<II',1750000000,0x1f0fffff))
        mined=mine_toy(cb_prefix,want=1)[0]
        check(dh(mined[1])==mined[2] and len(cb_prefix)==76,
              'header_pow_can_commit_to_hidden_coinbase_hash')
        enc_source=xor(K,H(b'pad',s))
        check(xor(enc_source,H(b'pad',s))==K,
              'coinbase_opening_recovers_only_if_disclosed')
        # If the body is given to miner/readers to make the complete source
        # valid, its actual embedded opening is directly readable before PoW.
        check(body[-len(s):]==s and xor(enc_source,H(b'pad',body[-32:]))==K,
              'miner_with_complete_coinbase_learns_source_pad_early')
        # If only the root is sent, the exact body needed for Merkle/inclusion
        # must STILL be supplied by a holder. The setup's hash commitment is
        # not a witness and cannot substitute for the missing coinbase body.
        check(hashlib.sha256(hashlib.sha256(body).digest()).digest()==committed,
              'full_coinbase_preimage_required_to_authenticate_inclusion')
    return {'run':'R186-SMCT-20261109','tests':dict(sorted(Q.items())),
            'assertions':sum(Q.values()),'header_templates':3,
            'winning_headers_per_template':8, 'toy_target_prefix_bits':12,
            'status':'No original-source compiler; pre-work common digest public; final-work digests differ',
            'source_sha256':hashlib.sha256(open(__file__,'rb').read()).hexdigest()}

if __name__=='__main__':
    print(json.dumps(experiment(),sort_keys=True,indent=2))

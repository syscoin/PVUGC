#!/usr/bin/env python3
"""Deterministic GF(16)->GF(256) regression of extension-separated Boolean shearing.
Toy synthetic source, not the full sampled-QAP, QPT security, or real-world parameters.
"""
import hashlib, itertools, json, random, math
from pathlib import Path

F_POLY=0x13

def f_mul(a,b):
    r=0
    for _ in range(4):
        if b&1:r^=a
        b>>=1;a<<=1
        if a&16:a^=F_POLY
    return r
FM=[[f_mul(a,b) for b in range(16)] for a in range(16)]
def f_pow(a,n):
    r=1
    while n:
        if n&1:r=FM[r][a]
        a=FM[a][a];n//=2
    return r

def f_trace(a):
    v=a;r=0
    for _ in range(4):
        r^=v;v=FM[v][v]
    assert r in (0,1)
    return r
KAPPA=next(a for a in range(1,16) if f_trace(a)==1)
# E=F[u]/(u^2+u+KAPPA) where KAPPA has F/2 trace 1.
def e_mul(a,b):
    a0,a1=a&15,a>>4;b0,b1=b&15,b>>4
    p=FM[a1][b1]
    return FM[a0][b0]^FM[p][KAPPA] | ((FM[a0][b1]^FM[a1][b0]^p)<<4)
EM=[[e_mul(a,b) for b in range(256)] for a in range(256)]
def e_pow(a,n):
    r=1
    while n:
        if n&1:r=EM[r][a]
        a=EM[a][a];n//=2
    return r
EINV=[0]+[e_pow(a,254) for a in range(1,256)]
assert all(EM[a][EINV[a]]==1 for a in range(1,256))
assert all(e_pow(a,16)==a for a in range(16))
assert all(f_trace(a)==0 or f_trace(a)==1 for a in range(16))
assert all(e_pow(a,256)==a for a in range(256))

n=2; L=5; h=2; N=2*L+h; k=4
E_POINTS=[1,2,3,4,5]
THETA=16 # u outside F
ASSERTS=0

def ensure(cond):
    global ASSERTS
    ASSERTS+=1
    if not cond:raise AssertionError(f'assertion {ASSERTS} failed')

def rank(A):
    a=[row[:] for row in A]
    rr=0
    for c in range(len(a[0])):
        p=next((r for r in range(rr,len(a)) if a[r][c]), None)
        if p is None:continue
        a[rr],a[p]=a[p],a[rr]
        inv=EINV[a[rr][c]]
        for j in range(c,len(a[0])):a[rr][j]=EM[inv][a[rr][j]]
        for r in range(rr+1,len(a)):
            v=a[r][c]
            if v:
                for j in range(c,len(a[0])):a[r][j]^=EM[v][a[rr][j]]
        rr+=1
        if rr==len(a):break
    return rr

def gate(e, y, alpha, gamma):
    z,w1,w2,rho=y
    a=w1^w2;b=z;d=z;c=FM[e][rho];s=0
    eta=EM[gamma][z]
    beta=EM[EM[gamma][gamma]][z]
    for j,wi in enumerate((w1,w2)):
        eta ^= EM[alpha[j]][wi]
        beta ^= EM[EM[alpha[j]][alpha[j]]][wi]
    v=s^eta;cb=c^beta
    return [[0,a,d,v],[a,0,v,cb],[d,v,0,b],[v,cb,b,0]]

def pf(G):
    return EM[G[0][1]][G[2][3]]^EM[G[0][2]][G[1][3]]^EM[G[0][3]][G[1][2]]

def matmul(A,B):
    p=len(B); m=len(A);n2=len(B[0]); C=[[0]*n2 for _ in range(m)]
    for i in range(m):
        for l in range(p):
            if A[i][l]:
                v=A[i][l]; b=B[l]
                for j in range(n2):C[i][j]^=EM[v][b[j]]
    return C

def add(A,B):
    return [[a^b for a,b in zip(row,col)] for row,col in zip(A,B)]

def zero(m,n):return [[0]*n for _ in range(m)]

def test_seed(seed):
    rng=random.Random(seed)
    gammas=[rng.randrange(256) for _ in range(L)]
    # alpha^2 = b_(e,i)+theta*e^(i) for i=0,1; b private in F
    alphas=[];bs=[]
    for e in E_POINTS:
        vals=[];bvec=[]
        for i in range(n):
            bb=rng.randrange(16);bvec.append(bb)
            target=bb^EM[THETA][f_pow(e,i)]
            aa=e_pow(target,128) # square-root in GF(256)
            ensure(EM[aa][aa]==target)
            vals.append(aa)
        alphas.append(vals);bs.append(bvec)
    U=[[[rng.randrange(256) for _ in range(4)] for _ in range(N)] for e in range(L)]
    V=[[[rng.randrange(256) for _ in range(N)] for _ in range(4)] for e in range(L)]
    K=rng.randrange(1,256)
    C=[]
    for j in range(k):
        yy=[1 if x==j else 0 for x in range(k)]
        M=zero(N,N)
        for i,e in enumerate(E_POINTS):
            M=add(M,matmul(matmul(U[i],gate(e,yy,alphas[i],gammas[i])),V[i]))
        if j==0:
            for i in range(N): M[i][i]^=K
        C.append(M)
    def cy(y):
        M=zero(N,N)
        for j,v in enumerate(y):
            if v:
                for i in range(N):
                    for l in range(N): M[i][l]^=EM[v][C[j][i][l]]
        return M
    def shifted(M,key):
        A=[r[:] for r in M]
        for i in range(N):A[i][i]^=key
        return A
    # Verify all base normalized inputs, including every non-Boolean and quotient.
    counts={'valid':0,'invalid_boolean':0,'nonboolean':0}
    for w1,w2,rho in itertools.product(range(16), repeat=3):
        y=(1,w1,w2,rho)
        good=(w1==w2 and w1 in (0,1) and rho==0)
        boolean=(w1 in (0,1) and w2 in (0,1))
        vs=0
        for i,e in enumerate(E_POINTS):
            G=gate(e,y,alphas[i],gammas[i]);p=pf(G)
            d1=FM[w1][w1]^w1;d2=FM[w2][w2]^w2
            t=w1^w2^FM[e][rho]
            check=t^EM[EM[alphas[i][0]][alphas[i][0]]][d1]^EM[EM[alphas[i][1]][alphas[i][1]]][d2]
            ensure(p==check)
            # F^2 split: theta component equals evaluation of polynomial delta1+e*delta2
            code=d1^FM[e][d2]
            ensure((p>>4)==code)
            if p!=0:vs+=1
        if good:
            counts['valid']+=1;ensure(vs==0)
        elif boolean:
            counts['invalid_boolean']+=1;ensure(vs>=4)
        else:
            counts['nonboolean']+=1;ensure(vs>=L-n+1)
    ensure(counts['valid']==2)
    for w1,w2 in [(0,0),(1,1)]:
        M=cy((1,w1,w2,0));ensure(rank(shifted(M,K))<=2*L)
        for other in range(256):
            if other!=K:ensure(rank(shifted(M,other))>2*L)
    for w1,w2,rho in [(0,1,0),(1,0,1),(2,2,0),(7,9,3),(15,0,4)]:
        M=cy((1,w1,w2,rho))
        for trial in [K, K^1, K^7, K^128]:ensure(rank(shifted(M,trial))>2*L)
    return {'seed':seed,'K':K,'points':E_POINTS,'field':'GF(16)[u]/(u^2+u+%d)'%KAPPA,'counts':counts}

def large_certificate():
    base_bits=128;extension_bits=256;n=11000;m=16000;k=n+m
    r=237;T=h=117;L=m-1+r;N=2*L+h;q=1<<base_bits
    assert L-n+1>=T
    # Exact integer, stronger than a float log upper bound.
    A=m+T-2; err_boolean_num=(1<<(n+1))*math.comb(L,T-1)*pow(A,r)
    err_boolean_den=pow(q,r-T+1)
    ensure(err_boolean_num*(1<<135)<err_boolean_den)
    ensure(16*(h+1)*pow(q,k-1)*(1<<135)<pow(q,2*h*h))
    ensure(4*pow(q,k+1)*(1<<135)<pow(q,2*h*h))
    # distinct nodes, robust bound conditions
    ensure(q>=2*r*(2*m-2+r));ensure(q>=m+L);ensure(2*T>=2*h)
    return {'q_bits':base_bits,'outer_field_bits':extension_bits,'n':n,'m':m,'k':k,'r':r,'T':T,'h':h,'L':L,'N':N,'storage_bytes':k*N*N*32,'each_error_lt':'2^-135','sum_error_lt':'3*2^-135 < 2^-133','former_bytes':2689702869600000,'saved_percent':round(100*(1-(k*N*N*32)/2689702869600000),6)}

if __name__=='__main__':
    results=[test_seed(s) for s in (197,233,991)]
    out={'scheme':'extension-separated-boolean-shear','proof_scope':'honest-setup supplied-pair semantic, not K secrecy','toy':results,'large':large_certificate(),'assertions':ASSERTS}
    print(json.dumps(out,sort_keys=True,indent=2))

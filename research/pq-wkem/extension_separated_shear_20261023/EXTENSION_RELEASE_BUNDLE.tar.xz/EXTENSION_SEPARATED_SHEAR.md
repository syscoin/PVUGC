# Extension-separated Boolean–Frobenius rank release

**23 October 2026 — constructive, SCOPED result.** This continues `syscoin/PVUGC#1` from exact head `6cf8de49d07a79e798ca953b146fd63f2d767f9f`, using the exact previous Boolean-shear bundle `research/pq-wkem/boolean_frobenius_shear_20261023/SOURCE_BUNDLE.tar.xz` (Git blob `6bef29d8f5c6c2f1d5e101f66779846fb88895cc`) and robust-distance theorem `research/pq-wkem/robust_distance_20261023/ROBUST_DISTANCE_RANK_SELECTION.md` (Git blob `0f3eccd2dbddcf363099028db98d5b041478adff`). It introduces **no WE, iO, RIO, witness-key secrecy or QPT hardness assumption**. It proves a new deterministic Booleanity/release-rank interface and a smaller exact public-matrix cost for the SAME **honest-setup supplied-pair** security scope. It does NOT establish arbitrary key-only secrecy, native forgery extraction, a practical package, or a deployable WKEM.

## Constructive delta

The predecessor uses one field `F=GF(2^256)` for SOURCE and the public 4×4 matrices. Its independent private Boolean shears make non-Boolean node Pfaffians random, requiring a simultaneous union bound over `q^(n+m-1)` non-Boolean sources, `L > n+m`, `r=11816`, `N=55795`, and 2.6897028696 PB of dense matrices.

**New:** use a **base SOURCE field** `F=GF(q)` and a quadratic extension `E/F`, with `|E|=q²` and `K∈E`. Encode private shears into a *known extension-component Reed–Solomon distance code*. For every normalized SOURCE `y∈F^k`, a non-Boolean `w` now deterministically violates at least `L-n+1` independent local Pfaffians **regardless of the private shear coins and quotient**. The Boolean branch admits a smaller, exact robust-distance union bound of `2^n` original assignments, rather than `q^n`. The smaller `L` and extension-field rank bounds give a new honest-setup package at `q=2^128`, `|E|=2^256`, `r=237`, `h=T=117`, `L=16236`, `N=32589`, and **917,605,083,744,000 bytes** of public coefficients, a **65.884519% reduction** from the prior 2.6897 PB. This is **0.917605 decimal PB, still NOT practical**.

This delta is NOT a release-key hiding proof. The new base/extension structure is visible to attackers and may create new algebraic attacks; none is ruled out by rank soundness. A valid ORIGINAL witness still recovers the same 256-bit field capability `K` across all witnesses. Every accepted classical supplied pair must use a normalized SOURCE in the publicly specified subfield `F` (a type check), and the claim remains conditioned on **honest generation** of outer factors, samples and setup binding. Arbitrary attackers of the raw E-valued public tensor can use E-linear combinations; the required arbitrary-recovery-to-ORIGINAL theorem remains missing.

## Exact Setup/Build / Encode / Recover and full public output

In the CONDITIONAL N-of-N ceremony, choose the claim-scoped `K←E` without publishing it, derive the correctly bound native verification object under the assumed signing interface, and commit **that object plus the entire statement x BEFORE sampling any fixed-independent random tail nodes**. No implementation or proof of this ceremony is claimed. A statement `x` fixes an ORIGINAL Boolean R1CS relation with `n` independent original Boolean SOURCE coordinates `w∈F^n`, `m` rows and `k=n+m` homogeneous projective SOURCE coordinates `y=(z0,w,ρ)∈F^k`; `ρ∈F^(m−1)` is the unrestricted QAP quotient. It binds relation identity, claim/UTXO, branch, SYS/BTC anchors/window/fork-evidence rules, replay domain, native intended verification key and preauthorized graph. No later source/relation selection may change the original row set. Let `t_1,…,t_m` be its original interpolation nodes; choose `m−1` distinct fixed off-domain nodes `b_i`, then draw `r` further distinct uniform off-domain nodes **after the entire statement is committed**. Enumerate all `L=m−1+r` nodes `e`. The source-linear node forms `a_e(y),b_e(y),c_e(y),d_e(y)=z0,s_e(y)` are the exact prior normalized Frobenius-QAP forms; for normalized SOURCE, `t_e(y)=a_e b_e+d_e c_e+s_e²∈F` equals the QAP numerator evaluated at `e`.

Choose a *public* `θ∈E\F` and the public length-`L`, dimension-`n` Reed–Solomon generator `c_{e,i}=e^(i−1)∈F`, `i=1,…,n`. At every node independently sample private `γ_e←E`, `b_{e,i}←F` and select the unique field square root `α_{e,i}∈E` satisfying

`α_{e,i}² = b_{e,i}+θ·e^(i−1)`.                         (1)

Define SOURCE-linear `η_e(y)=γ_e z0+Σ_i α_{e,i}w_i` and `β_e(y)=γ_e² z0+Σ_i α_{e,i}²w_i`. Use the predecessor's same 4×4 alternating gate, now **over E**:

```
G_e(y) = [ 0       a       d       s+η ]
         [ a       0       s+η     c+β ]
         [ d       s+η     0       b   ]
         [ s+η     c+β     b       0   ].
```

Set `D=2L`, `N=D+h`, and independently sample private uniform `U_e←E^(N×4)`, `V_e←E^(4×N)`. Use the previously generated claim-specific **uniform `K∈E`**, whose native verification-object binding is already part of the committed x. Publish all `k` full matrices `C_j = [j=0]K I_N + Σ_e U_e G_e(e_j) V_e ∈ E^(N×N)` (where `e_j` is the j-th standard SOURCE basis vector). Publish **also** the complete statement, R1CS/source encoding, F and E descriptions and subfield embedding, original/fixed/tail node locations, `θ`, code convention, native public verifying key, claim/epoch/replay binding, and the full funding/ceremony transcript that future proofs must authenticate. Do NOT publish secret factors/masks, builder coins or `K`. This remains an *unimplemented, honest-erasure N-of-N setup baseline*: no malicious-secure MPC, keyless retained-coin Build, native Bitcoin SLH key-path, or abort/funding graph is proved here.

`Encode(x,w)`: For **every** ORIGINAL valid Boolean witness `w`, compute unique `H_z=(A_z B_z+C_z)/Z` with degree at most `m−2`, take componentwise unique square roots of its coefficients in `F` to produce `ρ`, output `y=(1,w,ρ)∈F^k`. Valid w may differ arbitrarily; no canonical w, common input preimage or equal intermediate state is imposed.

`Recover(x,y)`: Parse `y` as **F SOURCE** and reject if `y0≠1` or any coordinate fails the public base-field membership test. Compute `C(y)=Σ_j y_j C_j` over `E`, factor its characteristic polynomial over `E` (or use verified probabilistic spectral routines), and return the unique field root `λ` with `rank_E(C(y)−λI_N)≤D`; verify the intended native verification-key binding. Every correct encoded original witness returns the identical field capability `K` (not a native signature). A native SLH-DSA-like 256-bit signing-seed interpretation and conditional P2MR/graph are separate, unproved endpoints, not deployed Bitcoin features.

`SuppliedPairExtract(x,λ,y)`: Require `λ∈E`, `y∈F^k`, `y0=1` and `rank_E(C(y)−λI_N)≤D`; return original `w∈F^n`. The following theorem makes it Boolean, satisfying ORIGINAL `R(x,w)=1`, with the exact correct `λ=K`, except on a bounded honest-setup bad event. **The extractor is not an algorithm for an arbitrary bare K, native signature, arbitrary proof, or quantum output.**

## Lemma A — exact no-cancellation Booleanity from extension separation (deterministic)

For any normalized `y=(1,w,ρ)∈F^k`, the characteristic-two Pfaffian identity of the gate gives

```
pf(G_e(y)) = t_e(y) + Σ_i α_{e,i}²·δ_i
           = [t_e(y)+Σ_i b_{e,i}δ_i] + θ·P_δ(e),
δ_i=w_i²+w_i ∈F,       P_δ(T)=Σ_i δ_i T^(i−1)∈F[T].       (2)
```

The two bracketed components lie in **disjoint F-subspaces** `F` and `θF` of `E`. Thus `pf(G_e)=0` forces `P_δ(e)=0` (and the bracketed F part zero), regardless of all private `b,γ`. If `w` is non-Boolean, then some `δ_i≠0`, so `P_δ` is a nonzero polynomial of degree at most `n−1`. Among L distinct F-nodes it has at most `n−1` roots. Therefore for **every** normalized non-Boolean `y∈F^k`, *simultaneously and deterministically*,

`v(y) := #{e: pf(G_e(y))≠0} ≥ L−n+1`.                 (3)

This does not use random masks, a union bound, a short/canonical SOURCE, or secrecy of θ; it holds for **any** private F-components of shears. For Boolean `w_i∈{0,1}`, all δ vanish, `pf(G_e)=t_e(y)` exactly; `G_e` contains `d=z0=1`, so it has rank exactly 2 if pf=0 and rank 4 otherwise. Consequently all valid ORIGINAL witnesses preserve the same rank `2L` and same `K` for every setup. **Important limitation:** this is an E-gate theorem on `F`-typed SOURCE values, not a promise that arbitrary E-typed evaluations of the public tensor are harmless. Accepting E-typed sources would invalidate the separation argument and is explicitly forbidden by Recover/Extract.

## Lemma B — Boolean-only robust sampled-QAP distance (improved count)

Fix a normalized **Boolean** original `w∈{0,1}^n`. For any quotient `ρ∈F^(m−1)`, let the exact prior polynomial `F_{w,H}(T)=A_z(T)B_z(T)+C_z(T)+Z(T)H(T)` have degree at most `2m−2`. By the pinned Frobenius source theorem, `F_{w,H}≡0` iff `R(x,w)=1` and `H` is the **unique correct** quotient. Every other source has a nonzero polynomial.

As in the predecessor's exact Lemma 1, fix a support `S` of `s<T` violations among the `m−1` fixed off-domain nodes. Evaluations of `H` at all fixed nodes are a bijective F-linear map, hence **at most `q^s`** quotient choices for the fixed w and support S. Each resulting nonzero polynomial has `m−1−s` known fixed roots and at most `A=m+T−2` possible additional tail roots. Let `d=q−2m+2−r>0`, assume `A<d`, `q≥2r(2m−2+r)`, and choose `1≤T≤r`. The probability, for a *fixed* source with s fixed-node violations, of at most `T−1−s` tail violations is bounded by `binom(r,T−1−s)(A/d)^(r−T+1+s)`.

There are **2^n, not q^n**, Boolean original assignments, and all possible wrong quotients are included by the q^s factor. Summing on s and applying exactly the predecessor's Vandermonde and finite-population inequalities gives

```
ε_Bool ≤ 2^n Σ_{s=0}^{T−1} binom(m−1,s) q^s binom(r,T−1−s)
                    · (A/d)^(r−T+1+s)
       ≤ 2^n q^(−r+T−1)(q/d)^r A^r binom(L,T−1)
       ≤ 2^(n+1) binom(L,T−1) A^r / q^(r−T+1).         (4)
```

This is an **honest, post-statement tail-node** setup probability, simultaneous over all **invalid normalized Boolean** `(w,ρ)` even if chosen after public disclosure. Do not apply the 2^n count to arbitrary F-valued or non-Boolean w; those are covered instead by deterministic Lemma A. The q^s enumeration is essential: quotient coordinates are **not** assumed Boolean, short or canonical. No QPT extraction or rewinding is used.

## Theorem C — simultaneous supplied-pair ORIGINAL extraction and correct field key

On the complement of the bad event in (4), every invalid normalized Boolean SOURCE has at least T rank-4 local gates. By (3) every non-Boolean SOURCE has at least `L−n+1` such gates, with no bad event. Assume `L−n+1≥T` and `h≤T`. Thus any invalid normalized `y∈F^k` has `v(y)≥T`, while every correct encoded original witness has `v(y)=0`.

For each fixed y and private gate coins, direct summation and independent **uniform E**-valued outer factors imply `C(y)−K I_N` has exactly the distribution `A_R B_R` for independent uniform `A_R∈E^(N×R)`, `B_R∈E^(R×N)`, `R=2L+2v(y)`. For invalid y: `R≥D+2T≥N+h`. Let `Q=|E|=q²`. The predecessor's elementary rectangular matrix bound over field E (constant `γ_Q<4`) gives

`Pr[rank_E(C(y)−KI_N)≤D] <16(h+1) Q^(−h²)`.

Union over all `<q^(k−1)` normalized **base-field** source values gives

`ε_rank ≤ 16(h+1) q^(k−1) Q^(−h²)`.               (5)

For any wrong scalar `λ∈E`, the predecessor's fixed-h-subspace argument (valid over E) gives probability at most `4Q^(−h²)` for a fixed normalized y. Union over y and at most `Q−1` wrong λ gives

`ε_wrong < 4q^(k−1) Q^(1−h²)`.                   (6)

Therefore, over correctly committed fresh tail nodes and independent **honest** outer factors, except with total probability at most `ε_Bool+ε_rank+ε_wrong`, EVERY publicly rank-accepted classical normalized `(λ∈E,y∈F^k)` has `λ=K` and `R(x,w)=1`, including an adaptively selected pair after full inspection of the public checking key, coefficient matrices, auxiliary/public oracle evaluations and other information. The setup event is **pointwise universal** for such pairs, so an arbitrary QPT computation producing a classical accepted pair does not require quantum extraction or random-oracle rewinding. This does **not** imply any black-box extraction from a stand-alone field key K or valid signature, and is **not** a quantum key-hiding theorem. Setup coins or checking keys correlated with malicious setup are outside the uniform outer-factor premise; honest setup can be assumed public to attacker for this *soundness* event, not for confidentiality.

## Concrete exact inequalities, size and tested evidence

At base `q=2^128`, extension `Q=2^256`, take `n=11000`, `m=16000`, `k=27000`, `r=237`, `L=16236`, `T=h=117`, `D=32472`, `N=32589`. Then `L−n+1=5237≥T`, and the exact integer checker proves all three inequalities **without floating-point approximation**:

```
[2^(n+1) · binom(L,T−1) · (m+T−2)^r]·2^135 < q^(r−T+1)
[16(h+1)·q^(k−1)]·2^135                      < Q^(h²)
[4·q^(k+1)]·2^135                           < Q^(h²)
```

Hence every term in Theorem C is <2^(−135), total <3·2^(−135)<2^(−133)<2^(−128) **for honest-setup supplied-pair soundness ONLY**. The setup sampling universe satisfies `q≥2r(2m−2+r)` and all nodes distinct; these are exact integer checks. The full published coefficient portion is `k·N²·32=917,605,083,744,000` bytes, saving `1,772,097,785,856,000` bytes (**65.884519%**) from the immediately previous 2,689,702,869,600,000-byte 4×4 sheared carrier. Secret outer factors alone take ~135 GB before overhead. This is nowhere near practical and no total memory/security estimate of a full Bitcoin graph is offered.

The standalone pure-Python reproducible checker constructs **actual E-valued public coefficient matrices** and tests the source-linear alternating gate on a synthetic 2-Boolean-variable/one-quotient relation over GF(16) with E=GF(256); it is NOT a full QAP fixture. Three deterministic seeds each exhaust all 4096 normalized base-field inputs, check the exact subfield-component equation and the deterministic non-Boolean distance, verify that two different true Boolean witnesses yield the same K, check all 255 wrong field scalars for each of those two witnesses, and sample full public invalid-pair ranks. **136,803 passing assertions**; the two complete runs produce byte-identical JSON. Large parameters are certified by integer inequalities in the same script. Toy RNG seeds and small fields have no cryptographic significance.

## Full remaining research interface; do not promote this to WKEM

The decisive missing equation remains **arbitrary unauthorized recovery of K / native accepted signature → an ORIGINAL witness or independently justified QPT-hardness violation** with all public E matrices, extension/subfield relations, native checking key, auxiliary information, multiple capsules and coherent quantum access. The public extension and Reed–Solomon fingerprint may make tensor decomposition and key-only attacks easier; an earlier four-moment attack is not disproved. Supplied-pair soundness and deterministic distance do not provide full-public-output false-instance secrecy. A practical local release must also radically reduce the still ~0.918 PB tensor, and instantiate malicious/abort-safe N-of-N preparation, native signing, and the Bitcoin graph before funding. No classical group, iO, RIO or assumed witness-release oracle has been silently substituted.

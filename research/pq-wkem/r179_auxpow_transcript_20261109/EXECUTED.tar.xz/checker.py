#!/usr/bin/env python3
"""R179 — byte-format SHA256d/AuxPoW core testbed and failed release experiment.

Synthetic regtest-like work chain; NOT actual BTC best-chain authentication,
Syscoin consensus, a deployed bridge, or witness-encryption/key security.
This consumes the pinned syscoin 1180dad source rules in a strict subset.
"""
import hashlib, json, struct
from dataclasses import dataclass
from collections import Counter

TALLY=Counter()

def ck(cond, label):
    if not cond: raise AssertionError(label)
    TALLY[label] += 1

def sha(b): return hashlib.sha256(b).digest()
def h256(b): return sha(sha(b))
def le32(n): return struct.pack('<I', n)
def le64(n): return struct.pack('<Q', n)
def varint(n):
    if n < 253:return bytes([n])
    if n<=65535:return b'\xfd'+struct.pack('<H',n)
    if n<=0xffffffff:return b'\xfe'+le32(n)
    return b'\xff'+le64(n)

def dec_varint(b, pos):
    if pos>=len(b):raise ValueError('truncated varint')
    d=b[pos];pos+=1
    if d<253:return d,pos
    if d==253:sz=2;minval=253
    elif d==254:sz=4;minval=65536
    else:sz=8;minval=2**32
    if pos+sz>len(b):raise ValueError('truncated count')
    v=int.from_bytes(b[pos:pos+sz],'little')
    if v<minval:raise ValueError('noncanonical CompactSize')
    return v,pos+sz

def parse_tx_nonwitness(raw):
    """Subset: non-segwit coinbase one vin, outputs; exhaustive parsing for fixtures."""
    if len(raw)<12:raise ValueError('short tx')
    off=4
    nv,off=dec_varint(raw,off)
    if nv!=1:raise ValueError('one coinbase input required')
    if off+36>len(raw):raise ValueError('short prevout')
    prev=raw[off:off+32];idx=struct.unpack('<I',raw[off+32:off+36])[0];off+=36
    if prev!=bytes(32) or idx!=0xffffffff: raise ValueError('not coinbase')
    n,off=dec_varint(raw,off)
    if off+n+4>len(raw):raise ValueError('short coinbase script')
    script=raw[off:off+n];off+=n+4
    nout,off=dec_varint(raw,off)
    outs=[]
    for _ in range(nout):
        if off+8>len(raw):raise ValueError('short output value')
        value=int.from_bytes(raw[off:off+8],'little');off+=8
        m,off=dec_varint(raw,off)
        if off+m>len(raw):raise ValueError('short output script')
        outs.append((value,raw[off:off+m]));off+=m
    if off+4!=len(raw):raise ValueError('trailing or missing locktime')
    return script,outs

def make_coinbase(child_digest, tagged_data, outputs_extra=(), tag_prefix=b'\x6a', script_payload=None):
    # AuxPow chain merkle branch = empty, nChainIndex=0: root is child digest.
    # C++ reversed nRootHash before embedding it in scriptSig.
    mixed=b'\xfa\xbe'+b'mm'+child_digest[::-1]+le32(1)+le32(0)
    payload=b'\x01'+mixed if script_payload is None else script_payload
    script_sig=payload
    outputs=[(0,tag_prefix+b'sys'+tagged_data)] + list(outputs_extra)
    raw=le32(2)+b'\x01'+bytes(32)+le32(0xffffffff)+varint(len(script_sig))+script_sig+le32(0xffffffff)
    raw+=varint(len(outputs))
    for v,script in outputs:raw+=le64(v)+varint(len(script))+script
    return raw+le32(0)

def header(merkle, prev=bytes(32), t=1700000000, bits=0x207fffff, nonce=0, version=0x20000000):
    assert len(merkle)==len(prev)==32
    return le32(version)+prev+merkle+le32(t)+le32(bits)+le32(nonce)

def target_from_bits(bits):
    nsize=bits>>24; mant=bits&0x007fffff
    if bits&0x00800000 or mant==0:return None
    target=(mant>>(8*(3-nsize))) if nsize<=3 else (mant<<(8*(nsize-3)))
    if target<=0 or target>=2**256:return None
    # Overflow conditions (broad version for this testbed).
    if nsize>34 or (mant>0xff and nsize>33) or (mant>0xffff and nsize>32):return None
    return target

def pow_ok(h):
    if len(h)!=80:return False
    bits=int.from_bytes(h[72:76],'little')
    target=target_from_bits(bits)
    return target is not None and int.from_bytes(h256(h),'little')<=target

def mine_parent(merkle,prev,t):
    for nonce in range(100000):
        candidate=header(merkle,prev,t,nonce=nonce)
        if pow_ok(candidate):return candidate,nonce+1
    raise AssertionError('synthetic mining exhausted')

def expected_slot(n):
    return ((n-6)//10)*10

def auxpow_index(chain_id,nonce,h):
    mod=1<<h
    r=(nonce*1103515245+12345)%mod
    r=(r+chain_id)*1103515245+12345
    return r%mod

def merkle_branch(digest, siblings,index):
    if index<0:return None
    for sibling in siblings:
        digest=h256(sibling+digest) if index&1 else h256(digest+sibling)
        index>>=1
    return digest

def auxpow_outer(child80, parent80, txraw, txbranch=(),chainbranch=(), chainidx=0,chainid=16):
    """Byte-format subset of CAuxPow::check plus parent PoW; not BTC admission."""
    if len(child80)!=80 or len(parent80)!=80 or not pow_ok(parent80):return False
    try: script,outs=parse_tx_nonwitness(txraw)
    except (ValueError,IndexError):return False
    child_hash=h256(child80)
    if len(chainbranch)>30 or chainidx!=auxpow_index(chainid,0,len(chainbranch)):return False
    root=merkle_branch(child_hash,chainbranch,chainidx)
    if root is None:return False
    mm=b'\xfa\xbe'+b'mm'
    first=script.find(mm)
    if first<0 or script.find(mm,first+1)>=0:return False
    if script[first+4:first+36]!=root[::-1]:return False
    off=first+36
    if len(script)<off+8:return False
    if int.from_bytes(script[off:off+4],'little')!=(1<<len(chainbranch)):return False
    nonce=int.from_bytes(script[off+4:off+8],'little')
    if chainidx!=auxpow_index(chainid,nonce,len(chainbranch)):return False
    # CAuxPow::check includes coinbase merkle branch index zero, not generic index.
    if merkle_branch(h256(txraw),txbranch,0)!=parent80[36:68]:return False
    return True

def tag_check(txraw, n, ancestor):
    if len(ancestor)!=32:return False
    try:_,outs=parse_tx_nonwitness(txraw)
    except ValueError:return False
    refheight=expected_slot(n)
    expect=ancestor+le32(refheight)
    found=False
    for _,script in outs:
        if not script.startswith(b'\x6a'):continue
        marker=script.find(b'sys')
        if marker<0:continue
        if script.find(expect,marker+3)<0:return False
        if found:return False
        found=True
    return found

@dataclass
class Obs:
    n:int
    child:bytes
    parent:bytes
    coinbase:bytes
    chain:int
    history:tuple

def make_child(n, prev, branch):
    # Only pure 80-byte hash identity and prev linkage, NOT full SYS consensus.
    return header(h256(b'child/body/'+bytes([branch])+le32(n)),prev,1700100000+n,0x207fffff,n)

def setup_branches():
    # Common source ancestor 90..100; incompatible at 101; tags at 116 refer 110.
    common={}
    prev=bytes(32)
    for n in range(90,101):
        h=make_child(n,prev,0)
        common[n]=h;prev=h256(h)
    branches=[]
    for br in (1,2):
        chain=dict(common)
        for n in range(101,117):
            h=make_child(n,h256(chain[n-1]),br)
            chain[n]=h
        branches.append(chain)
    return branches

def make_observations(branches):
    btcprev=bytes(32)
    observed=[];iters=0
    # Each synthetic BTC parent extends one parent chain, even though the two
    # child chains are incompatible. This alone does NOT establish canonical BTC.
    for n in range(101,117):
        for br,chain in enumerate(branches):
            child=chain[n]; ref=expected_slot(n)
            tx=make_coinbase(h256(child),h256(chain[ref])+le32(ref))
            parent,tries=mine_parent(h256(tx),btcprev,1700200000+(n-101)*2+br)
            iters+=tries
            btcprev=h256(parent)
            observed.append(Obs(n,child,parent,tx,br,tuple(chain[i] for i in range(90,n+1))))
    return observed,iters

def test_relations():
    branches=setup_branches()
    observed,iters=make_observations(branches)
    prev=bytes(32)
    all_parent_hashes=set()
    for o in observed:
        ck(auxpow_outer(o.child,o.parent,o.coinbase),'parent_sha_child_to_coinbase')
        chain=branches[o.chain]
        ck(tag_check(o.coinbase,o.n,h256(chain[expected_slot(o.n)])),'actual_contextual_tag')
        ck(o.parent[4:36]==prev,'single_linked_synthetic_btc_chain')
        prev=h256(o.parent)
        all_parent_hashes.add(prev)
        ck(o.child[4:36]==h256(chain[o.n-1]),'child_predecessor')
        # mutate important commitments
        bad=bytearray(o.child);bad[60]^=1
        ck(not auxpow_outer(bytes(bad),o.parent,o.coinbase),'child_mutation_rejected')
        bad=bytearray(o.parent);bad[36]^=1
        ck(not auxpow_outer(o.child,bytes(bad),o.coinbase),'parent_merkle_mutation_rejected')
        bad=bytearray(o.coinbase);bad[50]^=1
        ck(not auxpow_outer(o.child,o.parent,bytes(bad)),'coinbase_mutation_rejected')
        ck(not tag_check(o.coinbase,o.n,h256(branches[1-o.chain][expected_slot(o.n)])) if expected_slot(o.n)>=101 else True,'wrong_ancestor_when_diverged')
    ck(len(all_parent_hashes)==len(observed),'distinct_parent_work_ids')
    # Actual pair semantics: SYS child hashes differ at 101 onward, tags only
    # become contradictory at ref slot 110 (n>=116, when ref reaches 110).
    for n in range(101,117):
        a=observed[2*(n-101)];b=observed[2*(n-101)+1]
        ck(h256(a.child)!=h256(b.child),'different_child_outcomes')
        ra=expected_slot(n);rb=expected_slot(n)
        conflict=(ra==rb and h256(branches[0][ra])!=h256(branches[1][rb]))
        ck(conflict==(n>=116),'first_conflicting_tag_at_116')
    # Real tagging parser accepts non-adjacent expected bytes (pinned source)
    o=observed[-1];chain=branches[o.chain];ref=expected_slot(o.n)
    cb=make_coinbase(h256(o.child),b'xx'+h256(chain[ref])+le32(ref))
    ck(tag_check(cb,o.n,h256(chain[ref])),'nonadjacent_valid_tag_accepted')
    ck(not tag_check(make_coinbase(h256(o.child),b'xx'+h256(chain[ref])),o.n,h256(chain[ref])), 'missing_height_rejected')
    ck(not tag_check(make_coinbase(h256(o.child),b'xx'+h256(chain[ref])+le32(ref),outputs_extra=((0,b'\x6asys'+h256(chain[ref])+le32(ref)),)),o.n,h256(chain[ref])),'duplicate_tag_output_rejected')
    # Pinned source scans only the first SYS marker per OUTPUT. A second
    # marker within the same unspendable output is not a multiple-output fault.
    # A stricter light client would disagree with the actual Core predicate.
    dual_in_one=make_coinbase(h256(o.child),h256(chain[ref])+le32(ref)+b'sys'+h256(b'bad')+le32(ref))
    ck(tag_check(dual_in_one,o.n,h256(chain[ref])),'second_sys_marker_same_output_accepted')
    dual_parent,_=mine_parent(h256(dual_in_one),o.parent[4:36],1700700000)
    ck(auxpow_outer(o.child,dual_parent,dual_in_one),'second_sys_marker_outer_authentic')
    ck(tag_check(make_coinbase(h256(o.child),h256(b'wrong')+le32(ref)+b'sys'+h256(chain[ref])+le32(ref)),o.n,h256(chain[ref])),
       'first_marker_searches_later_expected')
    ck(not tag_check(make_coinbase(h256(o.child),b'xxx'+h256(chain[ref])+le32(ref),tag_prefix=b'\x51'),o.n,h256(chain[ref])),'spendable_tag_rejected')

    # A public, fixture-independent partial predicate, with *caller-supplied*
    # history and exact anchored child at height 100. No hidden fixture-helper
    # trust. Parent BTC best-chain membership / full Syscoin consensus absent.
    bound_100=h256(branches[0][100])
    def verify_partial_source(o, fixed_child_hash_100):
        if o.n<101 or len(o.history)!=(o.n-90+1):return False
        if h256(o.history[10])!=fixed_child_hash_100:return False
        for i in range(1,len(o.history)):
            if o.history[i][4:36]!=h256(o.history[i-1]):return False
        if o.history[-1]!=o.child:return False
        if not auxpow_outer(o.child,o.parent,o.coinbase):return False
        ref=expected_slot(o.n)
        if ref<90 or ref>o.n-1:return False
        return tag_check(o.coinbase,o.n,h256(o.history[ref-90]))
    for o in observed:
        ck(verify_partial_source(o,bound_100),'independent_history_predicate')
        wrong_history=list(o.history);wr=bytearray(wrong_history[6]);wr[40]^=1;wrong_history[6]=bytes(wr)
        forged=Obs(o.n,o.child,o.parent,o.coinbase,o.chain,tuple(wrong_history))
        ck(not verify_partial_source(forged,bound_100),'history_mutation_rejected')
        other_anchor=sha(b'different-signed-claim')
        ck(not verify_partial_source(o,other_anchor),'wrong_claim_source_anchor_rejected')

    # One true SRC child with independent parent certificate is not a fork.
    original=observed[-2]
    shadow_parent,tries=mine_parent(original.parent[36:68],original.parent[4:36],1700500000)
    ck(shadow_parent!=original.parent and auxpow_outer(original.child,shadow_parent,original.coinbase),
       'two_work_certificates_one_semantic_child')
    shadow=Obs(original.n,original.child,shadow_parent,original.coinbase,original.chain,original.history)
    ck(verify_partial_source(shadow,bound_100),'alternative_work_cert_same_child_valid')

    # A tag-fault *outer* check must be distinct from tag consistency.
    last=observed[-1]; chain=branches[last.chain]; ref=expected_slot(last.n)
    wrong_tag=h256(b'wrong-source-ancestor')+le32(ref)
    bad_tx=make_coinbase(h256(last.child),wrong_tag)
    repaired_parent,_=mine_parent(h256(bad_tx),last.parent[4:36],1700900000)
    ck(auxpow_outer(last.child,repaired_parent,bad_tx),'tag_fault_outer_authentication')
    ck(not tag_check(bad_tx,last.n,h256(last.history[ref-90])), 'tag_fault_inner_rejected')
    ck(not verify_partial_source(Obs(last.n,last.child,repaired_parent,bad_tx,last.chain,last.history),bound_100),
       'fault_not_falsely_valid_history')

    # RELEASE PROPOSAL: a SHA-transcript-derived source label, not an ideal
    # source oracle. Builder has the fixed *public* baseline anchor. In raw
    # evaluation the supposed protected key is exposed before any certificate.
    # This directly demonstrates why a faithful source verifier is insufficient.
    baseline=bound_100; context=b'claim-bound-cancel/R179'
    frozen=h256(b'frozen-native-fixture,not-signature')
    pad=sha(b'baseline-pad'+context+baseline)
    ct=bytes(x^y for x,y in zip(frozen,pad))
    raw=bytes(x^y for x,y in zip(ct,sha(b'baseline-pad'+context+baseline)))
    ck(raw==frozen,'raw_release_without_evidence')
    def honest_open(a,b):
        if not (verify_partial_source(a,bound_100) and verify_partial_source(b,bound_100)):return None
        if expected_slot(a.n)!=expected_slot(b.n):return None
        if h256(a.history[expected_slot(a.n)-90])==h256(b.history[expected_slot(b.n)-90]):return None
        return raw
    ck(honest_open(observed[-2],observed[-1])==frozen,'honest_check_accepts_authenticated_conflict')
    ck(honest_open(observed[-4],observed[-3]) is None,'honest_check_rejects_early_unvisible_fork')
    ck(honest_open(shadow,original) is None,'honest_check_rejects_same_child')
    # Critical scope failure: a forged low-difficulty local work history is
    # accepted by this incomplete parser but lacks canonical BTC admission.
    # This MUST NOT be promoted to a qualifying ORIGINAL R3 witness.
    ck(honest_open(observed[-2],observed[-1])==frozen,
       'partial_parser_cannot_establish_btc_canonicality')
    # Crucial: the valid source checks still do not gate raw K recovery!
    return {'run':'R179-authenticated-source-relation', 'checks':sum(TALLY.values()), 'groups':dict(sorted(TALLY.items())),
            'synthetic_parent_header_count':len(observed),'synthetic_parent_hash_trials':iters+tries,
            'first_tag_conflict_height':116,'local_refheight_at_conflict':110,
            'same_sha256d_parent_chain_includes_both_sys_forks':True,
            'premature_raw_secret_recovery':raw==frozen,
            'qualifier_limits':'regtest-like low-target; no Bitcoin best-chain admission/DAA/full SYS consensus; synthetic fixtures',
            'release_status':'FAILED: public baseline hash pad bypass; authenticating source outside crypto gate does not bind K',
            'hashes':{'code_sha256':hashlib.sha256(open(__file__,'rb').read()).hexdigest()}}
if __name__=='__main__':print(json.dumps(test_relations(),indent=2,sort_keys=True))

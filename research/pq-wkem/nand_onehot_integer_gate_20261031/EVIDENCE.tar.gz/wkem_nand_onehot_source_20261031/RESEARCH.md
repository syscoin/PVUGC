# NOGC — globally normalized one-hot NAND SOURCE, and the still-broken actual release

2026-10-31, **offline**. Research checkpoint **NOGC-20261031**. Result: **NO positive secure witness-KEM advance**. A new classical-PPT circuit-to-integer-SOURCE compiler establishes a stronger universal *short-INTEGER-opening → ORIGINAL witness* lemma than the preceding CORN binary-only compiler. However, the entire concrete public affine SOURCE-LWE release remains unsafe on FALSE and on TRUE statements possessing an easily identified rejecting assignment. A public near-short nonbinary opening recovers the **precommitted capability** directly, despite all-witness correctness and despite any downstream native checking key. We proved an explicit high-probability bound for this attack under the precise bounded independent noise distribution. The representation lemma is a reusable subcomponent; it does NOT establish a witness-KEM or the missing arbitrary-key-recovery reduction.

## Exact continuity and one chosen unfinished step

At the start of this iteration, GitHub read verified `syscoin/PVUGC` PR #1 **open/draft/unmerged**, head `12fd5365b54709ecfa0e35a143c5177615de1cf2`, branch `research/pq-wkem-validation-20260918`, latest substantive ordinary comment `6549617219`. The exact predecessor file `research/pq-wkem/corn_source_integrality_20261031/RESEARCH.md`, blob `7263b84538bc334cfb71df6d9b8a742f4a714f76`, and its checker blob `1f11284e6ed7b01d10289984a8543eba06170911` were inspected. CORN encodes satisfiability as a *binary* ISIS representation; its release is broken by public nonbinary openings of essentially honest noise budget. We attempted to repair precisely **global integer integrality**, not to assume a SOURCE-opening oracle, a representation supplied by the attacker, or new QPT assumptions.

## One explicit classical-PPT circuit compiler

Let `C_x` be a deterministic Boolean verifier circuit for fixed ORIGINAL statement `x`, written as NAND gates with `n` ORIGINAL input bits, `G` gates, and `V=n+G` wires. For clarity the last gate is the output (if necessary append a NAND network); the required output bit is 1. The claimed complete ORIGINAL relation is `R(x,W)=[C_x(W)=1]`. An actual implementation must bind `x` to the ORIGINAL relation identity, claim/UTXO, branch, anchors/window, signed context and intended native verification key; this toy checker does NOT instantiate that binding or a Bitcoin verifier.

Create one integral one-hot pair `(w_{j,0},w_{j,1})` per wire `j`, and one integral four-tuple `(u_{g,00},u_{g,01},u_{g,10},u_{g,11})` per NAND gate `g`. Define a public system `Az=t (mod q)` with the following **linear** rows:

1. For every wire `j`: `w_{j,0}+w_{j,1}=1`.
2. For every gate `g`: `u00+u01+u10+u11=1`.
3. For the gate's left and right input wire indices `a,b`: `u10+u11=w_{a,1}` and `u01+u11=w_{b,1}`.
4. For its output wire `o`: `u00+u01+u10=w_{o,1}` (NAND is 1 except at 11).
5. For the final output wire: `w_{V-1,1}=1`.

Thus `N=2V+4G` SOURCE coordinates and `D=V+4G+1` rows. Let `L=V+G`, and take prime `q>L+2` (and sufficiently large for the separate release margin). The compiler makes no witness, satisfiability decision, ORACLE call or secret selector; `A,t` are fully public and computable in polynomial time. `Lift(W)` runs `C_x(W)` offline, checks ORIGINAL acceptance, writes one-hot wire and gate entries, and takes `z` as its decryption representation.

### Proved stronger *integer* representation lemma

For every ORIGINAL witness `W`, this deterministic lift is an integer vector `z_W` satisfying `Az_W=t` over the integers and `||z_W||_1=L`. Conversely, for **any** integer vector `z` satisfying `Az=t mod q` and `||z||_1<=L`, the normalization rows are exact integers (as `q>L+2` and the row sum is bounded by `L`). Every one of the `L=V+G` blocks has sum exactly 1, hence L1 norm at least 1. Equality of their total L1 norm forces each block to have norm exactly 1, i.e. exactly one +1 and all other entries zero. The remaining sparse NAND rows then encode the true gate relation exactly, and the output is 1. Reading each ORIGINAL input wire's `w_{i,1}` extracts an ACTUAL ORIGINAL witness in linear time. In particular, for FALSE `x` there is no integer affine opener of norm at most `L`; any invalid integral solution has norm at least `L+2`. This includes ALL integer SOURCE representations within the bound, not merely a supplied binary representation. The proof does **not** extract a representation from an arbitrary attacker recovering the final key, nor rule out longer integral openings.

## Concrete full-public source-dependent release attempted

For each `b=8`-bit secret symbol `m` (native signing-key byte or XOR share byte), independently sample `s <- uniform(F_q^D)`, `e_i,e_* <- uniform({-B,...,B})`, and publish

```
beta = A^T s + e (mod q)
tau  = t^T s + e_* + g*m (mod q),      g=floor(q/256).
```

For a witness `W`, compute `z_W=Lift(W)` and decode `tau-z_W^T beta` to the nearest cyclic `g*m`. If `B(1+L)<g/2`, **all** ORIGINAL witnesses deterministically recover the SAME precommitted symbol `m`, since `||z_W||_1=L`. Independent coins are used for each share, each byte and related capsules. A native checking key and public adaptive preauthorization signatures could be attached exactly as in the predecessor's restricted subtheorems, but they cannot repair the direct decryption below; the checker uses 32-byte mock capabilities, 3 XOR lanes, 2 related capsules, with NO claim to native PQ key generation, signature verification or deployed Bitcoin features. Classical setup, evaluation and attack are polynomial time.

### Universal publicly computable near-short false opener

For ANY input assignment `W0` on which `C_x(W0)=0`, evaluate the true circuit trace, then **flip only the final output wire's one-hot bit from 0 to 1**. All previous wire and gate tuples remain their valid evaluations. For the final NAND gate the genuine inputs are both 1 and the output was 0. Replace its one-hot tuple `(0,0,0,1)` with the integer tuple **`(-1,1,1,0)`** (ordered `00,01,10,11`); it satisfies all three gate-consistency rows and the normalization row while forcing output 1. Call the resulting public integer vector `z_bad`. Exactly:

```
A*z_bad=t over Z
||z_bad||_1 = L+2
||z_bad||_2^2 = L+2.
```

No ORIGINAL witness is supplied. If the statement is FALSE, *every* input assignment is rejecting and hence the attack always applies. If a hard TRUE instance has a readily chosen rejecting assignment, the same explicit unauthorized opening works even without finding a satisfying ORIGINAL witness. The attack is thus not confined to FALSE instances. It requires no source trapdoor, LWE challenge secret, source-opening oracle, voluntary representation from a key-recovery adversary, quantum algorithm or signing oracle.

For each released symbol, the attacker's residual is `g*m + E (mod q)` where `E=e_*-z_bad^T e`. Under **independent, centered B-bounded errors**, Hoeffding gives

```
Pr[incorrect cyclic symbol decoding]
 <= 2*exp(-g^2/(8*B^2*(L+3)))
 <  2*exp(-(L+1)^2/(2*(L+3)))   if g/2>B*(L+1).
```

Across **T** correlated-in-context but independently sampled ciphertext symbols/related capsules, union bound multiplies by `T` (independence between attack success events is not needed). Thus the *same deterministic worst-case margin that makes honest decryption universal makes this adversarial near-short opening succeed with overwhelming probability as L grows*, even if its L1 norm is provably larger. Illustrative `L=2000,T=192` gives upper bound `2^-1433.390171` for any failed-symbol decoding, under the exact error assumptions. This is an analytic bound, not a 128-bit hardness estimate. For a small FALSE circuit `NAND(x,x); NAND(x,NOT x); NAND(OR result,OR result)` (i.e. `x AND NOT x`), `L=7`, `||z_bad||_1=9`, and `q=65537,B=2,g=256` even give **deterministic recovery** of every ciphertext under the bounded noise support. In a tight-margin variant `q=10007,B=2,g=39`, the fake opening no longer meets the deterministic error bound but the exact seeded checker still recovered **6000/6000** individual symbols; no inference of large-parameter security is drawn from these finite trials.

**No-go scope:** The argument applies to this *affine residual* release with those exact centered bounded errors and deterministic all-witness correctness margin, not to every LWE scheme or every PQ WE. Any patch that changes only the ordinary binary/integer API, globally normalizes local labels, or adds a public precheck that an attacker can bypass does not close the cryptographic gate. More strongly, any polynomial-time computable fake affine opener with `||z_bad||_2^2=O(L)` defeats this release when `g/2>B(L+1)` and `T=poly(L)`, by the same concentration argument. A semantic L1 gap or ordinary independent LWE pad-hiding alone cannot yield arbitrary final-key-recovery soundness for this structured public source.

## Exact local execution and reproducibility

`checker.py` is the exact executed, deterministic, Python-standard-library-only checker; `output.json` is its captured output, run **twice** with byte-identical SHA-256. It checked `37` NAND circuits, `97` valid ORIGINAL assignments, `3` exhaustive short integral affine openings on a single NAND-gate circuit, actual source-dependent encryption/decryption with three XOR lanes, two related mock-key capsules and a FALSE circuit, and `6000/6000` tight-margin fake-opening recoveries. It passed **1070 assertions**. Those checks corroborate the identities; the preceding arguments are mathematical. No actual QPT attacker, LWE hardness, native signature, zk verifier, Bitcoin endpoint or onchain execution was tested. `random.Random` is a deterministic toy generator, not cryptographic randomness.

## Precise remaining obligation and next constructive move

The exact missing item is **not** another supplied-representation lemma. Instantiate a genuinely nonlinear, witness-free classical-PPT release which is *not evaluable by public affine near-short `z_bad`*; its checking-key/capsule/context/auxiliary/related-capsule distribution must be jointly produced and QPT-simulated **from the actual structured SOURCE with the LWE challenge**, without assuming a SOURCE-open oracle or hidden honest witness. Every valid ORIGINAL witness must recover one precommitted capability without canonicalizing it, and arbitrary unauthorized final-key recovery/native forgery must imply an actual ORIGINAL witness or an independent QPT break. If retaining this affine decoder, prove a structural lower bound excluding **all efficiently computable** false affine openings of small L2 norm and account for non-representation-based key recovery; merely amplifying semantic L1 slack is insufficient. A PCP/high-distance-output repair might address the local flip but still does not by itself overcome L2 concentration or provide the required simulator, so it has NOT been instantiated or credited as a solution.

One-honest N-of-N funding/abort/graph/DA, SYS/BTC full qualification, chain censor/reorg assumptions, and hypothetical native PQ Bitcoin verification remain as in the standing requirements and were not claimed complete. The earlier uniform-random SOURCE LWE theorem does not automatically apply to this *structured* NAND matrix. There is no positive secure WKEM advance and the existing research automation must remain enabled.

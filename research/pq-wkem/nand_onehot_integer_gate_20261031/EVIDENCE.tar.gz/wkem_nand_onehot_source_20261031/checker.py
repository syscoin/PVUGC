#!/usr/bin/env python3
"""Offline finite-field checker: NAND-one-hot integral SOURCE and actual affine-LWE release bypass.
This is NOT a QPT test, a secure witness KEM, or a secure signature implementation.
"""
import hashlib, itertools, json, math, random

SEED=20261031_1544
rng=random.Random(SEED)
checks=0

def check(condition,description):
    global checks
    if not condition: raise AssertionError(description)
    checks+=1

def nand(a,b): return 1-(a&b)

def circuit_eval(n, gates, inp):
    w=list(inp)
    for i,j in gates:
        w.append(nand(w[i],w[j]))
    return w

def build(n, gates):
    v=n+len(gates); g=len(gates); N=2*v+4*g
    A=[]; t=[]
    def row(terms,value):
        r=[0]*N
        for j,k in terms:r[j]+=k
        A.append(r);t.append(value)
    for j in range(v): row([(2*j,1),(2*j+1,1)],1)
    for h,(i,j) in enumerate(gates):
        off=2*v+4*h; out=n+h
        row([(off+k,1) for k in range(4)],1)
        row([(off+2,1),(off+3,1),(2*i+1,-1)],0)
        row([(off+1,1),(off+3,1),(2*j+1,-1)],0)
        row([(off+0,1),(off+1,1),(off+2,1),(2*out+1,-1)],0)
    row([(2*(v-1)+1,1)],1)
    return A,t,v,g

def extension(n,gates,inputs,fake=False):
    w=circuit_eval(n,gates,inputs)
    if not fake and w[-1]!=1: return None
    if fake: w[-1]=1 # public choice of wire bits; doesn't need valid circuit execution
    eta=[]
    for h,(i,j) in enumerate(gates):
        a,b,c=w[i],w[j],w[n+h]
        x11=1-c;x10=a-x11;x01=b-x11;x00=1-a-b+x11
        eta.extend([x00,x01,x10,x11])
    z=[]
    for a in w: z.extend([1-a,a])
    z.extend(eta)
    return z

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def matvec(A,z):return [dot(row,z) for row in A]
def l1(z):return sum(abs(x) for x in z)
def l2sq(z):return sum(x*x for x in z)

def release_encrypt(A,t,m,Q,B):
    d=len(A); N=len(A[0]);g=Q//256
    s=[rng.randrange(Q) for _ in range(d)]
    e=[rng.randrange(-B,B+1) for _ in range(N)]
    es=rng.randrange(-B,B+1)
    beta=[(sum(A[j][i]*s[j] for j in range(d))+e[i])%Q for i in range(N)]
    tau=(dot(t,s)+es+g*m)%Q
    return beta,tau

def release_dec(beta,tau,z,Q):
    g=Q//256
    residue=(tau-dot(z,beta))%Q
    best=min(range(256), key=lambda m:min((residue-g*m)%Q,(g*m-residue)%Q))
    return best

def source_test(n,gates):
    A,t,v,g=build(n,gates);L=v+g;allowed=0
    for bits in itertools.product(range(2),repeat=n):
        zs=extension(n,gates,bits)
        if zs is not None:
            allowed+=1
            check(matvec(A,zs)==t,'valid NAND-source equation')
            check(l1(zs)==L,'all-valid source length')
            check(all(k in (0,1) for k in zs),'valid onehot vector')
        zbad=extension(n,gates,bits,fake=True)
        check(matvec(A,zbad)==t,'public fake integer affine opening always exists')
        check(l1(zbad)>=L,'fake length at least threshold')
        check(l1(zbad)<=v+5*g,'fake L1 is polynomial bounded')
        check(l2sq(zbad)<=v+7*g,'fake L2 is polynomial bounded')
        if circuit_eval(n,gates,bits)[-1]==0:
            check(l1(zbad)==L+2,'rejecting trace output flip has EXACT +2 integer l1 gap')
            check(l2sq(zbad)==L+2,'rejecting trace output flip has EXACT +2 integer l2-squared gap')
    return allowed

def iter_short_vectors(D,L):
    z=[0]*D
    def generate(i,budget):
        if i==D:
            yield tuple(z);return
        for value in range(-budget,budget+1):
            z[i]=value
            yield from generate(i+1,budget-abs(value))
    yield from generate(0,L)

def random_circuits():
    yield 2,[(0,1)]
    yield 1,[(0,0),(0,1),(2,2)] # FALSE, output x AND NOT x
    for _ in range(35):
        n=rng.randrange(1,4);m=rng.randrange(1,7);gates=[]
        for j in range(m):
            gates.append((rng.randrange(n+j),rng.randrange(n+j)))
        yield n,gates

def xor(*arr):return bytes([functools_reduce_xor(v) for v in zip(*arr)])
def functools_reduce_xor(vals):
    x=0
    for v in vals:x^=v
    return x

def full_capsule_test(n,gates,show_false=False):
    A,t,v,g=build(n,gates);Q=65537;B=2;L=v+g
    check(B*(1+L)<(Q//256)/2,'honest worst case noise margin')
    origs=[]
    for bits in itertools.product(range(2),repeat=n):
        z=extension(n,gates,bits)
        if z is not None: origs.append(z)
    master=bytes(rng.randrange(256) for _ in range(32))
    s0=bytes(rng.randrange(256) for _ in range(32))
    s1=bytes(rng.randrange(256) for _ in range(32))
    s2=xor(master,s0,s1)
    shares=(s0,s1,s2)
    reject=next((bits for bits in itertools.product(range(2),repeat=n) if circuit_eval(n,gates,bits)[-1]==0), None)
    fake_input=reject if reject is not None else (0,)*n
    fake=extension(n,gates,fake_input,fake=True)
    check(matvec(A,fake)==t,'specific direct public fake opening')
    if reject is not None:
        check(l1(fake)==L+2 and l2sq(fake)==L+2,'fake is a +2 near-honest integer opening')
    fake_results=[]
    authentic_results=[]
    for capsule in range(2):
        encrypted=[[release_encrypt(A,t,byte,Q,B) for byte in lane] for lane in shares]
        for w in origs:
            dec=[bytes(release_dec(beta,tau,w,Q) for beta,tau in lane) for lane in encrypted]
            res=xor(*dec)
            check(res==master,'all valid ORIGINAL NAND witnesses recover SAME capability')
            authentic_results.append(res)
        fake_dec=[bytes(release_dec(beta,tau,fake,Q) for beta,tau in lane) for lane in encrypted]
        candidate=xor(*fake_dec)
        if B*(1+l1(fake))<(Q//256)/2:
            check(candidate==master,'public false opening guaranteed by WORST CASE bound')
        fake_results.append(candidate==master)
    if show_false:
        check(not origs,'specific FALSE source has NO ORIGINAL witness')
        check(all(fake_results),'public fake recovers all 3 lanes across 2 related capsules')
    return len(origs),sum(fake_results),l1(fake),L,hashlib.sha256(master).hexdigest()[:16],reject is not None

def tight_margin_test():
    # On the FALSE circuit, tune the code spacing so the fake has no
    # deterministic worst-case guarantee, while honest valid traces would.
    n=1; gates=[(0,0),(0,1),(2,2)]
    A,t,v,g=build(n,gates)
    fake=extension(n,gates,[0],fake=True)
    Q=10007;B=2;spacing=Q//256
    check(B*(1+v+g)<spacing/2,'hypothetical honest trace still worst-case correct')
    check(B*(1+l1(fake))>spacing/2,'public fake fails worst-case guarantee')
    trials=6000; wins=0
    for _ in range(trials):
        u=rng.randrange(256);beta,tau=release_encrypt(A,t,u,Q,B)
        wins+=release_dec(beta,tau,fake,Q)==u
    return {'q':Q,'B':B,'g':spacing,'L':v+g,'fake_l1':l1(fake),'successful_public_fake_symbol_decryptions':wins,'trials':trials}

# Exact local compiler checks, no cryptographic security inference.
per=[]
for n,gates in random_circuits():
    per.append({'wires':n+len(gates),'gates':len(gates),'valid_originals':source_test(n,gates)})

# Exhaustive integer SOURCE openings for one NAND gate (2 ORIGINAL inputs),
# not just supplied binary strings: every norm<=L solution is ORIGINAL.
A,t,v,g=build(2,[(0,1)]);L=v+g
short_solution_count=0
for z in iter_short_vectors(len(A[0]),L):
    if matvec(A,z)==t:
        short_solution_count+=1
        bits=(z[1],z[3]);orig=extension(2,[(0,1)],bits)
        check(orig is not None and list(z)==orig,'arbitrary integer short affine opening extracts ORIGINAL input')
check(short_solution_count==3,'NAND has three accepting original assignments')

true_result=full_capsule_test(2,[(0,1)])
false_result=full_capsule_test(1,[(0,0),(0,1),(2,2)],show_false=True)
tight=tight_margin_test()

# Hoeffding: for the explicitly computed rejecting trace modified ONLY at
# the final NAND gate, fake l2-squared = L+2 EXACTLY, hence bound
# P(any of T symbols wrong) <= 2*T*exp(-((L+1)^2)/(2*(L+3))).
Vlarge=1000;Glarge=1000;T=192
exponent=(Vlarge+Glarge+1)**2/(2*(Vlarge+Glarge+3))
log2_fail=math.log2(2*T)-exponent/math.log(2)
check(log2_fail < -128,'analytic tail at illustrative large family')

out={'candidate':'NOGC: NAND one-hot global integer SOURCE and tested affine-release attack',
     'seed':SEED,'checks':checks,'circuits':len(per),
     'all_valid_original_witnesses_tested':sum(r['valid_originals'] for r in per),
     'exhaustive_small_integer_short_solutions':short_solution_count,
     'valid_scope_capsules':{'valid_originals':true_result[0],'public_fake_capsules_recovered':true_result[1], 'fake_l1':true_result[2], 'honest_threshold_L':true_result[3], 'fake_used_rejecting_original':true_result[5]},
     'false_scope_capsules':{'valid_originals':false_result[0],'public_fake_capsules_recovered':false_result[1], 'fake_l1':false_result[2], 'honest_threshold_L':false_result[3], 'fake_used_rejecting_original':false_result[5]},
     'tight_margin_test':tight,
     'analytical_example':{'V':Vlarge,'G':Glarge,'T_symbols':T,'hoeffding_exponent':round(exponent,6),'upper_log2_probability_any_wrong_symbol':round(log2_fail,6)},
     'interpretation':'Exact short INTEGER source soundness proved; actual source-dependent public affine LWE release still completely broken; no QPT security claim.'}
print(json.dumps(out,sort_keys=True,indent=2))

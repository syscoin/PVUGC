#!/usr/bin/env python3
"""Research-only: BIP143 SIGHASH_SINGLE|ANYONECANPAY frozen activation signatures.
Public deterministic fixture keys. Do NOT fund any generated script or tx.
No source-FE, complete covenant graph, Bitcoin VM or validation is tested.
"""
import hashlib, json, sys
from dataclasses import dataclass, replace
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature
from cryptography import __version__ as crypto_version

SIGHASH_ALL=1; SIGHASH_SINGLE=3; SIGHASH_ANYONECANPAY=0x80
ORDER=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141

def hash256(data):return hashlib.sha256(hashlib.sha256(data).digest()).digest()
def sha(data):return hashlib.sha256(data).digest()
def le(n,width):return n.to_bytes(width,'little')
def varint(n):
    if n<253:return bytes([n])
    if n<65536:return b'\xfd'+le(n,2)
    raise ValueError(n)
def vb(x):return varint(len(x))+x
@dataclass(frozen=True)
class TXI:
    outpoint:bytes
    seq:int=0xfffffffd
    script:bytes=b''
    def enc(self): return self.outpoint+vb(self.script)+le(self.seq,4)
@dataclass(frozen=True)
class TXO:
    value:int
    script:bytes
    def enc(self):return le(self.value,8)+vb(self.script)
@dataclass(frozen=True)
class TX:
    ins:tuple
    outs:tuple
    lock:int=0
    ver:int=2
    def enc(self):return (le(self.ver,4)+varint(len(self.ins))+b''.join(i.enc() for i in self.ins)
                          +varint(len(self.outs))+b''.join(o.enc() for o in self.outs)+le(self.lock,4))
    def txid(self):return hash256(self.enc())

def bip143(tx, index, script, amount, flag):
    base=flag & 31
    assert 0<=index<len(tx.ins) and base in [SIGHASH_ALL,SIGHASH_SINGLE] and amount>=0
    prevouts=b'\0'*32 if flag&SIGHASH_ANYONECANPAY else hash256(b''.join(i.outpoint for i in tx.ins))
    sequences=b'\0'*32 if flag&SIGHASH_ANYONECANPAY or base!=SIGHASH_ALL else hash256(b''.join(le(i.seq,4) for i in tx.ins))
    if base==SIGHASH_ALL:
        outputs=hash256(b''.join(o.enc() for o in tx.outs))
    else:
        outputs=hash256(tx.outs[index].enc()) if index<len(tx.outs) else b'\0'*32
    item=tx.ins[index]
    msg=(le(tx.ver,4)+prevouts+sequences+item.outpoint+vb(script)+le(amount,8)+le(item.seq,4)
         +outputs+le(tx.lock,4)+le(flag,4))
    return hash256(msg)

def key(i):
    scalar=(int.from_bytes(sha(b'PUBLIC DO NOT USE fee source assertion proof key'+le(i,4)),'big')%(ORDER-1))+1
    return ec.derive_private_key(scalar,ec.SECP256K1())
def public_bytes(k):return k.public_key().public_bytes(serialization.Encoding.X962,serialization.PublicFormat.CompressedPoint)
def sign(k,digest):
    der=k.sign(digest,ec.ECDSA(utils.Prehashed(hashes.SHA256()),deterministic_signing=True))
    r,s=utils.decode_dss_signature(der)
    return utils.encode_dss_signature(r,min(s,ORDER-s))
def verify(k,sig,digest):
    try:k.public_key().verify(sig,digest,ec.ECDSA(utils.Prehashed(hashes.SHA256())));return True
    except InvalidSignature:return False

def push(p):
    assert len(p)<=75
    return bytes([len(p)])+p

def main():
    # Published BIP143 P2WPKH reference, manually reconstructed from BIP143.
    # Digest is the source's native P2WPKH example, externally checked in prior FE test.
    keys=[key(i) for i in range(3)]  # 2 N-of-N preauthorizers, one live notary
    N1,N2,notary=keys
    # [notary sig] CHECKSIGVERIFY then 2-of-2 fixed setup signatures.
    source_script=push(public_bytes(notary))+b'\xad\x52'+push(public_bytes(N1))+push(public_bytes(N2))+b'\x52\xae'
    # Claim-independent vault staging script. Full bridge graph NOT modeled.
    staging_script=b'\x52'+push(public_bytes(N1))+push(public_bytes(N2))+b'\x52\xae'
    staging_spk=b'\x00\x20'+sha(staging_script)
    value_vault=12_000_000
    vaultr=TXI(sha(b'FICTITIOUS UNFUNDED VAULT PREVOUT')+le(0,4))
    feeinput=TXI(sha(b'FICTITIOUS NOTARY FEE PREVOUT')+le(1,4))
    fee_value=22000; fee_paid=900
    fixed=TXO(value_vault,staging_spk)
    def claim_output(statement):
        data=b'SYSWC'+sha(statement)
        return TXO(0,b'\x6a'+push(data))
    def activation(statement, include_fee=True, wrong_fixed=None):
        inp=(vaultr,feeinput) if include_fee else (vaultr,)
        # The original vault carries exactly its whole value to protected output0.
        outs=[fixed if wrong_fixed is None else wrong_fixed,claim_output(statement)]
        if include_fee:outs.append(TXO(fee_value-fee_paid,b'\x00\x14'+sha(b'FICTITIOUS NOTARY FEE CHANGE')[:20]))
        return TX(tuple(inp),tuple(outs))
    a=activation(b'claim A: withdrawal to recipient P against burn U')
    b=activation(b'claim B: different withdrawal recipient Q')
    nofee=activation(b'claim A: withdrawal to recipient P against burn U',False)
    wrongvalue=activation(b'claim A: withdrawal to recipient P against burn U',True,replace(fixed,value=value_vault-1))
    wrongscript=activation(b'claim A: withdrawal to recipient P against burn U',True,replace(fixed,script=b'\x00\x20'+sha(b'ATTACKER SCRIPT')))
    extra=replace(a,outs=a.outs+(TXO(0,b'\x6a'+push(b'UNRELATED AUX')),))
    malformed=replace(a,outs=(fixed,TXO(0,b'\x6a'+push(b'BADCLAIM')),a.outs[2]))
    # Presigning the SINGLE|ANYONECANPAY vault input, with no future assertion known.
    activation_flag=SIGHASH_SINGLE|SIGHASH_ANYONECANPAY
    base_digest=bip143(a,0,source_script,value_vault,activation_flag)
    presig=[sign(k,base_digest) for k in (N1,N2)]
    for t in (a,b,nofee,extra,malformed):
        d=bip143(t,0,source_script,value_vault,activation_flag)
        assert d==base_digest and all(verify(k,s,d) for k,s in zip((N1,N2),presig))
    for t in (wrongvalue,wrongscript):
        d=bip143(t,0,source_script,value_vault,activation_flag)
        assert d!=base_digest and not any(verify(k,s,d) for k,s in zip((N1,N2),presig))
    # One live notary signature SIGHASH_ALL approves exact assertion and fee context.
    a_notary=bip143(a,0,source_script,value_vault,SIGHASH_ALL)
    b_notary=bip143(b,0,source_script,value_vault,SIGHASH_ALL)
    n_sig=sign(notary,a_notary)
    assert verify(notary,n_sig,a_notary) and not verify(notary,n_sig,b_notary)
    # Each activated claim produces distinct nonwitness txid and its own cancelled outpoint.
    assert len({a.txid(),b.txid(),malformed.txid(),extra.txid()})==4
    def cancellation(t):
        return TX((TXI(t.txid()+le(0,4)),),(TXO(value_vault-1000,b'\x00\x14'+sha(b'SAFE-RECOVERY-DESTINATION')[:20]),))
    cancela,cancelb=cancellation(a),cancellation(b)
    ca=bip143(cancela,0,staging_script,value_vault,SIGHASH_ALL)
    cb=bip143(cancelb,0,staging_script,value_vault,SIGHASH_ALL)
    assert ca!=cb
    csig=[sign(k,ca) for k in (N1,N2)]
    assert all(verify(k,s,ca) for k,s in zip((N1,N2),csig))
    assert not any(verify(k,s,cb) for k,s in zip((N1,N2),csig))
    # Vault conservation: output0 receives all vault sats. Fee derives only from other input.
    assert a.outs[0].value==value_vault and sum(o.value for o in a.outs)==value_vault+fee_value-fee_paid
    assert all(o.value==0 for o in (a.outs[1],))
    # Adversarial malformed claim is valid under frozen N-of-N activation signatures:
    # no assurance of ORIGINAL exception certificate without further graph/release rules.
    assert bip143(malformed,0,source_script,value_vault,activation_flag)==base_digest
    result={
        'scope':'BIP143 native-message test only; no Bitcoin VM, qualified source, FE, funded tx or safe full covenant',
        'python':sys.version.split()[0], 'cryptography':crypto_version,
        'preauthorizer_sighash_flag':hex(activation_flag),
        'same_preauthorizer_sighash_across_different_claim':bip143(b,0,source_script,value_vault,activation_flag)==base_digest,
        'same_preauthorizer_sighash_with_extra_fee_input_removed':bip143(nofee,0,source_script,value_vault,activation_flag)==base_digest,
        'same_preauthorizer_sighash_with_extra_outputs':bip143(extra,0,source_script,value_vault,activation_flag)==base_digest,
        'changed_protected_output_rejected':True,
        'live_notary_approves_specific_claim':True,
        'activation_a_txid':a.txid()[::-1].hex(),
        'activation_b_txid':b.txid()[::-1].hex(),
        'claim_bound_cancel_A':ca.hex(), 'claim_bound_cancel_B':cb.hex(),
        'cross_claim_cancel_signature_valid':[verify(k,s,cb) for k,s in zip((N1,N2),csig)],
        'malformed_claim_remains_presig_valid':True,
        'full_vault_amount_staged':True,
        'fe_compiler_constructed':False,
        'proof_of_original_source_extraction':False,
        'full_bitcoin_script_verified':False,
    }
    print(json.dumps(result,sort_keys=True,indent=2))

if __name__=='__main__':main()

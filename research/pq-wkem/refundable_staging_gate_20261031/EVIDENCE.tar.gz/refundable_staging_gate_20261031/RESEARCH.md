# RSEG: Refundable Staging Escrow Gate for SCFB

**Research checkpoint:** RSEG-2026-10-31, source branch `research/pq-wkem-validation-20260918` of `syscoin/PVUGC` PR #1, beginning at commit `305c65d57844032c6077f1ad25a338366eb8a877`. Continued from SCFB (staged capsule/funding binding). **Status: conditional construction and path-cut theorem, NOT an instantiated generic PQ witness-KEM, QPT-LWE security proof, native Bitcoin implementation, or deployment.** Offline mathematics and bounded local computation only.

## 1. Exact previously unfinished obligation and constructive change

SCFB's authorized-funding readiness theorem assumed an *additional honest funding-input wallet*: the wallet had to withhold a necessary signature on the final funding transaction until the entire ORIGINAL-bound capsule, safe pre-signatures, certificate, and honest watcher receipt existed. In an N-of-N preauthorization system, the one honest preauthorizer need not own an input to a direct funding transaction; this funding-wallet gate therefore adds a distinct honest dependency. An off-chain certificate alone is not consensus-enforced: a third party can deposit to an identical script without knowing the certificate.

**RSEG replaces the extra post-compile funding-wallet gate for the final claim output with a refundable, preauthorized staging UTXO.** The existing one-honest N-of-N participant signs the *stage-to-final cooperative spend* only after checking the complete finalized manifest. The depositor requires only a verifiable pre-signed/refundable staging path *before* its first irrevocable on-chain stage deposit. A malicious participant can block timely progress but cannot cause an *authorized* stage coin to enter the final claim without the honest participant's final cooperative signature (apart from cryptographic/consensus breaks). This distinction requires two on-chain transactions, extra fees and a temporary reversible lock, and does not prevent unsolicited third-party funding. Stage refund liveness still requires eventually available transaction inclusion.

This is an actual protocol construction under stated endpoint assumptions; it **does not** instantiate `WKEM.Enc` or recover its ORIGINAL witness.

## 2. Algorithms and acyclic dependency graph

All honest preparation is classical PPT. Keys in different roles are independent, including the challenge native signing secret `sk_C` and the honest cooperative signing secret. The one honest human/participant may own both a cooperative key and a separate setup-only manifest authorization key; that is *not* an additional online release authority. An independent watcher holds its own key, and the depositor holds the refundable output key. Assume native no-EC-key-path PQ script branches implementing ordinary full-message native signatures and required timelocks; these are **hypothetical**, not existing Bitcoin features verified in this run.

- Freeze a **pre-stage** scope template `s=(network, ORIGINAL R identity, claim, branch, anchors/window, credential type, watcher authorization policy)` that does not contain the unknown stage txid. Define a staging output descriptor `D_S` with exactly two script branches: `coop` requiring **all N** specified participant signatures, including one honest signer's; and `refund` after relative timeout `T_S`, requiring a depositor signature. Bind the pre-stage scope digest, a setup-only authentication verification key and the accepted watcher verification-key policy in the descriptor. Exclude key paths, fallback spend keys and alternative bypass edges; this requires an actual consensus script enumeration in any future implementation.
- Freeze a SegWit-like witness-independent staging funding skeleton `S`, and compute `u_S=(txid(S),vout_S)` *before funding witnesses*. Generate and verify a valid refund transaction `R_S` spending exactly `u_S` after timeout. Sign and durably store the refund (with a fee/rebroadcast strategy) **before** the depositor signs/broadcasts `S`. Otherwise abort before this first staging deposit. The stage deposit locks value temporarily but has a designated-owner refund route; it is **not** yet an irrevocable challenge-bearing final output.
- Freeze a witness-independent cooperative stage-to-final transaction skeleton `F`, spending exactly `u_S` to a final descriptor `D_F` containing a challenge-path `vk_C` and only complete preauthorizable safe paths. Compute `u_F=(txid(F),vout_F)` without signatures. The actual ORIGINAL statement binds `(R identity,s,u_S,u_F,F,D_F,vk_C,branch,anchors/window,credential)`; generate the opaque `C=WKEM.Enc(x,sk_C)` (unimplemented). Every valid ORIGINAL witness is still required to recover exactly the same precommitted `sk_C`. `D_F` must **not** commit to a manifest containing `u_F`, or the old txid cycle returns.
- Construct and verify all **safe** child transactions spending `u_F`, with complete N-of-N pre-signatures and correct full-message sighashes and guards. **Never pre-sign the native challenge transaction.** Construct the complete manifest `M=(D_S,S,u_S,R_S,F,D_F,u_F,x,C,related capsules,all safe children/presignatures,scope/watch policy)`, setup-only certificate `cert=Sign_auth(domain||u_S||u_F||H(M))`, and an independently honest watcher receipt `rho=Sign_watch(domain||u_F||H(M)||accepted)` only after receiving and durably retaining the manifest bytes.
- The **honest cooperative stage signer** verifies canonicality, every stage/final path, actual funding/outpoint identities, full-message signature coverage, authentic refund, source/capsule/vk scope, exact certificate and watcher receipt, and locally retrievable complete bytes. It waits for all other cooperative signatures or a completed co-signing workflow, then signs **only the fixed F**. It may broadcast the fully signed F itself. If any readiness condition fails, it withholds its cooperative signature. Upon abort or non-cooperation, the depositor can instead attempt the pre-signed refund after `T_S`.
- A finalized F activates the original conditional challenge/timeout graph. Actual admissible original evidence must later recover `sk_C` **off chain**, and Bitcoin verifies only a native signature on the challenge path. Bitcoin never evaluates the original NP verifier, a SNARG, a VM or a BitVM trace. After legitimate settlement, UTXO ownership is unrestricted.

The dependency DAG is

```
pre-stage scope / N-of-N stage descriptor
        -> stage funding S -> stage outpoint u_S -> pre-signed refund R_S
        -> stage deposit
        -> final F skeleton -> u_F -> ORIGINAL x, capsule C, safe child signatures
        -> manifest M -> setup cert + watcher DA receipt
        -> one-honest N-of-N cooperative signature on F
        -> final UTXO u_F
```

No completed capsule, off-chain manifest or final child signature is committed inside `D_S` or `D_F`; the scoped authorization certificate binds the off-chain bytes to both actual outpoints. A different deposited UTXO with a superficially identical script is not automatically an authorized claim.

## 3. Precisely conditional RSEG path-cut theorem

Let `GateReady(M,u_S,u_F)` be the conjunction of every static graph, signature, scope, pre-signature, refund, watcher DA and source/capsule formatting check described above. The checker does **not** assert semantic correctness or source soundness of C. The policy must ensure that honest signing of cooperative message `m_F` happens only when GateReady is true and the honest signer has observed the complete manifest. A native consensus policy must require a signature under the honest `vk_H` on **every stage-to-final cooperative spend**, with no bypass. All honest signing interfaces receive only **classical** messages and the adversary makes adaptive classical signing queries; the adversary's internal computation and nonuniform advice may be arbitrary QPT, subject to secret-key independence.

For any such QPT adversary, define `Bad` as an accepted cooperative transfer from authorized stage UTXO `u_S` into a final claim without a prior honest GateReady event for its **exact** fixed `F` and manifest. Under (i) QPT EUF-CMA of the *native cooperative signature* with classical signing queries, (ii) binding of the native full-message signature and witness-independent txids, (iii) source-independent cryptographic signature verification under the script's exact public key, (iv) QPT EUF-CMA of independently generated setup-certificate and watcher-attestation keys, (v) quantum collision/second-preimage resistance of the manifest digest, and (vi) complete canonical script graph enumeration and honest local GateReady enforcement,

```
Pr[Bad] <= Adv_QPT-EUF(honest_coop)
         + Adv_QPT-EUF(setup_cert) + Adv_QPT-EUF(watcher_receipt)
         + Adv_QPT-hash-binding + eps_txid_malleability
         + eps_script_parser_or_graph_bypass + eps_honest_policy_violation.
```

This is a conservative union bound; each signature reduction can run **straight-line**, generating all independent keys/transcripts, answering valid signing queries through its challenger and refusing invalid requests in the simulated honest participant's policy. If F bears an honest signature that was never issued for that exact message, it is an EUF-CMA forgery. If it was issued, that issuance was gated by `GateReady` for its exact committed manifest; a different accepted manifest for the same authorized scope is a forgery or a binding collision. Every adaptive QPT operation on the complete classical public transcript, including coherent processing, remains allowed. The proof cannot lift Ed25519 or toy hash checks to QPT and cannot assume quantum rewinding/extraction.

This statement is **not** a full-public WKEM reduction. It holds regardless of whether the capsule is source-sound, so a malicious capsule that leaks `sk_C` could enable a challenge-path spend immediately after F. The one-honest preauthorizer must also ensure honest challenge-key origination/erasure or sound distributed generation and must not release the challenge key outside the future witness-KEM. The optional keyless malicious-builder model remains unproved. Those requirements are separate from stage path-cut safety.

## 4. Abort, liveness, and competing spends

If no honest cooperative signature is issued and the stage output has only these two paths, the adversary cannot cooperatively spend `u_S` without forging or bypassing the script. After relative timeout `T_S`, the depositor's already signed refund is eligible to be mined. This is **conditional useful abort**, not guaranteed finite-time liveness: arbitrary network censorship, RBF/fee pinning, miner behavior and unconfirmed-stage malleability can impede settlement. The depositor still needs to verify its refundable `D_S` and preserve the correct refund before making the first stage deposit. If a full cooperative signature exists before `T_S` but F is delayed until after `T_S`, both F and the refund may compete for the same outpoint; whichever confirms first consumes it. A late F is already manifest-gated and therefore not an unsafe unexpected finalization, but refund success is not guaranteed. A withheld signature from one of the other N-1 participants can force timeout/refund rather than claim activation.

The construction does not assume an unseen competing fork can be proved absent. Qualified fork/tag evidence, source ChainLocks, BTC best-chain qualifications, observation windows, DA and censorship assumptions remain unchanged and uninstantiated by this protocol note. Challenge bearer/designated-owner authorization must remain path/claim scoped. No old keys authorize a new UTXO merely because the scripts match.

## 5. Full joint public view and the missing source-LWE challenge simulator

The public classical view now contains `(R,x,u_S,u_F,S,F,D_S,D_F,C,vk_C,other C,children,safe signatures,cert,rho,refund,other aux)`. All authentic certs, receipts and safe/coop signatures can be generated as *polynomial-time postprocessing* of a syntactically formed capsule using independent signing keys. Thus, for **any already independently established** pair of QPT-indistinguishable joint capsule distributions for which all original scope fields are held fixed, applying this staged-signature postprocessing preserves indistinguishability by a direct straight-line distinguisher composition, even against coherent processing of the complete resulting classical transcript. The postprocessor does **not** require `sk_C` to sign F or issue the setup and watcher certificates. Its own signing-policy decision is internal, and it issues a certificate for the syntactically supplied capsule bytes in both hybrids.

This postprocessing lemma does **not** make the needed premise true for arbitrary ORIGINAL instances. The previous uniform random binary-ISIS QPT-LWE hybrid does not instantiate a source-bound simulator for an adversarial SYS/BTC NP relation or all chosen FALSE/hard-TRUE statements. If an external consistency proof is required for C, that proof and its quantum simulator must be included in the joint game: public proof validity may otherwise distinguish a uniformized ciphertext. Likewise, target share openings, target-key-correlated auxiliary advice and malicious-source choices cannot be silently simulated. The LWE target may not be replaced independently of `x`, `vk_C`, setup proofs or related capsules. No SOURCE-opening oracle, arbitrary key-recovery-to-representation theorem or extra online authorizer is assumed.

The unresolved core equation is still

```
Comp(R_original,x,context,vk; classical coins) -> (C,precommitted K,public checking data)
Lift(C,W) = K  for EVERY W with R_original(x,W)=1,
```

with a **jointly instantiated** QPT reduction from arbitrary adversarial-FALSE or unauthorized hard-TRUE final-key recovery / accepted fresh native signature to an **actual ORIGINAL witness**, or an independently justified QPT break. This has not been achieved. All prior local label/occurrence switching, public interpolation, affine/low-degree closure, short invalid representation and random-hash-collapse regressions still apply.

## 6. Reproducible checker and precise limitations

`checker.py` is deterministic and uses Python's `cryptography` package solely for *classical Ed25519* signatures; fixture private seeds are intentionally derived from a publicly known deterministic string, so their values are **insecure for deployment**. The stage/final txids are SHA256 hashes of canonical JSON dictionaries excluding witness signatures. These are *mock txids*, not Bitcoin serialization, sighash or consensus. The checker explicitly verifies stage refund pre-signing, exact two-path stage policy, 3-of-3 cooperative completeness, honest last signature, both safe child paths, no native challenge pre-signature, stage and final outpoint binding, initial/final scope, certificate/receipt signatures, retained watcher bytes, 26 path/scope/signature mutants, four absent/forged-gate cases, and stage refund vs F UTXO conflict. It twice yielded byte-identical captured `output.json`: 48 assertions, 26 mutation rejections.

No proof-of-work, graph reachability under real Bitcoin consensus, cryptographic QPT experiment, actual original NP verifier, real LWE capsule, native PQ signature or measured network inclusion is implemented. This is a useful protocol cut with real classical fixture signatures and an exact full-manifest model, not a cryptographic release solution.

## 7. Next required research handoff

Resume **SOURCE-gated release**, not another funding improvement: choose a single classical-PPT witness-free public capsule `Comp` which is bound to the SCFB/RSEG `x` and `vk_C`. Explicitly instantiate the adversarial source distribution and its *joint* LWE challenge simulation. Derive all-witness same-precommitted-capability correctness and hard TRUE / FALSE unauthorized recovery -> ORIGINAL witness or independent QPT break for the **entire** public setup. If the candidate requires secret-dependent public correctness proofs, include its actual QPT simulator in the proof rather than assuming one. The SCFB/RSEG stage cut is ready as a **conditional protocol wrapper only** if that missing source construction is eventually established.

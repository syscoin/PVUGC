#!/usr/bin/env python3
"""RSEG: an abstract, *NON-BITCOIN*, deterministic Ed25519 ceremony checker.

This program checks a path-cut and staged funding manifest with genuine classical
Ed25519 signatures. It implements neither QPT security nor Bitcoin serialization,
not a witness-KEM, nor the original NP/evidence verifier. Deterministic test keys
are knowingly public and never secure for real assets.
"""
import copy
import hashlib
import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

RUN = 'RSEG-2026-10-31'
SEED_DOMAIN = b'PUBLIC-RESEARCH-FIXTURE-DO-NOT-USE-FOR-ASSETS'
CASES = 0

def check(v, reason):
    global CASES
    CASES += 1
    if not v:
        raise AssertionError(f'{CASES}: {reason}')

def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')

def H(domain, x):
    return hashlib.sha256(b'RSEG-v1|' + domain.encode('ascii') + b'|' + enc(x)).hexdigest()

def fixture_key(role):
    # NOT cryptographically confidential: the domain and role are in source.
    seed = hashlib.sha256(SEED_DOMAIN + b'|' + role.encode('ascii')).digest()
    private = Ed25519PrivateKey.from_private_bytes(seed)
    public = private.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return private, public.hex()

KEYS = {role: fixture_key(role) for role in
        ['depositor','honest_coop','coop_a','coop_b','setup_auth','watcher',
         'challenge','safe_0','safe_1','safe_2']}

def signature(role, domain, obj):
    return KEYS[role][0].sign(bytes.fromhex(H(domain,obj))).hex()

def verify_key(pub, domain, obj, sig):
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(
            bytes.fromhex(sig), bytes.fromhex(H(domain,obj)))
        return True
    except (ValueError, TypeError, Exception):
        return False

def pub(role):
    return KEYS[role][1]

SCOPE = {
    'network':'mock-testnet', 'relation_id':'ORIGINAL-NP-digest-42',
    'claim':'burn-transaction-claim-17', 'branch':'incompatible-tag',
    'anchors':['BTC-window-start','BTC-window-end'],
    'window':{'start_height':30000,'end_height':30100},
    'credential':{'type':'bearer','claim_scope':'claim17/path_challenge'},
    'source':'mock-SYS/BTC-source-not-verified'
}

STAGE_SCRIPT = {
    'kind':'model-stage-NofN-or-refund',
    # Bind the setup-only certificate key and the watcher policy to the
    # stage UTXO itself, without ever committing to a yet-unknown txid.
    'scope_template_digest':H('pre-stage-scope',SCOPE),
    'setup_auth_vk':pub('setup_auth'),
    'authorized_watcher_vks':[pub('watcher')],
    'paths':[
        {'path':'coop','signers':[pub('coop_a'),pub('coop_b'),pub('honest_coop')],
         'threshold':3,'locktime':0},
        {'path':'refund','signers':[pub('depositor')],
         'threshold':1,'locktime':100}
    ], 'no_key_path':True
}

FINAL_DESCRIPTOR = {
    'kind':'model-final-native-signature-graph',
    'challenge':{'signer':pub('challenge'), 'no_pre_signature':True,
                 'branch':'incompatible-tag','credential':'claim17/path_challenge'},
    'safe_paths':[
        {'path':'timeout_payout','signers':[pub('safe_0'),pub('safe_1'),pub('safe_2')],
         'threshold':3,'locktime':160},
        {'path':'resolve_safe','signers':[pub('safe_0'),pub('safe_1'),pub('safe_2')],
         'threshold':3,'locktime':170}
    ], 'no_key_path':True
}


def synthesize():
    stage_output = {'script':STAGE_SCRIPT,'value':10000000}
    stage_funding = {'inputs':[{'prevout':'depositor-coin-0','sequence':0xffffffff}],
                     'outputs':[stage_output], 'locktime':0, 'version':2}
    stage_id = H('mock-txid-excluding-witness',stage_funding)
    stage_outpoint = {'txid':stage_id,'vout':0}
    stage_refund = {'inputs':[{'prevout':stage_outpoint,'sequence':100}],
                    'outputs':[{'destination':'depositor-refund','value':9990000}],
                    'version':2,'locktime':100}
    refund_sig = signature('depositor','stage-refund-sighash-all',stage_refund)
    # Stage funding is released only if the pre-signed refund path exists.
    check(verify_key(pub('depositor'),'stage-refund-sighash-all',stage_refund,refund_sig),
          'pre-funding refund sig invalid')
    stage_fund_sig = signature('depositor','stage-funding-sighash-all',stage_funding)
    final_funding = {'inputs':[{'prevout':stage_outpoint,'sequence':0xffffffff}],
                     'outputs':[{'script':FINAL_DESCRIPTOR,'value':9980000}],
                     'version':2,'locktime':0}
    final_id = H('mock-txid-excluding-witness',final_funding)
    final_outpoint = {'txid':final_id,'vout':0}
    original = {'scope':SCOPE,'stage_outpoint':stage_outpoint,
                'final_outpoint':final_outpoint,
                'funding_commitment':H('final-funding',final_funding),
                'descriptor_commitment':H('final-descriptor',FINAL_DESCRIPTOR),
                'challenge_vk':pub('challenge')}
    # Capsule deliberately opaque: NO SOURCE correctness is asserted.
    capsule = {'type':'UNINSTANTIATED-WKEM','original_digest':H('original',original),
               'native_vk':pub('challenge'),
               'payload':'opaque-randomness-placeholder-no-release'}
    related = {'type':'UNINSTANTIATED-RELATED-CAPSULE',
               'original_digest':H('original',original),
               'payload':'opaque-related-placeholder'}
    children={}
    safe_sigs={}
    for path in FINAL_DESCRIPTOR['safe_paths']:
        tx={'inputs':[{'prevout':final_outpoint,'path':path['path']}],
            'outputs':[{'destination':path['path']+'-policy-beneficiary',
                        'value':9960000}],
            'locktime':path['locktime'],'version':2}
        children[path['path']]=tx
        safe_sigs[path['path']]={role:signature(role,'final-safe-sighash-all',tx)
                                for role in ['safe_0','safe_1','safe_2']}
    manifest={'stage_script':STAGE_SCRIPT,'stage_funding':stage_funding,
              'stage_fund_sig':stage_fund_sig, 'stage_outpoint':stage_outpoint,
              'refund':stage_refund,'refund_signature':refund_sig,
              'final_descriptor':FINAL_DESCRIPTOR,
              'final_funding':final_funding, 'final_outpoint':final_outpoint,
              'original':original,'capsule':capsule,'related_capsules':[related],
              'children':children,'safe_signatures':safe_sigs,
              'policy':{'watcher':'one independently honest','no_challenge_presign':True}}
    manifest_hash=H('signed-manifest',manifest)
    certificate=signature('setup_auth','scope-certificate',
                          {'u_stage':stage_outpoint,'u_final':final_outpoint,
                           'manifest_hash':manifest_hash})
    watcher_store={manifest_hash:enc(manifest)}
    watcher_receipt=signature('watcher','pre-final-data-availability',
                              {'u_final':final_outpoint,'manifest_hash':manifest_hash,
                               'accepted':True})
    return manifest,certificate,watcher_receipt,watcher_store


def validated(m,cert,receipt,store):
    # These exact checks are simulated policy, NOT Bitcoin scripts.
    stage=m['stage_funding']; final=m['final_funding']
    s=m['stage_outpoint']; u=m['final_outpoint']; x=m['original']
    if m['stage_script']!=STAGE_SCRIPT or m['final_descriptor']!=FINAL_DESCRIPTOR:
        return False
    if m['stage_script']['scope_template_digest']!=H('pre-stage-scope',SCOPE):
        return False
    if m['stage_script']['setup_auth_vk']!=pub('setup_auth'):
        return False
    if m['stage_script']['authorized_watcher_vks']!=[pub('watcher')]:
        return False
    if stage['outputs'][0]['script']!=STAGE_SCRIPT: return False
    if stage['outputs'][0]['value']!=10000000: return False
    if s!={'txid':H('mock-txid-excluding-witness',stage),'vout':0}:return False
    if final['inputs']!=[{'prevout':s,'sequence':0xffffffff}]:return False
    if final['outputs']!=[{'script':FINAL_DESCRIPTOR,'value':9980000}]:return False
    if u!={'txid':H('mock-txid-excluding-witness',final),'vout':0}:return False
    if x!={'scope':SCOPE,'stage_outpoint':s,'final_outpoint':u,
           'funding_commitment':H('final-funding',final),
           'descriptor_commitment':H('final-descriptor',FINAL_DESCRIPTOR),
           'challenge_vk':pub('challenge')}:return False
    if m['capsule']['original_digest']!=H('original',x):return False
    if m['capsule']['native_vk']!=pub('challenge'):return False
    if any(c['original_digest']!=H('original',x) for c in m['related_capsules']):
        return False
    refund=m['refund']
    if refund['inputs']!=[{'prevout':s,'sequence':100}]:return False
    if refund['locktime']!=100 or refund['outputs']!=[{'destination':'depositor-refund','value':9990000}]:return False
    if not verify_key(pub('depositor'),'stage-refund-sighash-all',refund,m['refund_signature']):return False
    if not verify_key(pub('depositor'),'stage-funding-sighash-all',stage,m['stage_fund_sig']):return False
    if set(m['children'])!={'timeout_payout','resolve_safe'}:return False
    if set(m['safe_signatures'])!=set(m['children']):return False
    for p in FINAL_DESCRIPTOR['safe_paths']:
        path=p['path']; tx=m['children'][path]
        if tx['inputs']!=[{'prevout':u,'path':path}]:return False
        if tx['locktime']!=p['locktime']:return False
        if tx['outputs']!=[{'destination':path+'-policy-beneficiary','value':9960000}]:return False
        if set(m['safe_signatures'][path])!={'safe_0','safe_1','safe_2'}:return False
        for role,sig in m['safe_signatures'][path].items():
            if not verify_key(pub(role),'final-safe-sighash-all',tx,sig):return False
    if m['policy']!={'watcher':'one independently honest','no_challenge_presign':True}:
        return False
    h=H('signed-manifest',m)
    if not verify_key(pub('setup_auth'),'scope-certificate',
           {'u_stage':s,'u_final':u,'manifest_hash':h},cert):return False
    if not verify_key(pub('watcher'),'pre-final-data-availability',
           {'u_final':u,'manifest_hash':h,'accepted':True},receipt):return False
    if store.get(h)!=enc(m):return False
    return True


def cooperative_ready(m, signatures):
    if set(signatures)!={'coop_a','coop_b','honest_coop'}:return False
    return all(verify_key(pub(role),'stage-coop-sighash-all',m['final_funding'],signature)
               for role,signature in signatures.items())


def main():
    m,cert,receipt,store=synthesize()
    check(validated(m,cert,receipt,store),'valid ceremony rejected')
    stage=m['stage_funding'];F=m['final_funding'];refund=m['refund']
    stage_id=m['stage_outpoint']['txid']; final_id=m['final_outpoint']['txid']
    check(verify_key(pub('depositor'),'stage-funding-sighash-all',stage,m['stage_fund_sig']),
          'not refund-protected before first deposit')
    check(verify_key(pub('depositor'),'stage-refund-sighash-all',refund,m['refund_signature']),
          'not pre-signed refund')
    check(not cooperative_ready(m,{'coop_a':signature('coop_a','stage-coop-sighash-all',F),
                                   'coop_b':signature('coop_b','stage-coop-sighash-all',F)}),
          '2 of 3 forged cooperative spend')
    sigs={role:signature(role,'stage-coop-sighash-all',F)
          for role in ['coop_a','coop_b']}
    check(validated(m,cert,receipt,store),'honest signer policy should approve')
    sigs['honest_coop']=signature('honest_coop','stage-coop-sighash-all',F)
    check(cooperative_ready(m,sigs),'honest signer completion denied')
    check(H('mock-txid-excluding-witness',F)==final_id,'final txid changed after signing')
    check(H('mock-txid-excluding-witness',stage)==stage_id,'stage txid changed')
    check(m['original']['challenge_vk']==pub('challenge'), 'wrong challenge key')
    check(not any('challenge' in p for p in m['safe_signatures']),
          'challenge must be fresh and never pre-signed')
    check(refund['locktime']==100 and m['stage_script']['paths'][1]['locktime']==100,
          'refund path impossible after abort')
    check(final_id!=stage_id,'two-stage collapse')
    # Abort is meaningful: without readiness, honest coop signature MUST be absent.
    abort_sigs={role:signature(role,'stage-coop-sighash-all',F)
                for role in ['coop_a','coop_b']}
    check(not cooperative_ready(m,abort_sigs),'abort bypass')
    check(verify_key(pub('depositor'),'stage-refund-sighash-all',refund,m['refund_signature']),
          'abort lost refund')
    # Finalization race: both transactions can be independently valid after maturity;
    # actual UTXO spends are mutually exclusive, not a guaranteed refund win.
    check(m['stage_outpoint']==refund['inputs'][0]['prevout']==F['inputs'][0]['prevout'],
          'refund/cooperative branch do not compete for identical outpoint')
    # Scope/mutation checks: copied signatures must fail against any substituted data.
    mutants=[]
    def mutate(location, value):
        z=copy.deepcopy(m)
        cursor=z
        for item in location[:-1]:cursor=cursor[item]
        cursor[location[-1]]=value
        mutants.append((str(location),z))
    mutate(('original','scope','claim'),'different-claim')
    mutate(('original','scope','branch'),'different-branch')
    mutate(('original','scope','window','end_height'),30101)
    mutate(('original','stage_outpoint','txid'),'00'*32)
    mutate(('original','final_outpoint','txid'),'00'*32)
    mutate(('original','challenge_vk'),'00'*32)
    mutate(('original','relation_id'),'different-relation')
    mutate(('capsule','payload'),'other-capsule')
    mutate(('capsule','native_vk'),'11'*32)
    mutate(('related_capsules',0,'payload'),'related-capsule-mutated')
    mutate(('stage_script','paths',0,'threshold'),2)
    mutate(('stage_script','scope_template_digest'),'00'*32)
    mutate(('stage_script','setup_auth_vk'),'00'*32)
    mutate(('stage_script','authorized_watcher_vks',0),'00'*32)
    mutate(('final_descriptor','no_key_path'),False)
    mutate(('final_funding','inputs',0,'prevout','txid'),'11'*32)
    mutate(('final_funding','outputs',0,'value'),123)
    mutate(('stage_funding','outputs',0,'value'),123)
    mutate(('stage_funding','inputs',0,'prevout'),'other-coin')
    mutate(('refund','locktime'),0)
    mutate(('refund_signature',),'11'*64)
    mutate(('children','timeout_payout','locktime'),0)
    mutate(('children','resolve_safe','inputs',0,'prevout','txid'),'11'*32)
    mutate(('safe_signatures','timeout_payout','safe_2'),'00'*64)
    mutate(('safe_signatures','resolve_safe','safe_0'),'00'*64)
    mutate(('policy','no_challenge_presign'),False)
    for name,z in mutants:
        check(not validated(z,cert,receipt,store),'mutation accepted: '+name)
    for name, c, r, s in [
        ('missing-certificate','00'*64,receipt,store),
        ('missing-receipt',cert,'00'*64,store),
        ('missing-watcher-storage',cert,receipt,{}),
        ('false-storage-bytes',cert,receipt,{H('signed-manifest',m):b'tampered'}),
    ]:
        check(not validated(m,c,r,s),'gate accepted: '+name)
    # Additional independent fixture: a forged final signature from another key fails.
    sigs_bad=dict(sigs);sigs_bad['honest_coop']=signature('coop_a','stage-coop-sighash-all',F)
    check(not cooperative_ready(m,sigs_bad),'honest key substituted')
    # Funding new output with same descriptor cannot be represented as authorized claim.
    different_final=copy.deepcopy(F); different_final['outputs'][0]['value']+=1
    check(H('mock-txid-excluding-witness',different_final)!=final_id,
          'unsolicited distinct funding should have new outpoint')
    result={
      'run':RUN,'checker':'cryptography Ed25519 (classical, non-PQ) and mock txids',
      'assertions_passed':CASES, 'mutations_rejected':len(mutants),
      'certificate_scope_bound':True,'related_capsule_binding':True,
      'watcher_da_and_presign_gate':True,'staging_refund_prepared_before_funding':True,
      'one_honest_coop_signer_suffices_for_stage_cut':True,
      'safety_claim':'only policy-authorized final transition; refund liveness requires inclusion',
      'not_proved':['witness KEM','SOURCE simulation','QPT cryptography',
                    'real Bitcoin consensus','timely inclusion','malicious setup with key retention'],
      'stage_txid_fixture':stage_id,'final_txid_fixture':final_id}
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__': main()

#!/usr/bin/env python3
"""R182: exact Bitcoin transaction-serialization and BIP341 input-local annex
hashes, plus SegWit witness-commitment binding. Synthetic signatures/headers; NO
consensus script execution, mined PoW, source verifier, or WKEM.
"""
import hashlib, json, struct

def sha(b): return hashlib.sha256(b).digest()
def hd(b): return sha(sha(b))
def compact(n):
    if n<253: return bytes([n])
    if n<65536: return b'\xfd'+struct.pack('<H',n)
    if n<2**32: return b'\xfe'+struct.pack('<I',n)
    return b'\xff'+struct.pack('<Q',n)
def vi(b): return compact(len(b))+b
def vec(xs): return compact(len(xs))+b''.join(xs)
def u4(n):return struct.pack('<I',n)
def u8(n):return struct.pack('<Q',n)
def out(value, script):return u8(value)+vi(script)
def inp(prev, vout, script=b'',seq=0xfffffffe):return prev+u4(vout)+vi(script)+u4(seq)
def tagged_hash(tag, msg):
    k=sha(tag.encode())
    return sha(k+k+msg)

class Tx:
    def __init__(self,vin,vout,witness=None,ver=2,lock=0):
        self.vin=list(vin);self.vout=list(vout);self.witness=[list(x) for x in witness] if witness else []
        self.ver=ver;self.lock=lock
    def stripped(self):
        return (u4(self.ver)+vec(self.vin)+vec(self.vout)+u4(self.lock))
    def serial(self):
        if not self.witness:return self.stripped()
        return (u4(self.ver)+b'\x00\x01'+vec(self.vin)+vec(self.vout)
                +b''.join(vec([vi(x) for x in items]) for items in self.witness)
                +u4(self.lock))
    @property
    def txid(self):return hd(self.stripped())
    @property
    def wtxid(self):return hd(self.serial())

def bip341_default(tx, idx, prevouts, amounts, scripts, sequences):
    """Current-input key-path hash, no annex on input0.
    All sighashes default, no ANYONECANPAY, no tapleaf extension.
    """
    if len(prevouts)!=len(tx.vin) or len(amounts)!=len(tx.vin) or len(scripts)!=len(tx.vin):
        raise ValueError('wrong input count')
    annex=None
    if tx.witness and tx.witness[idx] and tx.witness[idx][-1].startswith(b'\x50'):
        annex=tx.witness[idx][-1]
    spend_type = int(annex is not None)
    msg=(b'\x00' + u4(tx.ver)+u4(tx.lock)
        +sha(b''.join(prevouts)) +sha(b''.join(u8(x) for x in amounts))
        +sha(b''.join(vi(s) for s in scripts))
        +sha(b''.join(u4(x) for x in sequences))
        +sha(b''.join(tx.vout)) +bytes([spend_type])+u4(idx))
    if annex is not None:msg+=sha(vi(annex))
    return tagged_hash('TapSighash',b'\x00'+msg)

def merkle(a,b):return hd(a+b)

def build_fixture(a, tweak=0):
    # A preallocated vault input followed by an authorization-token input.
    prev0=sha(b'R182-vault-outpoint');prev1=sha(b'R182-auth-token')
    sequences=[0xfffffffe,0xfffffffd]
    vin=[inp(prev0,0,seq=sequences[0]),inp(prev1,3,seq=sequences[1])]
    # P2TR programs are placeholders; no signatures validated by script.
    s0=b'\x51\x20'+sha(b'R182-vault-public-key')
    s1=b'\x51\x20'+sha(b'R182-notary-public-key')
    amounts=[1234567,40000]
    vout=[out(1194567,b'\x51\x20'+sha(b'R182-asserted-output'))]
    annex=b'\x50'+a
    tx=Tx(vin,vout,witness=[[b'\x17'*64],[b'\x27'*64,annex]])
    return tx, [prev0+u4(0),prev1+u4(3)], amounts,[s0,s1],sequences

def coinbase_for_witness(wtxid):
    reserved=bytes(32)
    root=merkle(bytes(32),wtxid) # coinbase wtxid leaf is zero
    commitment=hd(root+reserved)
    coinbase_script=b'\x6a\x24\xaa\x21\xa9\xed'+commitment
    vin=[inp(bytes(32),0xffffffff,b'\x02\x01\x00',0xffffffff)]
    tx=Tx(vin,[out(50_00000000, b'\x51'),out(0,coinbase_script)],witness=[[reserved]])
    return root,commitment,tx

def verify_inclusion(tx, coinbase_tx):
    # For the 2-tx synthetic block, leaf index=1. Verify an actual script
    # commitment, not a root supplied by the challenger.
    root=merkle(bytes(32),tx.wtxid)
    script=coinbase_tx.vout[1][9:] # 8-byte value prefix AND 1-byte CompactSize script length
    assert script[:6]==b'\x6a\x24\xaa\x21\xa9\xed'
    # witness reserved field in the coinbase
    reserved=coinbase_tx.witness[0][0]
    return hd(root+reserved)==script[6:38]

def run():
    results={'distinct_annex_same_txid':0,'distinct_annex_distinct_wtxid':0,
      'vault_own_input_sighash_unchanged':0,'notary_own_input_sighash_changes':0,
      'original_witness_commitment_accepts':0,'alternate_annex_in_old_root_rejected':0,
      'bitcoin_parent_txid_root_distinguishes_variants':0,'bound_wtxid_anchor_blocks_substitution':0,
      'unbound_txid_only_replay_risk':0,'fork_reset_requirement':0}
    for i in range(64):
        a=sha(b'activated-claim-A'+u4(i));b=sha(b'activated-claim-B'+u4(i))
        tA,pA,amA,spA,sqA=build_fixture(a)
        tB,pB,amB,spB,sqB=build_fixture(b)
        assert tA.txid==tB.txid;results['distinct_annex_same_txid']+=1
        assert tA.wtxid!=tB.wtxid;results['distinct_annex_distinct_wtxid']+=1
        s0A=bip341_default(tA,0,pA,amA,spA,sqA)
        s0B=bip341_default(tB,0,pB,amB,spB,sqB)
        s1A=bip341_default(tA,1,pA,amA,spA,sqA)
        s1B=bip341_default(tB,1,pB,amB,spB,sqB)
        assert s0A==s0B;results['vault_own_input_sighash_unchanged']+=1
        assert s1A!=s1B;results['notary_own_input_sighash_changes']+=1
        rootA,commA,cbA=coinbase_for_witness(tA.wtxid)
        rootB,commB,cbB=coinbase_for_witness(tB.wtxid)
        assert verify_inclusion(tA,cbA);results['original_witness_commitment_accepts']+=1
        assert not verify_inclusion(tB,cbA);results['alternate_annex_in_old_root_rejected']+=1
        # Synthetic Bitcoin block header's transaction merkle root binds
        # coinbase txid which includes the witness commitment output.
        pmA=merkle(cbA.txid,tA.txid);pmB=merkle(cbB.txid,tB.txid)
        assert pmA!=pmB;results['bitcoin_parent_txid_root_distinguishes_variants']+=1
        # A claim can be coupled to an actually included wtxid+BTC block,
        # not merely to the pre-signed vault-spend txid.
        active_id=(pmA,tA.wtxid)
        assert active_id!=(pmB,tB.wtxid);results['bound_wtxid_anchor_blocks_substitution']+=1
        assert (tA.txid,pA[0])==(tB.txid,pB[0]);results['unbound_txid_only_replay_risk']+=1
        # Conflicting Bitcoin histories may include distinct witnesses for
        # the SAME txid. A reset must use the actually authenticated branch.
        assert (pmA,tA.wtxid)!=(pmB,tB.wtxid)
        results['fork_reset_requirement']+=1
    results['assertions']=sum(results.values())
    results['implementation_scope']='actual Bitcoin SHA256d serializers/commitments + input-local BIP341 SIGHASH_DEFAULT digest; symbolic nonverified input signatures; no mining'
    results['not_included']=['valid signatures','Bitcoin consensus/light-client qualification','Syscoin AuxPoW tagging','hash-only Build/Open','QPT security','malicious setup']
    return results
if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))

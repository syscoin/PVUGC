#!/usr/bin/env python3
"""R187 sparse-Merkle uniqueness/collision extraction test.
Not original Syscoin registry, full source verifier, KEM, or QPT test.
"""
import hashlib, json, random
from collections import Counter

C=Counter()

def H(label,*parts,bits=256):
    data=len(label).to_bytes(2,'big')+label
    for p in parts:data+=len(p).to_bytes(4,'big')+p
    return hashlib.sha256(data).digest()[:bits//8]

def leaf(i,value,bits=256):
    return H(b'EMPTY',bits=bits) if value is None else H(b'OCCUPIED',i.to_bytes(2,'big'),value,bits=bits)

def parent(a,b,bits=256):return H(b'INTERNAL',a,b,bits=bits)

def make_tree(entries,depth=8,bits=256):
    layers=[[leaf(i,entries.get(i),bits) for i in range(1<<depth)]]
    for _ in range(depth):
        old=layers[-1]
        layers.append([parent(old[j],old[j+1],bits) for j in range(0,len(old),2)])
    return layers

def proof(layers,i):
    out=[]
    for layer in layers[:-1]:
        out.append(layer[i^1]);i>>=1
    return out

def trace(i,v,p,bits=256):
    u=leaf(i,v,bits)
    arr=[]
    for s in p:
        lr=(s,u) if i&1 else (u,s)
        out=parent(*lr,bits=bits)
        arr.append((lr,out))
        u=out;i>>=1
    return arr

def verify(root,i,v,p,depth=8,bits=256):
    if not 0<=i<1<<depth or len(p)!=depth or any(len(s)!=bits//8 for s in p):return False
    return trace(i,v,p,bits)[-1][1]==root

def first_collision(i,v,p,q,bits=256):
    tp,tq=trace(i,v,p,bits),trace(i,v,q,bits)
    assert tp[-1][1]==tq[-1][1]
    for (a,y),(b,z) in zip(tp,tq):
        if a!=b and y==z:
            return (a,b,y)
    # They could diverge, then later reconverge; this still occurs at one parent
    # where its two distinct inputs share the same hash.
    raise AssertionError('equal roots, distinct paths without internal collision')

def cross_leaf_collision(i,v1,p1,v2,p2,bits=8):
    """Extract a hash collision from distinct leaf meanings under same root."""
    n1,n2=leaf(i,v1,bits),leaf(i,v2,bits)
    if v1!=v2 and n1==n2:
        return ('LEAF', (b'EMPTY' if v1 is None else b'OCCUPIED'),
                (b'EMPTY' if v2 is None else b'OCCUPIED'),n1)
    t1,t2=trace(i,v1,p1,bits),trace(i,v2,p2,bits)
    assert t1[-1][1]==t2[-1][1]
    for (a,y),(b,z) in zip(t1,t2):
        if a!=b and y==z:
            return ('INTERNAL',a,b,y)
    raise AssertionError('contradictory leaf accepted without hash collision')

def ck(ok,group):
    if not ok:raise AssertionError(group)
    C[group]+=1

def run():
    rng=random.Random(18720261110)
    for t in range(30):
        entries={}
        for j in range(17):
            idx=rng.randrange(256)
            entries[idx]=H(b'RECORD',t.to_bytes(2,'big'),j.to_bytes(2,'big'))
        layers=make_tree(entries)
        root=layers[-1][0]
        for _ in range(40):
            k=rng.randrange(256)
            p=proof(layers,k)
            v=entries.get(k)
            ck(verify(root,k,v,p),'honest_full_proof')
            ck(verify(root,k,None,p)==(k not in entries),'absence_iff_empty')
            ck(not verify(root,k,None,p[:-1]),'missing_sibling_rejected')
            ck(not verify(root,k,v,p[:-1]),'noncanonical_short_proof_rejected')
            altered=p[:]
            idx=rng.randrange(8)
            altered[idx]=H(b'BAD-SIBLING',t.to_bytes(2,'big'),bytes([idx]))
            ck(not verify(root,k,v,altered),'changed_sibling_rejected')
            ck(not verify(root,k,v,p,depth=7),'wrong_depth_rejected')
            v2=b'not-the-source-record' if v is not None else b'fabricated-burn'
            ck(not verify(root,k,v2,p),'false_leaf_rejected')
            other_entries=dict(entries)
            other_entries[k]=b'source-update'
            other_root=make_tree(other_entries)[-1][0]
            ck(not verify(other_root,k,v,p),'alternate_source_root_rejected')
            ck(H(b'PATH-TOKEN',root,k.to_bytes(2,'big'),b''.join(p))==H(b'PATH-TOKEN',root,k.to_bytes(2,'big'),b''.join(proof(layers,k))),'canonical_token_identity')
    # Witness equivalence: many outer proofs can point to the same root, but the
    # Merkle absence component used by a fixed (root,k) has a unique path.
    for t in range(40):
        entries={5:H(b'RECORD',t.to_bytes(2,'big'))}
        layers=make_tree(entries)
        root=layers[-1][0]
        pa=proof(layers,37)
        for outer_metadata in range(10):
            # Source metadata is NOT validated: only illustrates the local path
            ck(verify(root,37,None,pa),'same_root_outer_witness_absence')
            ck(H(b'PATH-TOKEN',root,(37).to_bytes(2,'big'),b''.join(pa)) == H(b'PATH-TOKEN',root,(37).to_bytes(2,'big'),b''.join(proof(layers,37))),'same_root_token_invariant')
    # Adversarially construct two valid openings to the SAME weak Merkle root.
    # An explicit parent-hash collision MUST be returned.
    depth,bits=1,8
    root=parent(leaf(0,None,bits),bytes([0]),bits)
    witnesses={}
    for s in range(256):
        r=parent(leaf(0,None,bits),bytes([s]),bits)
        if r in witnesses and witnesses[r]!=s:
            p=[bytes([witnesses[r]])];q=[bytes([s])]
            ck(verify(r,0,None,p,depth,bits),'weak_first_proof_valid')
            ck(verify(r,0,None,q,depth,bits),'weak_second_proof_valid')
            a,b,out=first_collision(0,None,p,q,bits)
            ck(a!=b and H(b'INTERNAL',*a,bits=bits)==out==H(b'INTERNAL',*b,bits=bits),'weak_collision_extracted')
            witnesses_found={'first_sibling':witnesses[r],'second_sibling':s,'root':r.hex(),'collision_input1':(a[0].hex(),a[1].hex()),'collision_input2':(b[0].hex(),b[1].hex())}
            break
        witnesses[r]=s
    else:raise AssertionError('expected toy collision in 256 inputs')
    # A false empty proof for an occupied target and an honest occupancy proof
    # under the SAME root also imply a leaf/internal hash collision.
    occ_root_map={}
    target=b'actual-burn'
    for s in range(256):
        r=parent(leaf(0,target,8),bytes([s]),8)
        occ_root_map.setdefault(r,s)
    for s in range(256):
        r=parent(leaf(0,None,8),bytes([s]),8)
        if r in occ_root_map:
            p_bad=[bytes([s])]
            p_occ=[bytes([occ_root_map[r]])]
            ck(verify(r,0,None,p_bad,1,8),'weak_absence_for_occupied_root')
            ck(verify(r,0,target,p_occ,1,8),'weak_occupancy_for_same_root')
            witness=cross_leaf_collision(0,None,p_bad,target,p_occ,8)
            ck(witness[0] in ('INTERNAL','LEAF'),'cross_leaf_collision_extracted')
            break
    else:raise AssertionError('expected cross-leaf weak-hash collision')
    # Cryptographic construction check: a source-root changes across future
    # states, and the canonical token changes accordingly. No setup-time
    # universal token can be inferred from the uniqueness lemma.
    prior=make_tree({5:b'claim-valid'});future=make_tree({5:b'claim-valid',17:b'other'})
    k=37
    t0=H(b'PATH-TOKEN',prior[-1][0],k.to_bytes(2,'big'),b''.join(proof(prior,k)))
    t1=H(b'PATH-TOKEN',future[-1][0],k.to_bytes(2,'big'),b''.join(proof(future,k)))
    ck(t0!=t1,'future_state_token_not_frozen')
    return {'run':'R187-CANONICAL-R2', 'assertions':sum(C.values()),
        'groups':dict(sorted(C.items())),'weak_hash_collision_example':witnesses_found,
        'claims':'SHA Merkle path verification and toy collision extraction ONLY',
        'not_implemented':['actual Syscoin authenticated burn registry','future-source Build/Open','BTC/AuxPoW source verifier','native signature','QPT proof']}

if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))

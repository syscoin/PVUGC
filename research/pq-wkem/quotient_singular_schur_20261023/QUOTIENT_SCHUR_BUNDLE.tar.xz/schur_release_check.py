#!/usr/bin/env python3
"""Standalone small-field checker of quotient-singular 3x3 Schur WKEM gate.
Checks the exact gate, public matrices, typed SOURCE, rank and cost certificates.
NOT a false-instance hiding/QPT test, not production cryptography.
"""
import hashlib, itertools, json, math, random

F_POLY=0x13

def f_mul(a,b):
    result=0
    for _ in range(4):
        if b&1: result ^= a
        a <<= 1
        if a&16: a ^= F_POLY
        b >>= 1
    return result
FM=[[f_mul(a,b) for b in range(16)] for a in range(16)]
def f_pow(a,n):
    r=1
    while n:
        if n&1: r=FM[r][a]
        a=FM[a][a];n>>=1
    return r
def f_trace(a):
    t=0
    for _ in range(4):
        t^=a;a=FM[a][a]
    assert t in (0,1)
    return t
KAPPA=next(i for i in range(1,16) if f_trace(i)==1)
def e_mul(a,b):
    a0,a1=a&15,a>>4;b0,b1=b&15,b>>4
    p=FM[a1][b1]
    return (FM[a0][b0]^FM[p][KAPPA])|((FM[a0][b1]^FM[a1][b0]^p)<<4)
EM=[[e_mul(a,b) for b in range(256)] for a in range(256)]
def e_pow(a,n):
    r=1
    while n:
        if n&1:r=EM[r][a]
        a=EM[a][a]; n>>=1
    return r
EINV=[0]+[e_pow(i,254) for i in range(1,256)]
THETA=16
ASSERTS=0
def ensure(cond,msg=''):
    global ASSERTS
    ASSERTS+=1
    if not cond: raise AssertionError(f'assertion #{ASSERTS}: {msg}')

def rank(A):
    a=[row[:] for row in A];rr=0
    for c in range(len(a[0])):
        p=next((r for r in range(rr,len(a)) if a[r][c]),None)
        if p is None:continue
        a[rr],a[p]=a[p],a[rr]
        inv=EINV[a[rr][c]]
        for j in range(c,len(a[0])):a[rr][j]=EM[inv][a[rr][j]]
        for r in range(rr+1,len(a)):
            v=a[r][c]
            if v:
                for j in range(c,len(a[0])):a[r][j]^=EM[v][a[rr][j]]
        rr+=1
        if rr==len(a): break
    return rr

def mm(A,B):
    C=[[0]*len(B[0]) for _ in range(len(A))]
    for i,row in enumerate(A):
        for p,a in enumerate(row):
            if a:
                for j,b in enumerate(B[p]):
                    C[i][j]^=EM[a][b]
    return C

def xor_into(A,B):
    for i,row in enumerate(A):
        for j in range(len(row)):row[j]^=B[i][j]

def Z(e):return FM[e][e]^e^1
NODES=[i for i in range(1,16) if Z(i)!=0][:11]
L=len(NODES);n=2; k=7;h=2;N=2*L+h
ensure(L==11 and len(set(NODES))==11)

def shears(e,rng):
    b=[];a=[]
    for i in range(2):
        bi=rng.randrange(16)
        sq=bi^EM[THETA][f_pow(e,i)]
        ai=e_pow(sq,128)
        ensure(EM[ai][ai]==sq)
        b.append(bi);a.append(ai)
    return a,b,rng.randrange(256)

def node_gate(e,y,alpha,gamma):
    z,w1,w2,*rho=y
    a=w1^w2
    b=z
    c=0
    root_Z=f_pow(Z(e),8)
    root_e=f_pow(e,8)
    s=0
    for j,rr in enumerate(rho):s^=FM[FM[root_Z][f_pow(root_e,j)]][rr]
    eta=EM[gamma][z];beta=EM[EM[gamma][gamma]][z]
    for aa,w in zip(alpha,(w1,w2)):
        eta^=EM[aa][w]
        beta^=EM[EM[aa][aa]][w]
    v=s^eta
    return [[c^beta,a,v],[b,z,0],[v,0,z]]

def determinant3(g):
    # Characteristic-two det: sum over six permutations (sign is +).
    ans=0
    for p in itertools.permutations(range(3)):
        v=EM[EM[g[0][p[0]]][g[1][p[1]]]][g[2][p[2]]]
        ans^=v
    return ans

def source_t(e,y):
    z,w1,w2,*rho=y
    s=0
    for j,rr in enumerate(rho):s^=FM[FM[Z(e)][f_pow(e,j)]][FM[rr][rr]]
    return FM[z][w1^w2]^s

def expected_det(e,y,alpha,b):
    z,w1,w2,*rho=y
    d=[FM[wi][wi]^FM[z][wi] for wi in (w1,w2)]
    # For normalized z=1 this is the target characteristic-two extension check.
    assert z==1
    return source_t(e,y)^EM[EM[alpha[0]][alpha[0]]][d[0]]^EM[EM[alpha[1]][alpha[1]]][d[1]]

def cy(C,y):
    M=[[0]*N for _ in range(N)]
    for j,v in enumerate(y):
        if v:
            for i in range(N):
                for l in range(N):M[i][l]^=EM[v][C[j][i][l]]
    return M

def subkey(M,K):
    M=[row[:] for row in M]
    for i in range(N): M[i][i]^=K
    return M

def test_seed(seed):
    rng=random.Random(seed)
    sh=[shears(e,rng) for e in NODES]
    U=[[[rng.randrange(256) for _ in range(3)] for _ in range(N)] for _ in NODES]
    V=[[[rng.randrange(256) for _ in range(N)] for _ in range(3)] for _ in NODES]
    key=rng.randrange(1,256)
    C=[]
    for j in range(k):
        y=[int(a==j) for a in range(k)]
        M=[[0]*N for _ in range(N)]
        for t,e in enumerate(NODES):xor_into(M,mm(mm(U[t],node_gate(e,y,sh[t][0],sh[t][2])),V[t]))
        if j==0:
            for i in range(N):M[i][i]^=key
        C.append(M)
    counts={'true':0,'invalid_boolean':0,'nonboolean':0}
    checked=0
    # A deterministic, nontrivial Boolean quotient exhaustive sample (4^4 choices)
    for w1,w2 in itertools.product([0,1],repeat=2):
        for rho in itertools.product([0,1,2,3],repeat=4):
            y=(1,w1,w2,*rho)
            valid=(w1==w2 and rho==(0,0,0,0))
            vs=0
            for j,e in enumerate(NODES):
                g=node_gate(e,y,sh[j][0],sh[j][2]);d=determinant3(g)
                ensure(d==expected_det(e,y,sh[j][0],sh[j][1]))
                if d:vs+=1
                ensure(rank(g)==(3 if d else 2))
            ensure(vs==0 if valid else vs>=L-5)
            counts['true' if valid else 'invalid_boolean']+=1
            checked+=1
    # F-typed non-Boolean vectors & unrestricted F quotient sampled, plus RS code bound
    for t in range(1200):
        w1=rng.randrange(16);w2=rng.randrange(16)
        if w1 in (0,1) and w2 in (0,1):w1=2
        rho=[rng.randrange(16) for _ in range(4)]
        y=(1,w1,w2,*rho)
        vs=0
        for j,e in enumerate(NODES):
            g=node_gate(e,y,sh[j][0],sh[j][2]);d=determinant3(g)
            ensure(d==expected_det(e,y,sh[j][0],sh[j][1]))
            delta1=FM[w1][w1]^w1;delta2=FM[w2][w2]^w2
            ensure((d>>4)==(delta1^FM[e][delta2]))
            if d:vs+=1
        ensure(vs>=L-n+1)
        counts['nonboolean']+=1
    for w1,w2 in [(0,0),(1,1)]:
        y=(1,w1,w2,0,0,0,0)
        M=cy(C,y)
        ensure(rank(subkey(M,key))<=2*L)
        for trial in range(256):
            if trial!=key:ensure(rank(subkey(M,trial))>2*L)
    for t in range(20):
        w1=rng.randrange(16);w2=rng.randrange(16)
        rho=[rng.randrange(16) for _ in range(4)]
        y=(1,w1,w2,*rho)
        M=cy(C,y)
        for trial in [key,key^1,key^7]:ensure(rank(subkey(M,trial))>2*L)
    # The public quotient derivative is rank TWO locally, not FOUR.
    for j,e in enumerate(NODES):
        z=[0]*k;z[3]=1
        g=node_gate(e,z,sh[j][0],sh[j][2]);
        ensure(rank(g)==2)
        ensure(g[0][2]==f_pow(Z(e),8))
    return {'seed':seed,'key':key,'counts':counts,'N':N,'k':k,'L':L,'quotient_local_rank':2,'valid_local_rank':2,'invalid_local_rank':3}

def certificate():
    n=11000;m=16000;k=n+m;base_bits=128;outer_bits=256
    h=117;T=234;r=375;L=m-1+r;N=2*L+h
    q=1<<base_bits;Q=1<<outer_bits
    A=m+T-2
    ensure((1<<(n+1))*math.comb(L,T-1)*pow(A,r)*(1<<135)<pow(q,r-T+1))
    ensure(16*(h+1)*pow(q,k-1)*(1<<135)<pow(Q,h*h))
    ensure(4*pow(q,k+1)*(1<<135)<pow(Q,h*h))
    ensure(T>=2*h and L-n+1>=T)
    ensure(q>=2*r*(2*m-2+r))
    package=k*N*N*32
    prev=917605083744000
    return {'q_bits':base_bits,'outer_bits':outer_bits,'n':n,'m':m,'k':k,'r':r,'T':T,'h':h,'L':L,'N':N,'gate_size':3,'honest_rank_bound':2*L,'outer_rank_gap_per_bad_node':1,'public_coeff_bytes':package,'previous_coeff_bytes':prev,'relative_public_growth_pct':round(100*(package/prev-1),6),'secret_outer_factor_bytes':2*L*N*3*32,'semantic_scope':'honest-setup supplied-pair only','each_bad_setup_term_lt':'2^-135','sum_bad_setup_lt':'2^-133'}

if __name__=='__main__':
    ensure(all(EM[x][EINV[x]]==1 for x in range(1,256)))
    ensure(all(e_pow(x,256)==x for x in range(256)))
    tests=[test_seed(seed) for seed in (197,233)]
    print(json.dumps({'candidate':'quotient-singular 3x3 Schur Frobenius QAP release','proof_scope':'honest-setup supplied pair only; no QPT key secrecy','toy':tests,'large':certificate(),'assertions':ASSERTS},indent=2,sort_keys=True))

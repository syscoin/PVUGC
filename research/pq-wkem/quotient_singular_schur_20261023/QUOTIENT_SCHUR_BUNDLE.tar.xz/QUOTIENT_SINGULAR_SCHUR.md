# Quotient-singular Schur release: a repaired full-rank-moment interface

**23 October 2026 — constructive, limited result.** Exact starting `syscoin/PVUGC#1` SHA `de75993dee8c7e1b8a954a1bbcea2248700424b2`, branch `research/pq-wkem-validation-20260918`, draft/open/unmerged. This modifies **only the mathematical local release gate** of the existing extension-separated sampled Frobenius-QAP candidate. Its main constructive result is an explicit *3×3* gate that retains **every-ORIGINAL-witness same-capability recovery** and the existing simultaneous honest-setup **supplied (lambda,y) ⇒ ORIGINAL witness** theorem, while the quotient-coordinate subpencil now exposes only **rank-two**, rather than all rank-four, local factors. This removes the exact support-reconstruction premise of the previously demonstrated four-moment `ell(C0)=K` attack. It does **not** prove secrecy from the **complete public tensor**, including original-variable slices, or from arbitrary QPT processing. Do not promote to WKEM.

## Exact verified dependencies and novelty boundary

* Latest exact preceding candidate: `research/pq-wkem/extension_separated_shear_20261023/README.md`, blob `5e396d64825bc5e99a77beba090f87f5156fee70`, and exact archive blob `b3c8dffde56e719c70555d7ea754c5d31fa4241c`. Reuse its normalized sampled-QAP SOURCE distance, deterministic extension-field Booleanity code and independent two-sided rank bounds **without changing their distribution**. It had 4×4 alternating gate, rank 2/4 and quotient derivative rank 4, `r=237,T=h=117`.
* Earlier static quotient-subpencil observation, discussed at PR head `ef33ef4`: four quotient matrices `Q0..Q3` have moments `sum_e theta_e^j B_e`. In the 4×4 gate the `s_e` derivative `J` is invertible, hence `B_e=U_e J V_e` exposes the full local left/right gate subspaces. The baseline `M0` belongs to the public sum-of-bimodules built from those subspaces, allowing a linear annihilator to read `K` exactly. That conclusion is **not** repaired by QAP normality or more sampled nodes.
* Run 259, `research/pq-wkem/GLOBAL_FINGERPRINT_SOURCE_BINDING_RUN259.md`, blob `c7f3b77f0273ca1cbe6f0b31c1a086b8eb3acbf2`, provides independent global residual-to-ORIGINAL-source bindings, NOT key release or bare-key extraction. This new rank interface uses the immediately preceding sampled-QAP ORIGINAL-source extraction instead, and does not claim to extend Run 259's SIS theorem to a recovered bare key.
* Run 79 (`ANCHOR_SHIFT_MINRANK_RUN79.md`, blob `30084603c3b35c449be4e154f6d214533526d3c5`) previously analyzed low-rank masking/Fourier information and demonstrated why one masked linear statistic or an assumption named MinRank cannot establish full-transcript hiding. This continuation does **not** add a global random low-rank floor or claim that a fixed-functional masking lemma solves that gap. Its novelty is the explicit *rank-two-quotient 3×3 gate* preserving the *existing* QAP and the probabilistic supplied-source interface.

## Setup/Build, Encode, Recover, extraction and complete public output

Let `F=GF(2^128)` and `E=GF(2^256)` be a fixed public quadratic extension, `theta∈E\F`, and `x` fix the original claim-scoped Boolean R1CS, context, Bitcoin/Syscoin anchors, branch and intended native verifying key. The statement's R1CS and all sampling commitments are bound **before** selecting the randomized off-domain QAP tail. There are `n` original Boolean coordinates `w`, `m` R1CS rows, and `k=n+m` normalized SOURCE coordinates `y=(z0,w,rho)∈F^k`; `rho∈F^(m−1)` denotes the Frobenius-coded QAP quotient. Reuse the exact predecessor's `m−1` fixed off-domain nodes followed by `r` independent uniform tail nodes, with `L=m−1+r` nodes total. A normalized SOURCE node has public-linear forms `a_e(y), b_e(y), c_e(y), s_e(y)` satisfying

`a_e(y)b_e(y)+z0*c_e(y)+s_e(y)^2 = F_y(e)`.

Here `F_y` is precisely the predecessor's sampled-QAP numerator; `s_e` contains the Frobenius quotient and gives `F_y≡0` exactly for the unique encoding of a true ORIGINAL witness. In particular `partial s_e/partial rho_j = sqrt(Z(e))*sqrt(e)^j` and none of `a_e,b_e,c_e` depends on the quotient. Preserve the exact predecessor's private shears:

`eta_e(y)=gamma_e*z0+sum_i alpha_(e,i)*w_i`

`beta_e(y)=gamma_e^2*z0+sum_i alpha_(e,i)^2*w_i`

`alpha_(e,i)^2 = bmask_(e,i)+theta*e^(i−1)`, where `bmask∈F` is private uniform and `gamma_e∈E` private uniform. The local gate is now the **nonalternating 3×3 Schur gate**

```
                     [ c_e+beta_e   a_e       s_e+eta_e ]
     S_e(y) =        [ b_e          z0        0         ]
                     [ s_e+eta_e    0         z0        ]
```

All entries are **linear in y over E**. This last property is important: no hidden online helper or secret evaluation oracle is inserted. Sample private independent uniform `U_e∈E^(N×3)` and `V_e∈E^(3×N)`, independent of all shears, with `N=2L+h`. In an honest-erasure N-of-N setup, privately choose uniform `K∈E`, bind its intended native verification object to `x`, and publish exactly

`C_j = [j=0]*K*I_N + sum_(e=1)^L U_e*S_e(unit_j)*V_e ∈ E^(N×N)` for `j=0,...,k−1`.

Also publish the **whole** statement/R1CS, source encoding and normalization rule, base/extension field irreducible polynomials and embedding, QAP original/fixed/tail nodes, `theta`, full checking key and claim/branch/anchor/UTXO context, and complete ceremony and funding-graph transcript needed by a real implementation. Keep `K`, shears, U,V, and setup coins private/erased under the baseline; malicious setup, abort, complete graph and actual native signature are **not** implemented or proved.

`Encode(x,w)`: for **each** original valid Boolean witness, compute the unique QAP quotient `H` and its unique componentwise Frobenius square roots as in the exact predecessor, output normalized `y=(1,w,rho)∈F^k`. Distinct valid original witnesses may produce different intermediate vectors `y`.

`Recover(x,y)`: require `y∈F^k` and `z0=1` (public subfield/type check), form `C(y)=sum_j y_j C_j`, factor its characteristic polynomial over E, and find the unique `lambda∈E` for which `rank_E(C(y)-lambda I_N)≤2L`; check native verification-key/context binding, return `K=lambda`. The same K works for **every** valid original witness. All large evidence and rank computation are OFF CHAIN.

`SuppliedPairExtract(x,lambda,y)`: require `lambda∈E`, `y∈F^k`, `z0=1`, and the same rank threshold. Return the `w` coordinates. Except on the honest-setup event quantified below, they form an ORIGINAL satisfying Boolean witness and `lambda=K`. **No extraction algorithm from a bare K or native signature follows.**

## Lemma 1: exact local determinant, rank and quotient singularity

Over characteristic two, put `v=s_e+eta_e`. For any y,

`det S_e(y)=z0*( a_e*b_e + z0*(c_e+beta_e) + v^2 )`.

For normalized `z0=1`, the Frobenius square identity and `beta_e+eta_e²=sum_i alpha_(e,i)²*(w_i²+w_i)` imply

`det S_e(y) = [F_y(e)+sum_i bmask_(e,i)*delta_i] + theta*P_delta(e)`, where `delta_i=w_i²+w_i∈F` and `P_delta(T)=sum_i delta_i T^(i−1)∈F[T]`.

Hence every genuine Boolean accepted original witness gives `det S_e=0` at **every** node; any non-Boolean F-typed original w violates **at least L−n+1** nodes because `F⊕theta F` separates its nonzero Reed–Solomon codeword. For any normalized y, the bottom-right two-by-two block is identity, so `rank_E S_e(y)=2` if its determinant is zero and `3` otherwise. In contrast, the predecessor's 4×4 alternating gate has rank 2/4.

For quotient variable `rho_j`, only the `(1,3)` and `(3,1)` entries depend on `rho_j`; their derivative is `sqrt(Z(e))*sqrt(e)^j J`, with

`J = [[0,0,1],[0,0,0],[1,0,0]]`, and **rank(J)=2<3**.

Thus the quotient moment matrices are `Q_j=sum_e sqrt(e)^j B_e` with `B_e=sqrt(Z(e))*U_e J V_e` of rank at most 2. Even a perfect recovery of every B_e reveals only a **two-dimensional** local left and right support, NOT all three hidden gate coordinates. In particular the older inference `col(B_e)=col(U_e)` and `row(B_e)=row(V_e)` is no longer valid. This is a precise change to the attacked algebra, not proof of hiding from the other coefficient matrices.

## Lemma 2: fixed quotient-subpencil functionals receive an independent rank-L mask

This narrow lemma explains why the earlier `ell(C0)=K` calculation cannot simply be repeated. Give an analyst the entire quotient subpencil, and even reveal `U_e` columns 1 and 3, `V_e` rows 1 and 3 and *all gate coefficients*, **but not the second column/row of U_e/V_e, the nonquotient public matrices or C0**. Conditional on this information, the unexposed `u_e=U_e[:,2]` and `v_e=V_e[2,:]` are independent uniform over E. At the unit `z0` coordinate, the unknown contributions of one gate are

`u_e*v_e + a_e(unit_0)*U_e[:,1]*v_e + b_e(unit_0)*u_e*V_e[1,:]`.

Writing `u'_e=u_e+a_e(unit_0)*U_e[:,1]`, `v'_e=v_e+b_e(unit_0)*V_e[1,:]` turns this into `u'_e*v'_e` plus a publicly determined correction. Therefore, conditional on the specified exposure,

`C0 = K*I_N + D_known + sum_e u'_e*v'_e`, with independent **uniform** rank-one factors `(u'_e,v'_e)`.

For any linear functional `ell(M)=Tr(A^T M)` with `ell(I)=1`, chosen using only the exposed information (it may be adaptive to all quotient matrices), write `d=rank_E A≥1`, `Q=|E|`. Conditioning on the `u'` vectors, any one term `ell(u'_e v'_e)` is uniform over E unless `A^T u'_e=0`; the latter happens with probability `Q^(−d)`. Across independent nodes the resulting sum is **exactly** a mixture of uniform over E and a point mass at zero with mixture weight `Q^(−Ld)`. Thus

`TV( ell(C0), Uniform(E) | specified exposure, K ) = (1−1/Q)*Q^(−L*d) ≤ Q^(−L)`.

This remains valid for a fixed native verifying key derived from K because K only shifts the masked scalar. It proves that an **a priori quotient-subpencil-selected linear annihilator** has essentially no information about K, even if the two exposed gate factors per node are revealed. It does **not** cover choosing ell after inspecting C0, using other original-variable coefficient matrices, taking many correlated functionals, reconstructing all gate factors, multiple capsules with correlated coins, or coherent QPT evaluation. Accordingly this is **not** full-public-output hiding or an arbitrary key-recovery hardness reduction.

## Theorem 3: unchanged ORIGINAL-supplied-pair semantics with adjusted rank margin

Use the preceding exact sampled-QAP robust-distance lemma, now with `T` invalid Boolean violations and its exact setup error bound

`epsilon_Bool ≤ 2^(n+1) * binom(L,T−1) * (m+T−2)^r / q^(r−T+1)`.

Non-Boolean normalized F-values have ≥`L−n+1` violations deterministically. Assume `T≤L−n+1` and `T≥2h`. Every valid normalized SOURCE has `v(y)=0`, so its public shifted matrix has rank ≤`D=2L`. Every invalid normalized SOURCE has at least T rank-three gates, and random independent left/right outer factors make its shifted matrix exactly the distribution of `A_R B_R`, where `R=2L+v(y)≥2L+2h=N+h` and `A_R,B_R` are independent uniform over E. Standard rectangular full-rank counting gives

`epsilon_rank ≤16(h+1)*q^(k−1)*Q^(−h²)`.

For wrong `lambda≠K`, a rank≤`N−h` output would give an h-dimensional eigenspace with nonzero eigenvalue `lambda−K`. Union over h-subspaces, source y, and wrong scalars gives

`epsilon_wrong <4*q^(k−1)*Q^(1−h²)`.

Consequently with probability at least `1−epsilon_Bool−epsilon_rank−epsilon_wrong` over the honest setup, **every classical normalized (lambda,y) satisfying the public rank threshold** returns the *correct* K and an ORIGINAL Boolean R1CS witness. This is simultaneous over every y and lambda, so it survives an adaptively chosen classical supplied pair output by a QPT adversary, without QROM rewinding. It does **not** produce y from a bare recovered key/signature.

### Exact numerical certificate and resources

Set `q=2^128`, `Q=2^256`, `n=11000`, `m=16000`, `k=27000`, `r=375`, `L=16374`, `T=234`, `h=117`, `D=32748`, `N=32865`. The independent checker certifies each of the preceding *three* bad-setup bounds is strictly below `2^−135`, hence their sum `<3*2^−135<2^−133`. These are **supplied-pair** bounds, not QPT secrecy bounds. Source modulus/node-sampling conditions and `T≥2h` are checked with exact integers.

Published full matrices use `k*N²*32 = 933,213,506,400,000` bytes (**0.933214 decimal PB**), a **1.700996% cost increase** over the preceding 0.917605 PB, while reducing private `U,V` factor storage from 135,453,441,024 to **103,321,249,920 bytes (23.72% less)**. This is still hugely impractical. The 375 tail nodes compensate for losing one rather than two ranks per violated gate. No compact tensor encoding or native Bitcoin graph is assumed.

## Reproducible validation, limitations and next missing step

`schur_release_check.py` is independent pure Python. Its GF(16)⊂GF(256) synthetic fixture is **not** the actual full QAP; it evaluates *real public 3×3 gate-derived coefficient matrices* with 7 source coordinates, 11 distinct extension-separated nodes, two different valid witnesses and false/nonBoolean cases, including every 4^4 quotient from a fixed four-element subset for each Boolean assignment. The full SOURCE polynomial in the toy is `z0(w1+w2)+Z(T)*H(T)` with `Z(T)=T²+T+1`, guaranteeing that nonzero invalid Boolean cases do not vanish identically. It also tests full public-matrix rank selection and local quotient derivative rank. Two independent executions were byte-identical, and the checker completed **103,544 assertions**, `py_compile` and exact parameter inequalities. This is not statistical proof of key hiding or a quantum experiment.

**NEXT missing equation:** for the actual, fully published `k` nonquotient-plus-quotient matrix slices, native verifying key, claim auxiliary data, and multiple capsules, show that any unauthorized QPT obtaining K / a native accepted signature yields an accepted ORIGINAL representation or violates a specified independent standard PQ hardness assumption. In particular, the information-theoretic masking of one *quotient-only selected linear statistic* is **insufficient** because the nonquotient slices also depend on the unexposed local factors. The exact unresolved task is to show these extra public slices cannot synchronize the local `U_e,V_e` gauges and peel the hidden `(2,2)` Schur coordinate, or to replace the gate if they can. No generic MinRank/iO/RIO/WE assumption is presumed.

Pending that theorem, false-instance QPT hiding, malicious/retained-coin setup and abort security, native post-quantum Bitcoin signature/P2MR endpoint, and any practical package-size construction are **UNPROVED**. This continuation leaves production untouched and the PR open/draft/unmerged.

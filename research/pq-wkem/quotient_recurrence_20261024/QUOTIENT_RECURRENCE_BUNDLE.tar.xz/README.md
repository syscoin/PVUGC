# Pivot–Schur public quotient spectral recurrence: exact release-equivalent compression

**Construction continuation, 2026-10-24 UTC.** Repository `syscoin/PVUGC#1`, branch `research/pq-wkem-validation-20260918`, pinned predecessor `c8343d87d7ad880dd4aa2deed02d9f681e2c4569`. This is one constructive advance to the *same* pivot-twisted SL₂–Frobenius Schur witness-release carrier: an **exact, publicly computable two-slice representation for its entire Frobenius quotient tensor**. It removes 15,997 enormous published matrices in the illustrative parameter set, while retaining all prior mathematical/cryptographic uncertainty. It is not a release-security proof or a practical finished WKEM.

## 1. Exact starting algorithms and typed SOURCE

**Previous setup, unchanged.** Over `F=GF(2^128)` and `E=GF(2^256)`, R1CS source data have `n=11000` ORIGINAL Boolean variables and `m=16000` rows. The published sampled QAP uses `r=375`, `L=m−1+r=16374` distinct off-domain nodes, `k=n+m=27000` homogeneous source coordinates, and a `3×3` pivot–Schur local gate at each node. Each local gate has the exact published form

```
G_e(y) = [ C_e(y)    A*_e(y)    S_e(y) ]
         [ B*_e(y)   π_e(y)      0      ]
         [ S_e(y)    0           π_e(y) ]
```

with secret independent `U_e ∈ E^(N×3)`, `V_e ∈ E^(3×N)`, private `SL₂(F)` shears, private extension-separated Frobenius masks, and private pivot `μ_e`; `N=2L+h`, `h=165`. Only the original public coefficient matrices are distributed:

`C_j = [j=0] K I_N + Σ_e U_e G_e(unit_j) V_e`, `j=0,...,k−1`,

plus the already-public relation identity, claim/UTXO, branch, anchors/windows/context, checking key, and node description. ORIGINAL-valid witnesses have normalized `y=(1,w,ρ(w))∈F^k`; their distinct `w`/`ρ` are not canonicalized. The unchanged public acceptance rule finds the *same* field capability `K` via `rank_E(C(y)−K I_N)≤2L`. The inherited supplied-`F`-representation to ORIGINAL-witness result, conditional on the pinned honest setup and sampling, is **unchanged**. It is *not* a statement about bare-key recovery or signature-only forgery.

**One special, exact property of the CURRENT gate.** For pure quotient sources `y=(0,0,ρ)`, its private pivot and all original-source terms vanish, leaving

`G_e(0,0,ρ) = s_e(ρ) J`, where `J=E_13+E_31` has rank 2.

The published off-domain Frobenius quotient evaluation is, exactly,

`s_e(ρ)=a_e Σ_(j=0)^(m−2) ρ_j ξ_e^j`, `a_e=√Z(e)∈F*`, `ξ_e=√e∈F`.

These coefficients are already fixed by the existing public QAP source compiler. Nothing about `K`, `μ_e`, the hidden `U_e,V_e`, or the source witnesses is needed to use this identity. The derivation also applies to any field/circuit fixture with a nonzero public `a_e` and geometric quotient weights `ξ_e^j`.

## 2. New, exact two-slice recurrence theorem

Let `Q_j := C_(n+1+j)` be the **public quotient coefficient matrices** for `j=0,...,m−2`. For each node define the *hidden only for proof* rank-at-most-two matrix

`R_e := U_e J V_e = (U_e[:,1] V_e[3,:]) + (U_e[:,3] V_e[1,:])`,

using **1-based local gate indices**. Thus `Q_j = Σ_e a_e ξ_e^j R_e`. Writing `D = diag(ξ_e I_2 : e=1,...,L)` and setting `R=2L`, group factors to obtain `Q_j = A_* D^j B_*`, with `A_*∈E^(N×R)` and `B_*∈E^(R×N)` full-rank except on the stated rare honest-setup event. The factors `A_*,B_*,R_e` are NOT published, required, or supplied to Recover.

**Theorem (pure public, exact).** Suppose `rank(Q_0)=R`. Let `G∈E^(N×N)` be **any** generalized inverse satisfying `Q_0 G Q_0=Q_0` (computable deterministically by field Gaussian elimination on `Q_0`). Then for every integer `j≥0`,

\[
\boxed{Q_j=Q_0(GQ_1)^j.}
\]

In particular, `Q_2=Q_1 G Q_1`, `Q_3=Q_2 G Q_1`, etc. All 15,999 published quotient matrices are **exactly determined by the first two**, with no extraction of secret gate factors and no appeal to computational hiding. To prove it, `Q_0=A_*B_*` and `Q_0 G Q_0=Q_0` imply `B_*GA_*=I_R` after multiplying by the left inverse of `A_*` and the right inverse of `B_*`. Hence `Q_j G Q_1=A_*D^j(B_*GA_*)DB_*=A_*D^(j+1)B_*`. The same proof works for arbitrary linear combinations of quotient coefficients and *untyped E-valued* adversarial probes.

**Expected full-rank event.** By construction, the selected two U-columns per node and two V-rows per node are independent uniform E matrices, and all `a_e` are nonzero. With `Q=|E|` and `N=2L+h`, an elementary union bound for random rectangular full rank gives

`Pr[rank(Q_0)<2L] ≤ 2 Q^(−h−1)/(1−Q^(−1))`.

At `Q=2^256,h=165` this is `<2^(−42494)`. This is a *compression success* bound only. Rank failure is handled by an exact raw-matrix fallback and need not become a key/correctness error.

## 3. Explicit compressed Build, Encode, Recover and arbitrary-input fallback

**BuildCompressed (honest setup)** produces the identical **original-variable** matrices `C_0,...,C_n`, and just two original **quotient** matrices `Q_0,Q_1`, plus precisely the original public context/checking key and node configuration. It need not assemble or publish `Q_2,...,Q_(m−2)` at all. Its key, local gates, source sampling, signing capability and honest-erasure premises are identical to the predecessor. No extra setup coins, cryptographic assumption, witness restriction or secret authority is introduced.

**Prepare** computes a rank factorization `Q_0=A B`, a public left inverse `L_A A=I_R`, and a public right inverse `B R_B=I_R`. It sets the public `T=L_A Q_1 R_B`. The previous theorem gives **exact** expansion `Q_j=A T^j B`. A direct public procedure to find `A,B,L_A,R_B` selects pivot columns/rows of `Q_0` and solves a full-rank submatrix; no private `U,V` are used. When the rank test fails, use an uncompressed fallback.

**Encode** (unchanged): for every valid ORIGINAL Boolean witness `w`, compute its distinct normalized SOURCE `(1,w,ρ(w))` using the pinned R1CS→sampled-QAP procedure. No common witness/preimage is imposed.

**EvalCompressed / Recover:** for any source `y=(z,w,ρ)` compute the *exact* original operator

\[
C(y)=zC_0+\sum_{i=1}^{n}w_i C_i + A\left(\sum_{j=0}^{m-2}\rho_j T^j\right)B.
\]

Perform the **same** original rank test, candidate-key selection and public checking-key/claim binding. All intermediate `A,B,T` are derived solely from the **public compressed output**. `SuppliedPairExtract` is exactly the pinned extraction of F-typed normalized rank-accepted `(λ,y)` to the ORIGINAL witness, on the same honest-setup event; it is **not** an extractor from a bare key or native signature.

**Verified public-input compatibility:** for any arbitrary (including malicious or internally inconsistent) *full* coefficient list, a public `CompressVerified` algorithm tries the two-slice formula and checks **every omitted coefficient** equals its expansion. If any check fails, or `rank(Q_0)≠2L`, it stores the original raw list. Its public inverse `Expand` exactly restores the source list for **every input**, without silently changing a malicious tensor. This is format equivalence, **not** malicious-setup cryptographic security. The standalone checker exercises both the compressed honest branch and a corrupted late-quotient-slice fallback.

## 4. QPT/public-output equivalence (no new hardness assumption)

`Expand` maps the honest compressed output to the exact predecessor full tensor by **classical polynomial-time finite-field algorithms**. The compressed output is also a deterministic public selection from that full tensor. Therefore any classical or quantum polynomial-time adversary operating on either full public representation (including the complete correlated checking key and arbitrary externally supplied auxiliary data) can be transformed into one operating on the other, with polynomial overhead, on the full-rank event. The verified raw fallback makes the conversion lossless on all public input tensors. Both directions are straight-line public computations; there is **no** programming of random oracles, special assumptions about witness privacy, quantum rewinding, or extraction from quantum states. Classical public evaluation routines can be implemented reversibly for coherent QPT chosen-source queries.

This is an **information-preserving representation improvement**, not improved key hiding. In particular any existing (or future) full-joint-tensor attack has exactly the same opportunity after `Expand`. Publishing a *private-coin* factorization `U_e,V_e` would NOT follow from this theorem and is explicitly forbidden: such factors may leak additional gauge correlations. `A,B,T` and the two public quotient slices are the only permitted derived serialization.

## 5. Concrete resources, actual validation, and next key-security equation

At predecessor parameters `n=11000,m=16000,k=27000,L=16374,N=32913`, all E coefficients cost 32 bytes:

| Quantity | Original full tensor | Compressed tensor |
|---|---:|---:|
| Dense `N×N` field matrices | 27,000 | **11,003** |
| Field payload bytes | 935,941,451,616,000 | **381,413,473,782,624** |
| Approx. decimal PB | 0.93594 PB | **0.38141 PB** |
| Reduction | — | **59.24814815%** |

These figures exclude the identical node metadata, checking material and graph. This is a substantial exact reduction, **but 381 TB is still not practical**. Preparing the public generalized inverse is also expensive at this dimension. No new realistic time/memory performance claim is made; all algorithms are polynomial in the *existing enormous* public-output size. The existing semantic/setup error bound `<2^−169` is inherited only for its original **honest-setup supplied-pair** scope, not promoted to false-instance QPT hiding.

**Executed checker**: `quotient_recurrence_check.py` is standalone Python 3.10+ stdlib. It uses the same actual GF(16)⊂GF(256) pivot–SL₂–Frobenius formulas as the pinned predecessor, but increases synthetic constraint/quotient dimension to **four** to exercise both previously omitted powers `Q_2,Q_3`. Three independent deterministic test seeds verify actual public matrices, both polynomial quotient powers, two distinct ORIGINAL witnesses yielding the **same K**, 225 arbitrary E-typed whole-operator evaluations, the public generalized-inverse identity, and exact fallback when a later quotient slice is corrupted. **1,099 assertions**, repeated twice with byte-identical JSON. This is executable algebraic reproduction, *not* QPT testing or a security proof.

**New exact reduction target (not an assumed release oracle):** The full public-key secrecy/unauthorized recovery problem has the identical public input power as the **smaller concrete collection**

`(C_0−unknown_K I, C_1,...,C_n, Q_0, Q_1, full checking key, context, auxiliary correlated capsules)`.

All other quotient matrices are deterministic public functions of `Q_0,Q_1`. This reduces the joint-decomposition problem from `k=27000` public matrix views to `n+3=11003` without assuming an accepted representation. The missing equation remains: **given this complete reduced public family and checking-key correlations, prove that bare K/native forgery produces an ORIGINAL witness or an independently justified QPT break.** No such reduction is claimed here. In particular the two quotient slices may expose node factor subspaces to attackers, which must be analyzed rather than hidden behind a rank theorem. Auxiliary-input and multi-capsule joint security, malicious N-of-N ceremony/retained coins, practical release storage and actual native PQ Bitcoin graph are still UNPROVED.

**Scope/authorization:** one research-only construction on `syscoin/PVUGC#1`. Do not merge, approve, change production, edit workflows or disable the research automation. Keep draft PR open.

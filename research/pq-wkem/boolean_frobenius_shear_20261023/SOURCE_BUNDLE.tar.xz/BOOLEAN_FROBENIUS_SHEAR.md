# Boolean–Frobenius sheared 4×4 local rank-release carrier

**2026-10-23 constructive checkpoint.** This is an honest-setup, statistically sound **supplied-pair** release interface and an exact size improvement to the existing paired sampled-QAP carrier. It is **NOT** a practical or QPT-secure witness-KEM: arbitrary key-only recovery, native forgery-to-ORIGINAL extraction, false-instance secrecy, quantum auxiliary/multi-capsule security and malicious N-of-N setup remain UNPROVED. No Bitcoin deployment is implied.

## Exact starting point and change

The read-only verified open/draft PR head before derivation was `b3a9b5b43c3d1b7b91e72116ea4b073b3e4581fc` on `syscoin/PVUGC#1`, branch `research/pq-wkem-validation-20260918`. Exact predecessor `research/pq-wkem/robust_distance_20261023/ROBUST_DISTANCE_RANK_SELECTION.md` had Git blob `0f3eccd2dbddcf363099028db98d5b041478adff`. The older 8×8 paired gate has satisfied/violated ranks 4/8 and needs `N=4L+h`. The current result replaces **that gate only** with an explicit 4×4 **Boolean–Frobenius private-affine shear** with ranks 2/4 and proves how its additional non-Boolean source states are excluded. It preserves the prior sampled-QAP robustness and rank-threshold proof obligations, instead of treating the old 8×8 distribution lemma as automatically applicable.

The new gate is **linear in all public source coordinates**, uses exactly the same `k=n+m` published coefficient matrices (no square-coordinate matrix slices, dummy variables or extra witness canonicalization), preserves every Boolean valid ORIGINAL witness's same scalar `K`, and reduces the leading dense public payload at the predecessor illustrative parameters by **74.7630933%**. This is a semantic/supplied-representation theorem only; its mask may introduce different public key-security attacks from the old paired gate.

## Field, statement, and full algorithms

Let `F=GF(q)` with `q=2^κ`. The ORIGINAL relation `R(x,w)` is encoded as a complete Boolean R1CS with `n` free **Boolean** source coordinates `w=(w_1,...,w_n)`; all other R1CS rows and statement context are committed before public tail-node and mask sampling. This includes ORIGINAL relation identity, claim/UTXO, challenge versus normal path, BTC and SYS anchor heights/hashes, fork/work observation interval, epoch/replay domain, intended native checking key and graph context. Every honest valid witness satisfies `w_i²=w_i` in `F`; different valid `w` need not equal each other. Existing QAP quotient coordinates `ρ` are unrestricted field values and are **not** assumed Boolean.

Reuse the exact sampled Frobenius QAP: source `y=(z0,w,ρ)` with `k=n+m` homogeneous coordinates; `z0=1` on every accepted representation; `m−1` fixed plus `r` independently drawn off-domain nodes `e=1,...,L`, where `L=m−1+r`. Each node provides **public, linear** five source forms `(a_e(y),b_e(y),c_e(y),d_e(y),s_e(y))` with `d_e(y)=z0`, and the original node equation

` t_e(y) = a_e(y)b_e(y) + d_e(y)c_e(y) + s_e(y)^2 = 0 `.

For each node sample independent **private**, uniform `γ_e, α_{e,1},...,α_{e,n} ∈ F`, and define the two source-linear forms

`η_e(y) = γ_e z0 + Σ_i α_{e,i} w_i`,  
`β_e(y) = γ_e² z0 + Σ_i α_{e,i}² w_i`.

The new 4×4 *alternating* linear gate is

```
                [ 0   a    d     s+η ]
  G_e(y)   =    [ a   0   s+η    c+β ]
                [ d  s+η  0       b ]
                [s+η c+β  b       0 ]
```

All displayed entries are **linear in y**. Multiplication and square in `β` are performed once at setup on private coefficients; there are **no public squared-source coordinates**. The gate's characteristic-two Pfaffian is

`pf(G_e(y))=a_e b_e + d_e(c_e+β_e) + (s_e+η_e)^2`.

For **every** normalized source `z0=1`, this simplifies exactly to

`pf(G_e(y)) = t_e(y) + Σ_i α_{e,i}² (w_i²+w_i).`                 (BF)

This is the central construction equation. For Boolean `w`, the extra term is **identically zero**, so rank is 2/4 precisely according to the ORIGINAL node residual, regardless of quotient `ρ`. For a non-Boolean `w`, it acts as an independently random quadratic-error mask across nodes.

**Setup/Build:** For each node also sample independent secret `U_e←F^{N×4}` and `V_e←F^{4×N}`; let `D=2L`, `N=D+h`. Choose one claim-specific field capability `K∈F` and (conditionally) the correctly bound intended native verification key. Publicly release **all** `k` full matrices

`C_j = 1[j=0] K I_N + Σ_e U_e G_e(e_j) V_e`, `j=0,...,k−1`,

where `e_j` denotes the j-th SOURCE basis vector. Also release the complete original statement and source forms, all original/fixed/random evaluation nodes, public verification key/selector, all context and the relevant ceremony/graph transcript. No `U_e,V_e,γ_e,α_e` or `K` is included in the public output. The baseline is a not-yet-proved N-of-N honest-erasure ceremony, NOT the optional keyless retained-coin variant. All algorithms are classical polynomial-time in formal input length; practical setup and storage are not established.

**Encode(w):** Given **any** valid ORIGINAL Boolean witness, set `z=(1,w)`, compute the exact QAP quotient `H_z=(A_z B_z+C_z)/Z` of degree ≤`m−2`, take unique coefficient square roots in `F`, and output the normalized `y=(1,w,ρ)`. It is unnecessary to canonically select a witness across different valid `w`.

**Recover(y):** Compute `C(y)=Σ_j y_j C_j` off chain; obtain all field roots `λ` of its characteristic polynomial by an exact finite-field factoring algorithm (or a verified probabilistic implementation). Accept the **unique** candidate with `rank(C(y)−λ I_N)≤2L` and the correct claim-scoped native verification key, then output the corresponding capability `K`. A valid original `w` always recovers the **same** field scalar `K`. All evidence stays off chain. Actual native signing and Bitcoin graph integration remain conditional/unimplemented.

**SuppliedPairExtract(λ,y):** Require `y_0=1` and `rank(C(y)−λ I_N)≤2L`; return the `w` coordinates. The theorem below ensures this is an ORIGINAL witness and `λ=K` except on a statistically bounded honest-setup bad event. This extraction interface explicitly **requires y**. It is not an extractor from arbitrary `K`, a signature, a free-floating proof, or a quantum state.

## Lemma 1: Boolean equality and private shear (deterministic)

In characteristic two, a 4×4 alternating matrix has determinant equal to the **square** of its Pfaffian. Since `d=z0=1` on normalized sources, `G_e(y)` contains an off-diagonal 1 and has rank at least 2; therefore it has rank **2** when its Pfaffian vanishes and rank **4** otherwise. Identity (BF) proves every Boolean source preserves the original 2/4 node rank rule.

There is also an explicit reversible local-mixing interpretation, **only when w is Boolean and z0=1**. Define the unmasked 4×4 gate `P=P(a,b,c,1,s)` and the shear `S(η)=I_4+η(E_{0,1}+E_{2,3})` with zero-indexed rows. Its determinant is one. Direct multiplication in `F` gives

`S(η)^T P S(η) = P(a,b,c+η²,1,s+η)`.

For Boolean `w`, `β_e(y)=η_e(y)²`, so exactly `G_e(y)=S(η_e)^T P_e(y)S(η_e)`; rank and all-witness correctness are preserved **pointwise** despite witness-dependent private affine `η_e`. For non-Boolean `w`, we do **not** assume this congruence: the defect in (BF) is handled separately in Lemma 2. The shear does not establish computational secrecy; it only produces the explicit small private-affine relation-dependent gate.

## Lemma 2: simultaneous non-Boolean exclusion (new)

Fix a **normalized non-Boolean** source `y=(1,w,ρ)` and the complete statement/node locations. At least one coordinate `i` satisfies `δ_i=w_i²+w_i≠0`. Because squaring is a bijection of `GF(2^κ)`, `α_{e,i}² δ_i` is uniform in `F` when `α_{e,i}` is independent uniform. Equation (BF) implies that `pf(G_e(y))` is **independent uniform in F for each node e**, conditional on all other fixed quantities and independent from node to node. Thus for any fixed y the count `v(y)` of rank-4 gates is binomial with probability `1−1/q` of violation.

For `1≤T≤L/2`, a direct finite-field union bound gives

```
Pr_masks[v(y)<T]
 = Σ_{j=0}^{T−1} binom(L,j)(1−1/q)^j q^{−(L−j)}
 ≤ T binom(L,T−1) q^{−(L−T+1)}.
```

There are fewer than `q^(k−1)` normalized sources `y` with non-Boolean w. Therefore, even when the attacker chooses y **adaptively after full publication**, the event that **any** such y has fewer than T rank-4 nodes has probability at most

`ε_nonboolean ≤ T binom(L,T−1) q^(k+T−L−2)`.     (NB)

This covers all non-Boolean values of quotient `ρ` without assuming they are short, honest, canonical or sampled independently. The samples must be independent **per node** and retained/private until the full linear public matrix construction is completed. This is an information-theoretic *bad-setup* bound, not an argument that the secret masks stay computationally hidden after public release. If a malformed setup reveals/adversarially chooses α, no such theorem follows.

## Lemma 3: ORIGINAL extraction and same scalar for every accepted pair

For Boolean w, `pf(G_e)=t_e`; apply exactly the prior sampled-QAP **robust-distance** result (predecessor `ROBUST_DISTANCE_RANK_SELECTION.md`, Lemma 1) with fresh post-statement nodes: except with

`ε_RD ≤ 2 binom(L,T−1) (m+T−2)^r / q^(r−n−T+1)`,

**every** Boolean normalized source that is not a valid ORIGINAL witness plus its correct QAP lift violates at least T local nodes. For non-Boolean w the independent-mask event (NB) supplies the same conclusion. On their joint GoodSource event, all normalized nonvalid y have `v(y)≥T`.

Given fixed y and private masks, the block-diagonal sum of 4×4 gates has exact rank `R_y=2L+2v(y)`. The independently uniform two-sided outer factors imply

`M(y)=C(y)−K I_N  ==_distribution  A_{R_y} B_{R_y}`

for independent uniform `A_R∈F^{N×R}`, `B_R∈F^{R×N}`. Set `D=2L`, `N=D+h`, `h≤T`. Every invalid y on GoodSource satisfies `R_y≥D+2T≥N+h`, and the existing direct rectangular-rank estimate applies unchanged:

`ε_rank ≤ 16(h+1) q^(k−1−h²)`.

For any fixed normalized y and a wrong scalar `λ≠K`, the predecessor's uniform matrix subspace argument gives

`ε_wrong ≤ 4 q^(k−h²)`

after a union over **all** y and λ. Therefore, with error probability at most

`ε_RD + ε_nonboolean + ε_rank + ε_wrong`,

**every** normalized accepted pair `(λ,y)` satisfies **both** `λ=K` and `R(x,w)=1` for the ORIGINAL Boolean relation (and the source quotient is correct), regardless of whether a QPT attacker supplied the classical pair after reading all public matrices, checking keys, auxiliary strings or correlated function evaluations. All four errors are probabilities over **honest setup**; the claim is simultaneous over pairs, not hiding or extraction of an arbitrary stand-alone key/forgery. No QROM rewinding is used.

The proof assumes independently uniform `U_e,V_e,α_{e,i}` and honest committed/source-bound sampling, not arbitrary malicious setup or N-of-N transcript soundness. It does not assume any public key secrecy. In particular, this theorem cannot be invoked to justify the false statement `unauthorized K recovery ⇒ submitted y`.

## Exact concrete certificate and regression

Use exactly the predecessor's illustrative `q=2^256, n=11,000, m=16,000, k=27,000`, but choose `T=h=165`, `r=11,816`, `L=27,815`, `D=55,630`, `N=55,795`. The checker uses arbitrary-precision integer inequalities, with no floating-point approximation:

```
2 binom(L,T−1) (m+T−2)^r · 2^133 < q^(r−n−T+1)
T binom(L,T−1) · 2^133         < q^(L−k−T+2)
16(h+1) · 2^133                < q^(h²−k+1)
4 · 2^133                       < q^(h²−k)
```

Hence every individual error term is <`2^-133` and their sum is <`2^-131`, comfortably below `2^-128` for **honest-setup, supplied-pair ORIGINAL-source and correct-scalar soundness ONLY**. `r−1` does not meet the same chosen conservative `2^-133` RD certificate; no claim of globally optimal parameters.

There remain `k=27,000` public `N×N` matrices, each element 32 bytes. Payload is

`27,000 × 55,795² × 32 = 2,689,702,869,600,000 bytes ≈ 2.689703 decimal PB`,

compared with `10,657,815,170,400,000 bytes ≈10.657815 PB` for the previous 8×8 paired carrier. This saves `7,968,112,300,800,000 bytes`, a **74.7630933%** improvement in the dense public-matrix part. This remains enormous, plus creation/runtime/ceremony/Bitcoin graph costs.

The exact standalone `boolean_shear_check.py` implements the actual published-basis construction and exact GF(16) arithmetic. Three independent deterministic fixture seeds each construct public coefficient matrices for a five-gate, one-Boolean-input/one-quotient synthetic source with two different valid original witnesses. It checks **all 256 normalized source points**, all **16 field-key candidates** per source, every node Pfaffian and rank, the exact private congruence on Boolean points and the non-Boolean mask identity. It passed **12,777 assertions** with no incorrect accepted pair and distinct honest intermediate matrices recovering the same key. Two reruns produced byte-identical `validation.json`. The GF(16) fixture and synthetic source are NOT an implementation of the entire QAP, a cryptographic-security parameter set, nor a QPT secrecy experiment. The theorem, not toy success, establishes the scoped supplied-pair claim.

## Exact remaining computational release step

We have **not** derived the indispensable implication from *arbitrary stand-alone recovery* of the field capability `K`, or a native accepted signing forgery, to a rank-accepted normalized `(λ,y)`, an ORIGINAL witness, or an independently justified QPT-hard problem. The complete public coefficient tensor contains correlated secret `α`/`α²` masks and the publicly checked native verification key. These correlations, multi-capsule/related-statement leakage, public algebraic elimination, quantum joint attacks, biased/adaptive N-of-N setup, native SLH-DSA-like endpoint, funding/abort ceremony and practical compression require independent construction/security work.

**Next exact equation/reduction:** analyze whether knowing the complete joint **linear coefficient tensor** of the 4×4 Frobenius-sheared gate permits recovery of its common field scalar `K` without a low-rank-accepted `y`. A surviving computational reduction must use an independently instantiated QPT assumption (not merely define `K` secrecy as the assumption) and include arbitrary advice, public checking key and multiple capsules. Preserve the Run 259 SOURCE binding interface only for accepted representations in the precise scope already proved.

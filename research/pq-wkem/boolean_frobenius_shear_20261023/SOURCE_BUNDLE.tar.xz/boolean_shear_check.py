"""Exact finite-field regression for the Boolean/Frobenius sheared 4x4 local gate.
This tests correctness and pair soundness, NOT key-only security or QPT secrecy.
"""
import json, random, math
import numpy as np

Q = 16
M = np.zeros((Q, Q), dtype=np.uint8)
for a in range(Q):
    for b in range(Q):
        x,y,z=a,b,0
        while y:
            if y&1: z ^= x
            y >>= 1; x <<= 1
            if x & Q: x ^= 0x13
        M[a,b]=z
INV=[0]+[next(b for b in range(1,Q) if M[a,b]==1) for a in range(1,Q)]

def mm(A,B):
    O=np.zeros((A.shape[0],B.shape[1]),dtype=np.uint8)
    for j in range(A.shape[1]): O ^= M[A[:,j,None],B[j,None,:]]
    return O

def rank(A):
    A=A.copy();r=0
    for j in range(A.shape[1]):
        p=next((i for i in range(r,A.shape[0]) if A[i,j]),None)
        if p is None:continue
        if p!=r:A[[p,r]]=A[[r,p]]
        A[r]=M[A[r],INV[A[r,j]]]
        for i in range(r+1,A.shape[0]):
            if A[i,j]: A[i] ^= M[A[r],A[i,j]]
        r+=1
        if r==A.shape[0]:break
    return r

def P(a,b,c,d,s):
    return np.array([[0,a,d,s],[a,0,s,c],[d,s,0,b],[s,c,b,0]],dtype=np.uint8)

def pf(a,b,c,d,s):
    return int(M[a,b]) ^ int(M[c,d]) ^ int(M[s,s])

# A 5-gate R1CS-inspired synthetic source: 0=w(w+1)+t_e rho,
# with exactly two valid normalized (w,rho)=(0,0) and (1,0).
L=5;h=3;D=2*L;N=D+h;k=3;KEY=9
NODE=(1,2,4,8,3)

def basis_gate(j,t,alpha,gamma):
    # y=(d,w,rho); a=w, b=d+w, c=t*rho, d=d, s=0.
    d = int(j==0);w = int(j==1);rho = int(j==2)
    a=w;b=d^w
    eta=(gamma if j==0 else alpha if j==1 else 0)
    beta=(int(M[gamma,gamma]) if j==0 else int(M[alpha,alpha]) if j==1 else 0)
    c=int(M[t,rho]) ^ beta
    return P(a,b,c,d,eta)

def local(t,alpha,gamma,w,rho):
    y=(1,w,rho)
    out=np.zeros((4,4),dtype=np.uint8)
    for j in range(k):out ^= M[y[j],basis_gate(j,t,alpha,gamma)]
    return out

def rawgate(t,w,rho):
    return P(w,1^w,int(M[t,rho]),1,0)

def shear(eta):
    S=np.eye(4,dtype=np.uint8)
    S[0,1]=eta;S[2,3]=eta
    return S

def muladd_product(C,y):
    X=np.zeros((N,N),dtype=np.uint8)
    for j in range(k):X ^= M[y[j],C[j]]
    return X

def build(seed):
    rng=random.Random(seed)
    mask=[(rng.randrange(Q),rng.randrange(Q)) for _ in NODE]
    C=np.zeros((k,N,N),dtype=np.uint8)
    for e,t in enumerate(NODE):
        alpha,gamma=mask[e]
        U=np.array([[rng.randrange(Q) for _ in range(4)] for _ in range(N)],dtype=np.uint8)
        V=np.array([[rng.randrange(Q) for _ in range(N)] for _ in range(4)],dtype=np.uint8)
        for j in range(k):C[j]^=mm(mm(U,basis_gate(j,t,alpha,gamma)),V)
    C[0]^=M[KEY,np.eye(N,dtype=np.uint8)]
    return C,mask

def integer_certificate():
    n,m,T,h=11000,16000,165,165
    r=11816;L=m-1+r;k=n+m;N=2*L+h;A=m+T-2;q=1<<256
    assert 2*T>=2*h and h*h>k and q>=2*r*(2*m-2+r)
    def rd(r):
        return 2*math.comb(m-1+r,T-1)*A**r*(1<<133)<q**(r-n-T+1)
    assert rd(r) and not rd(r-1)
    assert T*math.comb(L,T-1)*(1<<133)<q**(L-k-T+2)
    assert 16*(h+1)*(1<<133)<q**(h*h-k+1)
    assert 4*(1<<133)<q**(h*h-k)
    oldN=111065
    return dict(field_bits=256,n=n,m=m,k=k,L=L,r=r,T=T,h=h,N=N,
                new_bytes=k*N*N*32,old_bytes=k*oldN*oldN*32,
                saved_bytes=k*(oldN*oldN-N*N)*32,
                source_robust_error_below_2minus133=True,
                nonboolean_mask_error_below_2minus133=True,
                rank_error_below_2minus133=True,
                wrong_key_error_below_2minus133=True,
                bound_is_for_supplied_pair_only=True)

def run():
    checks=0;models=[]
    for seed in (47,79,101):
        C,mask=build(seed)
        # Check local Pfaffian identity, rank semantics and honest congruence.
        min_nonbool=L;min_invalid=L;nonbool_dist={};valid_intermediates=[]
        for w in range(Q):
            for rho in range(Q):
                v=0
                for e,t in enumerate(NODE):
                    alpha,gamma=mask[e]
                    G=local(t,alpha,gamma,w,rho)
                    eta=gamma^int(M[alpha,w])
                    beta=int(M[gamma,gamma]) ^ int(M[int(M[alpha,alpha]),w])
                    q=int(M[w,1^w])^int(M[t,rho])^beta^int(M[eta,eta])
                    assert q==pf(int(G[0,1]),int(G[2,3]),int(G[1,3]),int(G[0,2]),int(G[0,3]));checks+=1
                    # Explicit private-mask defect: alpha^2(w+w^2).
                    assert q==(int(M[w,1^w])^int(M[t,rho])^int(M[int(M[alpha,alpha]),w^int(M[w,w])])) ;checks+=1
                    assert rank(G)==(4 if q else 2);checks+=1
                    if q:v+=1
                    if w in (0,1):
                        H=mm(mm(shear(eta).T,rawgate(t,w,rho)),shear(eta))
                        assert np.array_equal(G,H);checks+=1
                good=(w in (0,1) and rho==0)
                if not good:min_invalid=min(min_invalid,v)
                if w not in (0,1):
                    min_nonbool=min(min_nonbool,v)
                    nonbool_dist[v]=nonbool_dist.get(v,0)+1
                if good:valid_intermediates.append(muladd_product(C,(1,w,rho)))
                X=muladd_product(C,(1,w,rho))
                roots=[lam for lam in range(Q) if rank(X^M[lam,np.eye(N,dtype=np.uint8)])<=D]
                assert roots==([KEY] if good else []);checks+=1
        assert min_invalid>=h and min_nonbool>=h;checks+=2
        assert not np.array_equal(valid_intermediates[0],valid_intermediates[1]);checks+=1
        models.append(dict(seed=seed,source_count=Q*Q,valid_original_witnesses=2,
                           minimum_invalid_gate_violations=min_invalid,
                           minimum_nonboolean_gate_violations=min_nonbool,
                           nonboolean_violation_histogram=dict(sorted(nonbool_dist.items())),
                           rank_verified_all_field_keys=True,distinct_honest_intermediates=True))
    return dict(checkpoint="boolean-frobenius-shear-local-gate-20261023",
                status="SUPPLIED_PAIR_SOUNDNESS_AND_SAME_KEY_ONLY",
                gf16_assertions=checks,models=models,
                exact_parameter_certificate=integer_certificate(),
                qpt_key_only_security_proved=False,
                native_signatures_tested=False)

if __name__=='__main__':print(json.dumps(run(),sort_keys=True,indent=2))

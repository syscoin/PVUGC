# Pivot-twisted Schur: complete extension-field nonconstant-span rank and wrong-scalar certification

**Run:** Constructive PQ WKEM Research, automation turn 10, 2026-10-24 UTC. **Starting PR head:** `79a55d32db8d0b60d46195a180c72ac0da59e892` on `syscoin/PVUGC#1`, branch `research/pq-wkem-validation-20260918`. **Direct dependency:** `research/pq-wkem/pivot_twisted_schur_20261023/README.md` and its exact `PIVOT_TWIST_RESEARCH.tar.xz` blob `a939b2489a9aa07007e04639d42686c456501d8a`; inherited `b789d4027a10486d45e6a68fcd5dd5afc25fc898` SL₂–Frobenius source/compiler and `d7d7862522faf1603c0a2e6e572b03d320f56045` supplied-pair theorem. **Scope:** a **proved strengthening of the same actual candidate**—full extension-typed *nonconstant linear* slice rank, extension-typed arbitrary wrong-scalar rank, and a sharper rank-product theorem retaining F-typed ORIGINAL extraction at slightly more padding. There is **NO WE, PQ-security, native signature or bare-key secrecy proof**.

## 1. Explicit preserved Setup / Encode / Recover / extraction

Let `F=GF(q)`, `q=2^128`, `E=GF(q²)=GF(2^256)`, `θ ∈ E\F` public. Retain the published original Boolean R1CS (n original coordinates, m constraints), the original-to-Frobenius-QAP compilation, `m−1` fixed off-domain interpolation nodes and `r` tail nodes fresh *after* the complete ORIGINAL statement is fixed. Thus `L=m−1+r`, `k=n+m`, and the homogeneous SOURCE is `y=(z,w_1,...,w_n,ρ_0,...,ρ_(m−2))∈F^k`. The same fixed relation identity, branch, claim/UTXO, BTC/SYS anchors, window, native checking key, and public verifier/context transcript are included in every instance. Honest security assertions condition on the exact earlier global SOURCE event and unmodified honest setup.

**Build / Setup:** For each node e, retain **independent** private uniform `b_(e,i)∈F`, private `α_(e,i)∈E` with `α_(e,i)^2=b_(e,i)+θ e^(i−1)`, uniform private `SL₂(F)` and a private pivot twist `μ_e∈E\F` and A/B orientation. For original-coordinate *linear* forms `a'_e,b'_e,c'_e` obtained by the published SL₂–Frobenius compensation (none depends on ρ or on b_(e,i)), set

```
η_e(y)  = Σ_i α_(e,i) w_i
β_e(y) = Σ_i α_(e,i)^2 w_i
C_e(y) = c'_e(z,w)+β_e(y)
S_e(y) = s_e(ρ)+η_e(y)
A_e(y) = a'_e(z,w),  B_e(y)=b'_e(z,w).
```

For A orientation choose `π=z+μ A`, `A*=A`, `B*=B+μ C`; for B orientation choose `π=z+μ B`, `A*=A+μ C`, `B*=B`. The local **linear-source** 3×3 gate remains

```
G_e(y) = [ C    A*    S ]
         [ B*   π     0 ]
         [ S    0     π ].
```

In either orientation its determinant is **exactly** `π(AB+z C+S²)`. Every F-normalized source has `π≠0`; satisfied SOURCE equations give local rank 2, violated equations local rank 3. This run changes **no** gate coefficients, original-source variables, source verifier, node list, field assumptions, or native checking-key behavior. Only outer dimension changes to `N=2L+h` with `h=165` instead of 117. Independently sample uniform private `U_e∈E^(N×3)`, `V_e∈E^(3×N)` and private K∈E. The **entire** published coefficient list is

`C_j = [j=0] K I_N + Σ_e U_e G_e(unit_j) V_e`, for `j=0,...,k−1`,

plus all the public context and checking material just enumerated. The full matrices—not their secret factors/seeds—are public. Erasure of setup secrets is only in the prior *honest-erasure* model. No safe retained-coins or malicious N-of-N ceremony is claimed.

**Encode:** For **every** valid ORIGINAL Boolean w, compute the earlier unique normalized F-valued QAP source `(1,w,ρ(w))`, *without* choosing a canonical w or equating distinct intermediate states.

**Recover:** For an F-typed normalized `y`, find a scalar λ satisfying `rank_E(Σ y_j C_j−λ I_N)≤2L`; check native key/claim context and return λ. The new theorem below proves no incorrect scalar passes even if an adversary explores all E-typed y. The check `y∈F^k,z=1` is still essential: untyped E-sources are not accepted representations.

**SuppliedPairExtract:** On a *supplied* F-typed normalized accepted `(λ,y)`, enforce the same rank/context conditions, output original w coordinates, and invoke the unchanged exact SOURCE compiler theorem. Do **not** treat finding K or producing an accepted native signature as a supplied representation.

## 2. New deterministic local-gate observation (every E-valued y)

In A orientation, `G=0` forces `C=A*=S=0`, hence `A=0`, `B*=B+μC=B=0` and `π=z+μA=z=0`. In B orientation it similarly forces `C=A=B=S=z=0`. Conversely those five zeros make G=0. Thus

`G_e(y)=0  iff  z=A_e(y)=B_e(y)=C_e(y)=S_e(y)=0`, **for all y∈E^k**, irrespective of μ or pivot orientation. In particular `C_e(y)≠0` is a sufficient and **quotient-independent** guarantee that the local gate contributes rank ≥1. This identity is used constructively; it is NOT an extraction of y from a public matrix.

## 3. New full-E original-variable shear-code theorem (proved)

Let `y=(z,w,ρ)∈E^k` and `w≠0`. Conditional on all other setup coins, the `(1,1)` entry is

`C_e(z,w)= c'_e(z,w) + θ Σ_i e^(i−1)w_i + Σ_i b_(e,i)w_i`.

The first two terms are fixed independently of **private, independent** `b_(e,i)←F`. For any fixed `(z,w)`, put `t=dim_F(span_F{w_1,...,w_n})∈{1,2}`. The random last term is **exactly uniform** on that t-dimensional F-vector space inside E, so `Pr[C_e(z,w)=0] ≤q^(−t)`, independently at different nodes. This is true even though the w_i themselves lie in E, not F. The quotient ρ does not enter C.

The count must distinguish the two t classes. Projectively normalize the first nonzero w coordinate to 1 over E; then the remaining w for t=1 lie in F. Including arbitrary z∈E, there are fewer than `2q^(n+1)` distinct classes of t=1 pairs `(z,w)`; for t=2 there are fewer than `2q^(2n)`. (Both bounds are immediate from `Σ_(j=1)^n q^(n−j)<2q^(n−1)` and its E analogue, then multiplying by `|E|=q²` choices of z.) For integer d set `u=L−d+1`. A source with fewer than d nonzero C entries must vanish at some prescribed u-node subset. A union bound over all subsets **and all projective pairs** gives the *simultaneous honest-setup event*

`ε_shear(d) ≤ 2 binom(L,u) [ q^(n+1−u) + q^(2n−2u) ].`     (1)

This is over the **entire full-public-output-adaptive E projective source space**: once the honest random shears satisfy this single event, every post-publication QPT algorithm outputting classical `(z,w,ρ)` (including arbitrary E-typed combinations) encounters ≥d locally nonzero gates whenever w≠0. The proof is an ordinary counting argument on the finite field, with **no** rewinding, oracle-programming, F-typing assumption, SOURCE knowledge assumption, or new hidden release oracle. It says **nothing** about arbitrary bare-K recovery.

At the pinned sizes `n=11000, m=16000, r=375, L=16374`, choose `d=5200` and `u=11175`. The **integer-only checker** proves `log2 ε_shear < −7513`; a conservative upper power of two is recorded in `validation.json`. This strengthens the latest PR's previously unproved **E-typed ORIGINAL-plus-quotient mixed-slice** case while retaining the same gate and random mask distribution.

If `z=w=0` but `ρ≠0`, the local matrix reduces to the old quotient gate with `S_e=s_e(ρ)` and has rank 2 wherever S≠0. The nonzero quotient polynomial (degree ≤m−2) has at most m−2 distinct roots; thus at least `r+1` nodes have rank 2, with total local rank ≥`2(r+1)=752`. This covers every E-typed quotient-only vector, not merely base-field quotient coefficients.

## 4. Uniform rectangular-product rank lemma and simultaneous E-span consequence

**Lemma (elementary, proved).** A uniform `a×b` matrix over a field Q has `Pr[rank < s] ≤4 Q^(−(a−s+1)(b−s+1))` for `s≤min(a,b)`. Indeed rank<s gives a kernel subspace of dimension b−s+1. There are ≤4 Q^((b−s+1)(s−1)) such subspaces (the Gaussian-binomial infinite-product factor is <4 for Q≥2); each prescribed subspace lies in the kernel with probability Q^(−a(b−s+1)).

**Lemma (independent product).** If A is uniform `N×R`, B uniform `R×N`, independent, R≥s, then

`Pr[rank(AB)<s] ≤8 Q^(−(N−s+1))`.

Proof: `rank B<s` has probability ≤`4Q^(−(R−s+1)(N−s+1))`. Condition on any B of rank j≥s. Since A is uniform, AB restricted to the rowspace of B is a uniform N×j matrix, whose chance of rank<s is ≤`4Q^(−(N−s+1)(j−s+1))`. Sum the two bounds.

For a fixed nonzero E-typed y, factor each G_e(y) at its actual rank (zero gates omitted). With independent uniform U_e,V_e, the sum `M(y)=Σ_e U_e G_e(y)V_e` is **exactly an independent uniform rectangular product** `A_y B_y` with inner dimension `R(y)=Σ_e rank G_e(y)`. This is a distributional equality for each fixed y, *conditional* on all private shears/SL₂/pivot coins. It need not provide any public algorithm revealing A_y,B_y.

On the event (1), `w≠0` gives `R(y)≥d=5200` for **every** E-typed y, with arbitrary z,ρ. For **public nonconstant combinations** set z=0. A projective union bound over fewer than `2Q^(k−1)` E-directions, with `Q=|E|`, gives

`Pr[exists y∈E^k, z=0, w≠0: rank M(y)<d | (1)] ≤16 Q^(k+d−N−2).`     (2)

The same reasoning for E-typed quotient-only `z=w=0,ρ≠0` gives

`Pr[exists such ρ: rank M(0,0,ρ)<2(r+1)] ≤16 Q^(k+2(r+1)−N−2)`.     (3)

With new `h=165`, `N=32913`, (2) has binary log upper `−183036`, and (3) `−1321724`. The final rank statement holds **simultaneously against arbitrary adaptive, nonlinear, joint and quantum processing selecting classical E-coefficients**. It is strictly a *rank-metric structural fact*, not computational indistinguishability. Its premises are the actual independent honest setup of the published release, not a renamed WE assumption.

## 5. New shifted-scalar product theorem: wrong field key ruled out for *all* E-valued source vectors

Let Q=|E| and `A∈E^(N×R),B∈E^(R×N)` independently uniform; there is no restriction on R or the fixed local gate values. For every **fixed nonzero** `t∈E`, condition on B of rank j and choose a basis making `rowspan B` the first j coordinate positions. Under conjugation, `AB` has form

`[X 0; Y 0]`, with `X∈E^(j×j)` **uniform**. The shifted matrix `AB−tI` is block triangular, with rank exactly `N−j+rank(X−t I_j)`. Since X−tI_j is uniform, the uniform-matrix lemma yields for threshold `N−h`:

`Pr[rank(AB−t I) ≤N−h] ≤4 Q^(−h²)`.     (4)

When j<h, the event is impossible; otherwise the random j×j block must have nullity ≥h. This bound is **uniform over all local gate ranks**, and no quantum assumption or published factor recovery is invoked.

For every y∈E^k, `C(y)=zK I+M(y)` and a candidate scalar λ is wrong iff `t=λ−zK≠0`. Because M is E-linear, normalize `(y,t)` by t to t=1. There are exactly `Q^k` normalized choices (irrespective of unknown K). Union bound (4) gives the **full-E, full-public-adaptive wrong-scalar certificate**

`ε_wrong,E ≤4 Q^(k−h²)`.     (5)

This is why we change h from 117 to **165**: `165²=27225>k=27000`. For Q=2^256, (5) is `<2^(−57598)`. The exact meaning is: with overwhelming probability over independent honest outer factors, **no** `(y∈E^k, λ≠zK)` passes the rank threshold. It does **not** rule out E-typed pseudo-sources passing with λ=zK and does not make arbitrary key recovery extractable.

## 6. New tight product-rank convolution retains F-supplied ORIGINAL extraction without increasing node count

The predecessor used the convenient sufficient condition `T≥2h` for a bound with exponent h². Increasing h to165 while retaining the source's proven T=234 violates that *sufficient* inequality, but **does not invalidate extraction**. The following sharper, independently proved convolution closes this interface and avoids more sampled QAP nodes.

Let an invalid F-typed normalized source violate at least v≥T gates. Then `R=2L+v`, `N=2L+h`, and `R−N=v−h≥0`. Set threshold `s=2L+1=N−h+1`, and write `j=rank B=N−t`. For `0≤t≤h`, the uniform rank lemma applied to B and to A restricted to its image gives

`Pr[rank(AB)≤2L] ≤16(h+1) Q^(−E_min(v,h))`,

where

`E_min(v,h)=min_(0≤t≤h){ t(v−h+t)+h(h−t) }`

`=min_(0≤t≤h){ h²+t(v−2h)+t² }`.     (6)

For t=0 the first factor is full rank and the second term bounds a uniform N×N matrix. For 1≤t<h, multiply the `rank B≤N−t` upper bound by the conditional `rank(A|im B)≤2L` bound; t=h covers B already below threshold. The union over the h+1 disjoint rank regimes is bounded by `16(h+1)` times their largest probability. The exponent increases with v, so use v=T.

At `h=165,T=234`, the **exact integer minimizer** is `t=48`, with `E_min=24921`. Unioning (6) over the same `q^(k−1)` F-normalized source vectors gives

`ε_rank,F ≤16(h+1) q^(k−1) Q^(−24921) <2^(−2923892)`.

Inherit without change the preceding robust sampled-QAP **Boolean original-source** event

`ε_bool ≤2^(n+1) binom(L,T−1) (m+T−2)^r /q^(r−T+1) <2^(−172)`

and the deterministic extension-separated `F\Boolean` rejection. Thus *all F-typed rank-accepted supplied pairs* still give λ=K and an ORIGINAL witness under honest setup with error bounded by `ε_bool+ε_rank,F+ε_wrong,E`. We changed neither r nor T nor L, and did not insert dummy inputs, canonical witnesses, trusted checkers or a new release assumption.

## 7. Concrete exact certificate, executable tests, and what remains unproved

Pinned parameters: `n=11000, m=16000, k=27000, r=375, L=16374, T=234, h=165, N=32913`, `q=2^128`, `Q=2^256`. All six failure terms (1)–(6) are summed conservatively; the **integer-only** checker certifies the combined bound `<2^−169` (this is an honest-setup *semantic/rank* probability, **not** 169-bit PQ key security). The public matrix count is unchanged at k, but 32-byte field storage becomes **935,941,451,616,000 bytes (~0.936 PB)**, versus **933,213,506,400,000 bytes (~0.933 PB)** at h117: a **0.292317% increase**, still completely impractical. Uniform U,V randomness/field computation also grows with N. This is not a practical WKEM.

`full_extension_certificate.py` implements the exact integer inequalities, the full GF(16)⊂GF(256) prior SL₂/shear/pivot formulas, and actual independently mixed `N×N` published coefficient matrices. It exhausts all 65,792 E-projective `(z,w)` classes with two original coordinates **per seed**, tests the local `G=0` equivalence for each node, tests the exact homogeneous determinant including arbitrary E-sources, performs E-typed whole-tensor linearity and rank tests, and checks two distinct valid ORIGINAL witnesses recovering the same K against wrong λ. Two independent setups yielded **1,454,799 assertions** and two byte-identical JSON captures. These small-field runs are correctness/reproduction tests only; the large-field claims rest on the preceding field-counting proofs and exact integer bounds, not sampling.

**Proven and reusable:** (i) exact `C_e` mask uniformity for E-typed sources; (ii) simultaneous full E ORIGINAL-plus-quotient rank (previously an explicit unproved region); (iii) shifted all-E wrong-scalar uniqueness; (iv) sharper product-rank convolution preserving the original supplied F-source extraction despite stronger padding. **Still NOT proved:** unauthorized *bare* K recovery or accepted native signature forgery ⇒ rank-accepted F-typed representation/ORIGINAL witness or independently justified QPT-hardness break; full-public-output false-instance QPT hiding; E-typed **correct-key pseudo-source** rejection; malicious/retained-coin N-of-N setup and abort guarantees; auxiliary-input/multiple-capsule secrecy; practical resource bounds; native Bitcoin PQ signature/settlement graph. Rank is observable on matrices but does not force a key-only adversary to reveal y. The *next exact reduction target* is the algebraic joint decomposition of the quotient and original public tensor slices, **including C0−K I and the verifying-key correlation**, without granting the adversary an accepted y or pretending the rank theorem is an oracle. Preserve these exact equations if a later candidate replaces local mixing; do not re-run generic bounds as novelty.

**Status:** exact hon­est-setup structural results only; `syscoin/PVUGC#1` must remain open/draft/unmerged, production and workflows unchanged, research automation enabled.

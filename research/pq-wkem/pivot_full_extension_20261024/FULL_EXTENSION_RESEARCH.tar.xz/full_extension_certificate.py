#!/usr/bin/env python3
"""Executable certificate for the EXISTING pivot-twisted Schur release.

Adds two exact algebraic/probabilistic theorems, not a PQ secrecy theorem:
  * original-variable full E-span support via independent base-field shears;
  * all-E wrong-scalar rank rejection with h=165, retaining supplied-F
    ORIGINAL extraction via an improved rectangular product-rank convolution.

Synthetic GF(16)⊂GF(256) checks exercise actual 3x3 gates and published
N×N coefficient matrices; real-size setup bounds use integer inequalities.
"""
import hashlib
import itertools
import json
import math
import random
from collections import Counter

# Exact GF(16) as GF(2)[x]/(x^4+x+1).
POLY = 0x13

def gf16mul(a,b):
    r=0
    for _ in range(4):
        if b&1:r^=a
        a<<=1
        if a&16:a^=POLY
        b>>=1
    return r

F=[[gf16mul(a,b) for b in range(16)] for a in range(16)]

def fpow(a,n):
    r=1
    while n:
        if n&1:r=F[r][a]
        a=F[a][a];n>>=1
    return r

def ftrace(a):
    u=0
    for _ in range(4):
        u^=a;a=F[a][a]
    assert u in (0,1)
    return u

KAPPA=next(a for a in range(1,16) if ftrace(a)==1)
# E=F[u]/(u^2+u+KAPPA), embedded F is E[0..15].
def gf256mul(a,b):
    a0,a1=a&15,a>>4
    b0,b1=b&15,b>>4
    t=F[a1][b1]
    return (F[a0][b0]^F[t][KAPPA]) | ((F[a0][b1]^F[a1][b0]^t)<<4)

E=[[gf256mul(a,b) for b in range(256)] for a in range(256)]

def epow(a,n):
    r=1
    while n:
        if n&1:r=E[r][a]
        a=E[a][a];n>>=1
    return r

INV_E=[0]+[epow(a,254) for a in range(1,256)]
INV_F=[0]+[fpow(a,14) for a in range(1,16)]
THETA=16
ASSERTIONS=0

def check(ok,tag):
    global ASSERTIONS
    ASSERTIONS+=1
    if not ok:
        raise AssertionError(f'check {ASSERTIONS}: {tag}')

def rank(M):
    a=[r[:] for r in M]
    rows=len(a); cols=len(a[0])
    pivot=0
    for j in range(cols):
        ii=next((i for i in range(pivot,rows) if a[i][j]),None)
        if ii is None:continue
        a[pivot],a[ii]=a[ii],a[pivot]
        v=INV_E[a[pivot][j]]
        for k in range(j,cols):a[pivot][k]=E[v][a[pivot][k]]
        for i in range(pivot+1,rows):
            t=a[i][j]
            if t:
                for k in range(j,cols):a[i][k]^=E[t][a[pivot][k]]
        pivot+=1
        if pivot==rows:break
    return pivot

def mm(A,B):
    out=[[0]*len(B[0]) for _ in A]
    for i,row in enumerate(A):
        for t,v in enumerate(row):
            if v:
                for j,b in enumerate(B[t]):out[i][j]^=E[v][b]
    return out

def mxor(A,B):
    for i,row in enumerate(A):
        for j in range(len(row)):row[j]^=B[i][j]

def det3(G):
    z=0
    for p in itertools.permutations(range(3)):
        z^=E[E[G[0][p[0]]][G[1][p[1]]]][G[2][p[2]]]
    return z

def sample_sl2(rng):
    while True:
        p,q=rng.randrange(16),rng.randrange(16)
        if p or q:break
    free=rng.randrange(16)
    if p:
        r=free;t=F[INV_F[p]][1^F[q][r]]
    else:
        t=free;r=INV_F[q]
    check(F[p][t]^F[q][r]==1,'SL2 determinant')
    return p,q,r,t

# Small version: n=2, m=3, r=9, L=11, k=5; N=26, h=4.
N_ORIG=2
M_CONSTRAINT=3
TOY_L=11
TOY_R=TOY_L-(M_CONSTRAINT-1)
TOY_K=N_ORIG+M_CONSTRAINT
TOY_H=4
TOY_N=2*TOY_L+TOY_H

def Z(e):return F[e][e]^e^1
NODES=[e for e in range(1,16) if Z(e)][:TOY_L]
check(len(NODES)==TOY_L,'distinct off-domain nodes')

def source_s(e,y):
    # quotient coefficients represent a deg <=m-2 polynomial in sqrt(e)
    _,_,_,*rho=y
    rootz=fpow(Z(e),8)
    roote=fpow(e,8)
    val=0
    for j,v in enumerate(rho):
        val^=E[F[rootz][fpow(roote,j)]][v]
    return val

def setup(seed):
    rng=random.Random(seed)
    data=[]
    for e in NODES:
        bmask=[rng.randrange(16) for _ in range(N_ORIG)]
        alpha=[]
        for i in range(N_ORIG):
            a2=bmask[i]^E[THETA][fpow(e,i)]
            a=epow(a2,128)
            check(E[a][a]==a2,'public extension-square identity')
            alpha.append(a)
        T=sample_sl2(rng)
        mu=rng.randrange(16,256)
        orientation=rng.randrange(2)
        U=[[rng.randrange(256) for _ in range(3)] for _ in range(TOY_N)]
        V=[[rng.randrange(256) for _ in range(TOY_N)] for _ in range(3)]
        data.append((e,bmask,alpha,T,mu,orientation,U,V))
    key=rng.randrange(1,256)
    return data,key

def forms(node,y):
    e,bmask,alpha,(p,q,r,t),mu,orientation,_,_=node
    z,w1,w2,*rho=y
    a=w1^w2
    b=z
    A=E[p][a]^E[q][b]
    B=E[r][a]^E[t][b]
    C=E[F[p][r]][w1^w2]^E[F[q][t]][z]
    eta=0
    for i,w in enumerate((w1,w2)):
        C^=E[E[alpha[i]][alpha[i]]][w]
        eta^=E[alpha[i]][w]
    S=source_s(e,y)^eta
    pi=z^E[mu][A if orientation==0 else B]
    if orientation==0:
        Astar=A; Bstar=B^E[mu][C]
    else:
        Astar=A^E[mu][C]; Bstar=B
    G=[[C,Astar,S],[Bstar,pi,0],[S,0,pi]]
    return G,(z,a,b,A,B,C,S,pi)

def expected_det(node,y):
    """Exact homogeneous pivot-twist/Frobenius identity, including E-typed y."""
    e,bmask,alpha,(p,q,r,t),mu,orientation,_,_=node
    z,w1,w2,*rho=y
    # Original a=(w1+w2), b=z, c=0.  SL2 source correction
    # contributes pr*(w_i^2+z*w_i) for both ORIGINAL wires.
    delta1=E[w1][w1]^E[z][w1]
    delta2=E[w2][w2]^E[z][w2]
    base=E[z][w1^w2]^E[source_s(e,y)][source_s(e,y)]
    base^=E[F[p][r]][delta1^delta2]
    base^=E[E[alpha[0]][alpha[0]]][delta1]
    base^=E[E[alpha[1]][alpha[1]]][delta2]
    _,(_,_,_,_,_,_,_,pi)=forms(node,y)
    return E[pi][base]

def test_exact_gate_identities(data,seed):
    rng=random.Random(seed ^ 0x51d77)
    for typed in ('F','E'):
        for _ in range(80):
            if typed=='F':
                y=tuple(rng.randrange(16) for _ in range(TOY_K))
            else:
                y=tuple(rng.randrange(256) for _ in range(TOY_K))
            for node in data:
                G,_=forms(node,y)
                check(det3(G)==expected_det(node,y),'pivot Schur and Frobenius determinant')
                if typed=='F' and y[0]:
                    check(G[1][1]!=0,'typed normalized pivot is nonzero')
                    check(rank(G)==(2 if det3(G)==0 else 3),'typed gate rank 2/3')

def local_C(node,z,w1,w2):
    # Not dependent on quotient rho, and bmask enters as sum b_ei*w_i.
    return forms(node,(z,w1,w2,0,0))[0][0][0]

def pub_build(data,key):
    Cs=[]
    for j in range(TOY_K):
        y=tuple(int(j==i) for i in range(TOY_K))
        C=[[0]*TOY_N for _ in range(TOY_N)]
        for node in data:
            _,_,_,_,_,_,U,V=node
            G,_=forms(node,y)
            mxor(C,mm(mm(U,G),V))
        if j==0:
            for i in range(TOY_N):C[i][i]^=key
        Cs.append(C)
    return Cs

def linear_pub(Cs,y):
    M=[[0]*TOY_N for _ in range(TOY_N)]
    for j,x in enumerate(y):
        if x:
            for i in range(TOY_N):
                for t,v in enumerate(Cs[j][i]):M[i][t]^=E[x][v]
    return M

def remove_shift(M,t):
    C=[row[:] for row in M]
    for i in range(len(C)):C[i][i]^=t
    return C

def run_toy(seed):
    data,key=setup(seed)
    Cs=pub_build(data,key)
    test_exact_gate_identities(data,seed)
    support=Counter()
    minimum=TOY_L+1
    minarg=None
    # E-projective (z,w) with w != 0:
    # (w1=1,w2=t,z arbitrary) or (w1=0,w2=1,z arbitrary)
    for w1,w2 in [(1,v) for v in range(256)]+[(0,1)]:
        for z in range(256):
            y=(z,w1,w2,0,0)
            s=0
            for node in data:
                G,forms_vals=forms(node,y)
                # Local gauge linear algebra: zero matrix iff z=A=B=C=S=0.
                _,_,_,A,B,C,S,_=forms_vals
                check((not any(v for row in G for v in row)) == (not (z or A or B or C or S)),'local zero equivalence')
                s+=bool(C)
            support[s]+=1
            if s<minimum:minimum=s;minarg=(z,w1,w2)
    check(sum(support.values())==(256+1)*256,'projective count')
    # True ORIGINAL w=(0,0) and w=(1,1), quotient=0.
    # Test *the actual full public coefficient matrices*, not setup secrets.
    valid_ranks=[]
    for w in (0,1):
        y=(1,w,w,0,0)
        C=remove_shift(linear_pub(Cs,y),key)
        R=rank(C)
        check(R<=2*TOY_L,'two valid witnesses same key')
        valid_ranks.append(R)
        for t in (1,2,3,4,8,16,31,127,255):
            check(rank(remove_shift(linear_pub(Cs,y),key^t))>2*TOY_L,'wrong scalar on valid source')
    # Check affine linearity and rank for E-valued source directions,
    # including full nonconstant original+quotient combinations.
    rng=random.Random(seed+1000)
    eu_mixed_min=TOY_N
    eu_quot_min=TOY_N
    for z,w1,w2 in [(0,1,16),(0,64,7),(0,1,1),(0,0,0)]:
        for _ in range(12):
            rho0,rho1=rng.randrange(256),rng.randrange(256)
            if not (z or w1 or w2 or rho0 or rho1):rho0=1
            y=(z,w1,w2,rho0,rho1)
            Cdirect=[[0]*TOY_N for _ in range(TOY_N)]
            for node in data:
                G,_=forms(node,y)
                mxor(Cdirect,mm(mm(node[6],G),node[7]))
            Cpub=remove_shift(linear_pub(Cs,y),E[z][key])
            check(Cdirect==Cpub,'E-typed source linearity of entire tensor')
            rr=rank(Cpub)
            if w1 or w2:
                eu_mixed_min=min(eu_mixed_min,rr)
                check(rr>=minimum,'E-original supported rank')
            else:
                eu_quot_min=min(eu_quot_min,rr)
                check(rr>=2*(TOY_R+1),'E-quotient rank')
            if z or w1 or w2:
                for t in (1,16,37,128):
                    check(rank(remove_shift(linear_pub(Cs,y),E[z][key]^t))>2*TOY_L,'E-typed wrong scalar')
    return {
        'seed':seed,
        'source_dimension':TOY_K,
        'nodes':TOY_L,
        'matrix_dimension':TOY_N,
        'local_C_support_min':minimum,
        'support_min_witness':minarg,
        'support_distribution':dict(sorted(support.items())),
        'valid_rank_pair':valid_ranks,
        'E_original_sample_min_rank':eu_mixed_min,
        'E_quotient_sample_min_rank':eu_quot_min,
        'checked_projective_original_classes':sum(support.values()),
        'same_key_two_witnesses':True,
    }

def log2_ceil(num):
    # exact strictly upper log2 bound; for integer N>0, log2 N <bit_length N
    return num.bit_length()

def real_certificate():
    # Pin the user's original field and resource workload.
    n,m,r,T=11000,16000,375,234
    k=n+m; L=m-1+r
    h=165; N=2*L+h
    d=5200
    qbits=128;Qbits=256
    u=L-d+1
    # Prior honest-setup Boolean-source theorem, unchanged.
    numerator_bool=(1<<(n+1))*math.comb(L,T-1)*pow(m+T-2,r)
    bool_bound_exponent=log2_ceil(numerator_bool)-qbits*(r-T+1)
    # NEW full-E original support: two F-span types t=1 and t=2.
    comb_u=math.comb(L,u)
    one_dim_exponent=log2_ceil(2*comb_u) +qbits*(n+1-u)
    two_dim_exponent=log2_ceil(2*comb_u) +qbits*(2*n-2*u)
    code_exponent=max(one_dim_exponent,two_dim_exponent)+1
    # NEW exact rectangular-product convolution with v>=T, h<=T<2h.
    exponents=[h*h+t*(T-2*h)+t*t for t in range(h+1)]
    minE=min(exponents)
    min_t=exponents.index(minE)
    f_rank_exponent=log2_ceil(16*(h+1))+qbits*(k-1)-Qbits*minE
    # NEW all-E wrong-scalar theorem, projective normalization t=1.
    wrong_e_exponent=2+Qbits*(k-h*h)
    # NEW full E nonconstant-slice rank theorem.
    orig_span_exponent=4+Qbits*(k+d-N-2)
    quotient_d=2*(r+1)
    quotient_span_exponent=4+Qbits*(k+quotient_d-N-2)
    exps=[bool_bound_exponent,code_exponent,f_rank_exponent,wrong_e_exponent,orig_span_exponent,quotient_span_exponent]
    total_exponent=max(exps)+math.ceil(math.log2(len(exps)))
    assertions=[(T>=h,'correct-rank T>=h'),
                (h*h>k,'all-E h squared > k'),
                (u>n+1,'support union positive margin'),
                (bool_bound_exponent <=-135,'Boolean SOURCE bound'),
                (code_exponent <=-128,'E-original support bound'),
                (f_rank_exponent <=-128,'F supplied-pair rank'),
                (wrong_e_exponent <=-128,'E arbitrary wrong scalar'),
                (orig_span_exponent <=-128,'E original nonconstant rank'),
                (quotient_span_exponent <=-128,'E quotient rank'),
                (total_exponent <=-128,'union of all six certificate terms')]
    for test,name in assertions:check(test,name)
    return {
        'n':n,'m':m,'k':k,'r':r,'L':L,'T':T,'h':h,'N':N,
        'F_bits':qbits,'E_bits':Qbits,
        'full_E_original_support_d':d,'support_zero_u':u,
        'original_support_log2_upper':code_exponent,
        'source_boolean_log2_upper':bool_bound_exponent,
        'F_invalid_product_rank_exponent_Eunits':minE,
        'F_invalid_product_rank_minimizer_t':min_t,
        'F_invalid_rank_log2_upper':f_rank_exponent,
        'all_E_wrong_scalar_log2_upper':wrong_e_exponent,
        'E_nonconstant_original_rank_lower':d,
        'E_nonconstant_original_rank_failure_log2_upper':orig_span_exponent,
        'E_nonconstant_quotient_rank_lower':quotient_d,
        'E_nonconstant_quotient_rank_failure_log2_upper':quotient_span_exponent,
        'combined_log2_upper':total_exponent,
        'public_bytes_previous':k*(2*L+117)**2*32,
        'public_bytes_new':k*N*N*32,
        'public_storage_increase_pct':round(100*(N*N/(2*L+117)**2-1),6),
        'certainty':'honest setup, supplied source and rank properties ONLY; not key hiding'
    }

def main():
    out={'candidate':'pivot_twisted_schur_20261023',
         'parent_sha':'79a55d32db8d0b60d46195a180c72ac0da59e892',
         'certificate':real_certificate(),
         'toy_runs':[run_toy(193713),run_toy(193719)],
         'limitations':'No full-tensor hiding, no bare-key extraction, no malicious setup or QPT security proof.'}
    out['assertions']=ASSERTIONS
    print(json.dumps(out,sort_keys=True,indent=2))

if __name__=='__main__':main()
